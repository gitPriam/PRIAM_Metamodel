insert into gdpr_processing (processingID, processingName, processingType, processingCategory, creationDate) values (2, 'YYYYYYYYY', 'Optional', 'Consent_Contract', "null");

insert into gdpr_Purpose (description, type, processing) values('yes', 'Main', '2');
