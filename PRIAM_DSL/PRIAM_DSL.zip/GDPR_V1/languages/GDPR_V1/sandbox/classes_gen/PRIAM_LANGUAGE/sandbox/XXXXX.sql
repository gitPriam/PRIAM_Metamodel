insert into gdpr_processing (processingID, processingName, processingType, processingCategory, creationDate) values (12, 'XXXXX', 'Optional', 'Consent_Contract', "null");

insert into gdpr_Purpose (description, type, processing) values('yes', 'Secondary', '12');
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (12, 33, false, false,false, false, false);
insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (12, 20, false, false,false, false, false);
