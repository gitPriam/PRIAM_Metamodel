<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:444166bb-c487-4308-9a5d-c586fae7fd99(PRIAM_LANGUAGE.sandbox)">
  <persistence version="9" />
  <languages>
    <use id="e02dfeab-630f-4f6d-86a8-a0833a3f70fc" name="PRIAM_LANGUAGE" version="0" />
    <use id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage" version="12" />
    <use id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core" version="2" />
    <use id="3ecd7c84-cde3-45de-886c-135ecc69b742" name="jetbrains.mps.lang.refactoring" version="0" />
  </languages>
  <imports />
  <registry>
    <language id="e02dfeab-630f-4f6d-86a8-a0833a3f70fc" name="PRIAM_LANGUAGE">
      <concept id="699862489961106632" name="PRIAM_LANGUAGE.structure.PersonalData" flags="ng" index="8tInM">
        <property id="699862489961106650" name="dataConservation" index="8tInw" />
        <property id="6834132425656832624" name="source" index="__Elb" />
        <reference id="2765716104327934759" name="dataSubjectCategory" index="2qqJW3" />
        <reference id="7072058747586032807" name="personalDataCategory" index="1aEWHh" />
      </concept>
      <concept id="7493740931523026183" name="PRIAM_LANGUAGE.structure.DataRefNpd" flags="ng" index="hKK2F">
        <reference id="7493740931523026184" name="dataref2" index="hKK2$" />
        <child id="7493740931523026186" name="dataUsage" index="hKK2A" />
      </concept>
      <concept id="2765716104327901119" name="PRIAM_LANGUAGE.structure.Requirements" flags="ng" index="2qqQer">
        <reference id="2765716104327901121" name="listDataType" index="2qqQf_" />
        <reference id="5766407207168339835" name="listProcessing" index="3dwKIQ" />
      </concept>
      <concept id="3526323479971544488" name="PRIAM_LANGUAGE.structure.Actor" flags="ng" index="2y8F$H">
        <property id="4542680411326421431" name="id" index="Ed$TN" />
        <property id="5319992952818338717" name="country" index="TxubU" />
        <reference id="6800078833463032685" name="country" index="3Jqs36" />
      </concept>
      <concept id="3526323479971544491" name="PRIAM_LANGUAGE.structure.DataSubject" flags="ng" index="2y8F$I">
        <property id="3526323479971544499" name="age" index="2y8F$Q" />
        <property id="4542680411326009908" name="idRef" index="Ef8nK" />
        <reference id="4542680411326349652" name="dsCategory" index="Eclqg" />
      </concept>
      <concept id="6834132425656841904" name="PRIAM_LANGUAGE.structure.DataRefPD" flags="ng" index="__C6b">
        <reference id="2744329693372584821" name="dataref1" index="3e4$8_" />
        <child id="6834132425656841907" name="dataUsage" index="__C68" />
      </concept>
      <concept id="6834132425656832631" name="PRIAM_LANGUAGE.structure.DataUsage" flags="ng" index="__Elc">
        <property id="6834132425656834002" name="u" index="__E3D" />
        <property id="6834132425656834007" name="d" index="__E3G" />
        <property id="6834132425656833995" name="c" index="__E3K" />
        <property id="6834132425656833993" name="hasPersonalUsage" index="__E3M" />
        <property id="6834132425656833998" name="r" index="__E3P" />
      </concept>
      <concept id="6834132425656832617" name="PRIAM_LANGUAGE.structure.Data" flags="ng" index="__Eli">
        <property id="4542680411328450152" name="id" index="EklAG" />
      </concept>
      <concept id="6834132425656832578" name="PRIAM_LANGUAGE.structure.Processing" flags="ng" index="__ElT">
        <property id="6834132425656832592" name="updatingDate" index="__ElF" />
        <property id="6834132425656832585" name="pc" index="__ElM" />
        <property id="6834132425656832588" name="createDate" index="__ElR" />
        <property id="6834132425656832583" name="tp" index="__ElW" />
        <property id="8429905822917321402" name="id" index="341Iwk" />
        <child id="7493740931523026224" name="dataUsedNpd" index="hKK2s" />
        <child id="6834132425656838581" name="purposes" index="__DUe" />
        <child id="6834132425656832620" name="dataUsedPd" index="__Eln" />
        <child id="6986923738720036808" name="mesures" index="1vO6Rn" />
      </concept>
      <concept id="6834132425656835441" name="PRIAM_LANGUAGE.structure.Purpose" flags="ng" index="__EDa">
        <property id="6834132425656835442" name="description" index="__ED9" />
        <property id="6834132425656835444" name="type" index="__EDf" />
      </concept>
      <concept id="4542680411326545150" name="PRIAM_LANGUAGE.structure.DataRequestAnswer" flags="ng" index="EdaGU">
        <reference id="4542680411326545156" name="request" index="EdaF0" />
      </concept>
      <concept id="23373094781276816" name="PRIAM_LANGUAGE.structure.DataType" flags="ng" index="2NV_G$">
        <child id="2765716104326992134" name="personalData" index="2tBhOy" />
        <child id="2765716104326992135" name="nonPersonalData" index="2tBhOz" />
      </concept>
      <concept id="5799940921481343741" name="PRIAM_LANGUAGE.structure.DataSubjectCategory" flags="ng" index="2Rm3lO">
        <property id="5799940921481343744" name="locationId" index="2Rm3i9" />
      </concept>
      <concept id="586614309276224451" name="PRIAM_LANGUAGE.structure.PRIAM_GDPR" flags="ng" index="WHx_o">
        <child id="5718002482165470825" name="dataSubjectCategory" index="p73Ev" />
      </concept>
      <concept id="7072058747586032804" name="PRIAM_LANGUAGE.structure.PersonalDataCategory" flags="ng" index="1aEWHi">
        <property id="7072058747586032806" name="id" index="1aEWHg" />
      </concept>
      <concept id="7072058747586032808" name="PRIAM_LANGUAGE.structure.ListPersonalDataCat" flags="ng" index="1aEWHu">
        <child id="7072058747586032809" name="personalDataCategory" index="1aEWHv" />
      </concept>
      <concept id="5766407207167574559" name="PRIAM_LANGUAGE.structure.ProcessingList" flags="ng" index="3dvUri">
        <child id="5766407207167574560" name="processing" index="3dvUrH" />
      </concept>
      <concept id="2744329693372336144" name="PRIAM_LANGUAGE.structure.NonPersonalData" flags="ng" index="3e5x_0" />
      <concept id="6986923738721491257" name="PRIAM_LANGUAGE.structure.ListMeasures" flags="ng" index="1vMTcA" />
      <concept id="6986923738720036805" name="PRIAM_LANGUAGE.structure.MeasureRef" flags="ng" index="1vO6Rq" />
      <concept id="4248638672751712930" name="PRIAM_LANGUAGE.structure.DataTypeList" flags="ng" index="3IF6zY">
        <child id="4248638672751712931" name="dataType" index="3IF6zZ" />
      </concept>
      <concept id="6800078833463032669" name="PRIAM_LANGUAGE.structure.Country" flags="ng" index="3Jqs3Q">
        <property id="6800078833463032672" name="id" index="3Jqs3b" />
        <property id="6800078833463032677" name="minorAge" index="3Jqs3e" />
      </concept>
      <concept id="5648447043204369416" name="PRIAM_LANGUAGE.structure.ListCountry" flags="ng" index="3SFxMw">
        <child id="5648447043204369419" name="countries" index="3SFxMz" />
      </concept>
      <concept id="4648915867537282771" name="PRIAM_LANGUAGE.structure.Request" flags="ng" index="3VIdaa">
        <property id="8273050021459694961" name="id" index="8UP9o" />
      </concept>
      <concept id="4648915867537282793" name="PRIAM_LANGUAGE.structure.DataRequest" flags="ng" index="3VIdaK">
        <property id="5799940921480571069" name="type" index="2Rp6WO" />
        <property id="4648915867537282798" name="newValue" index="3VIdaR" />
        <reference id="5799940921480571044" name="datasubject" index="2Rp6WH" />
        <reference id="4648915867537316225" name="dataReq" index="3VIlRo" />
      </concept>
      <concept id="4648915867537282796" name="PRIAM_LANGUAGE.structure.ProcessingRequest" flags="ng" index="3VIdaP">
        <reference id="4648915867537316223" name="processing" index="3VIlOA" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ng" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
    </language>
  </registry>
  <node concept="1aEWHu" id="68$ZZoCB4$i">
    <node concept="1aEWHi" id="68$ZZoCB4$j" role="1aEWHv">
      <property role="1aEWHg" value="1" />
      <property role="TrG5h" value="biometric data" />
    </node>
    <node concept="1aEWHi" id="68$ZZoCB4$k" role="1aEWHv">
      <property role="1aEWHg" value="2" />
      <property role="TrG5h" value="genetic data" />
    </node>
    <node concept="1aEWHi" id="68$ZZoCCusr" role="1aEWHv">
      <property role="1aEWHg" value="3" />
      <property role="TrG5h" value="ethnic origin" />
    </node>
    <node concept="1aEWHi" id="68$ZZoCCuss" role="1aEWHv">
      <property role="1aEWHg" value="4" />
      <property role="TrG5h" value="health data" />
    </node>
    <node concept="1aEWHi" id="68$ZZoCCust" role="1aEWHv">
      <property role="1aEWHg" value="5" />
      <property role="TrG5h" value="political opinions" />
    </node>
    <node concept="1aEWHi" id="40NILoOZXiA" role="1aEWHv">
      <property role="1aEWHg" value="6" />
      <property role="TrG5h" value="physical data" />
    </node>
    <node concept="1aEWHi" id="40NILoOZXiB" role="1aEWHv">
      <property role="1aEWHg" value="7" />
      <property role="TrG5h" value="Profil data" />
    </node>
    <node concept="1aEWHi" id="2nvZ8XYW3y2" role="1aEWHv">
      <property role="1aEWHg" value="8" />
      <property role="TrG5h" value="Web Identification data" />
    </node>
  </node>
  <node concept="WHx_o" id="2pxN2iW5OMl">
    <node concept="2Rm3lO" id="2pxN2iW5OMm" role="p73Ev">
      <property role="TrG5h" value="nutrition_user" />
      <property role="2Rm3i9" value="user_id" />
    </node>
  </node>
  <node concept="2Rm3lO" id="2pxN2iW5PPU">
    <property role="TrG5h" value="user" />
    <property role="2Rm3i9" value="matricule" />
  </node>
  <node concept="3IF6zY" id="SXiEYPJjhR">
    <node concept="2NV_G$" id="SXiEYPJjhS" role="3IF6zZ">
      <property role="TrG5h" value="user" />
      <node concept="8tInM" id="2nvZ8XYW3xR" role="2tBhOy">
        <property role="TrG5h" value="userID" />
        <property role="__Elb" value="5l7YRmKfOvn/Produced" />
        <property role="8tInw" value="12" />
        <property role="EklAG" value="1" />
        <ref role="1aEWHh" node="2nvZ8XYW3y2" resolve="Web Identification data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="SXiEYPJjhT" role="2tBhOy">
        <property role="EklAG" value="2" />
        <property role="TrG5h" value="name" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG5c" role="2tBhOy">
        <property role="EklAG" value="3" />
        <property role="TrG5h" value="firstName" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG5f" role="2tBhOy">
        <property role="EklAG" value="4" />
        <property role="TrG5h" value="dateOfBirth" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG5j" role="2tBhOy">
        <property role="EklAG" value="5" />
        <property role="TrG5h" value="weight" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG5o" role="2tBhOy">
        <property role="EklAG" value="6" />
        <property role="TrG5h" value="waistSize" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG5u" role="2tBhOy">
        <property role="EklAG" value="7" />
        <property role="TrG5h" value="fatMass" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG5_" role="2tBhOy">
        <property role="EklAG" value="8" />
        <property role="TrG5h" value="profession" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG5H" role="2tBhOy">
        <property role="EklAG" value="9" />
        <property role="TrG5h" value="psychoProfil" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG5Q" role="2tBhOy">
        <property role="EklAG" value="10" />
        <property role="TrG5h" value="morphoProfil" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
    </node>
    <node concept="2NV_G$" id="LHr8hYMG6E" role="3IF6zZ">
      <property role="TrG5h" value="Mensuration" />
      <node concept="3e5x_0" id="LHr8hYMG8e" role="2tBhOz">
        <property role="EklAG" value="15" />
        <property role="TrG5h" value="date" />
      </node>
      <node concept="8tInM" id="2nvZ8XYW3yb" role="2tBhOy">
        <property role="EklAG" value="11" />
        <property role="TrG5h" value="mensurationID" />
        <property role="8tInw" value="12" />
        <property role="__Elb" value="5l7YRmKfOvn/Produced" />
        <ref role="1aEWHh" node="2nvZ8XYW3y2" resolve="Web Identification data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG7C" role="2tBhOy">
        <property role="EklAG" value="12" />
        <property role="TrG5h" value="newWeight" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG7E" role="2tBhOy">
        <property role="EklAG" value="13" />
        <property role="TrG5h" value="newWaistSize" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMG7L" role="2tBhOy">
        <property role="EklAG" value="14" />
        <property role="TrG5h" value="newFatMass" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
    </node>
    <node concept="2NV_G$" id="LHr8hYMG7Y" role="3IF6zZ">
      <property role="TrG5h" value="Appointment" />
      <node concept="3e5x_0" id="LHr8hYMG8$" role="2tBhOz">
        <property role="EklAG" value="16" />
        <property role="TrG5h" value="dateAppointment" />
      </node>
      <node concept="3e5x_0" id="LHr8hYMG8A" role="2tBhOz">
        <property role="EklAG" value="17" />
        <property role="TrG5h" value="type" />
      </node>
    </node>
    <node concept="2NV_G$" id="LHr8hYMG8i" role="3IF6zZ">
      <property role="TrG5h" value="DailyMeal" />
      <node concept="3e5x_0" id="LHr8hYMG8Y" role="2tBhOz">
        <property role="EklAG" value="18" />
        <property role="TrG5h" value="type" />
      </node>
      <node concept="3e5x_0" id="LHr8hYMG90" role="2tBhOz">
        <property role="EklAG" value="19" />
        <property role="TrG5h" value="date" />
      </node>
    </node>
    <node concept="2NV_G$" id="LHr8hYMG8D" role="3IF6zZ">
      <property role="TrG5h" value="Food" />
      <node concept="3e5x_0" id="LHr8hYMG93" role="2tBhOz">
        <property role="EklAG" value="20" />
        <property role="TrG5h" value="nameFood" />
      </node>
      <node concept="3e5x_0" id="LHr8hYMG9u" role="2tBhOz">
        <property role="EklAG" value="21" />
        <property role="TrG5h" value="calorie" />
      </node>
    </node>
    <node concept="2NV_G$" id="LHr8hYMG95" role="3IF6zZ">
      <property role="TrG5h" value="HealthyMeal" />
      <node concept="3e5x_0" id="LHr8hYMG9x" role="2tBhOz">
        <property role="EklAG" value="22" />
        <property role="TrG5h" value="type" />
      </node>
    </node>
    <node concept="2NV_G$" id="LHr8hYMG9z" role="3IF6zZ">
      <property role="TrG5h" value="Diet" />
      <node concept="3e5x_0" id="LHr8hYMGas" role="2tBhOz">
        <property role="EklAG" value="23" />
        <property role="TrG5h" value="duration" />
      </node>
      <node concept="3e5x_0" id="LHr8hYMGau" role="2tBhOz">
        <property role="EklAG" value="24" />
        <property role="TrG5h" value="type" />
      </node>
    </node>
    <node concept="2NV_G$" id="LHr8hYMG9Z" role="3IF6zZ">
      <property role="TrG5h" value="FoodHabit" />
      <node concept="8tInM" id="LHr8hYMGax" role="2tBhOy">
        <property role="EklAG" value="25" />
        <property role="TrG5h" value="id" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="68$ZZoCCuss" resolve="health data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
    </node>
    <node concept="2NV_G$" id="LHr8hYMGaB" role="3IF6zZ">
      <property role="TrG5h" value="Account" />
      <node concept="8tInM" id="LHr8hYMGb8" role="2tBhOy">
        <property role="EklAG" value="26" />
        <property role="TrG5h" value="userName" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMGba" role="2tBhOy">
        <property role="EklAG" value="27" />
        <property role="TrG5h" value="passWord" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMGbd" role="2tBhOy">
        <property role="EklAG" value="28" />
        <property role="TrG5h" value="state" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiB" resolve="Profil data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
    </node>
    <node concept="2NV_G$" id="LHr8hYMGbp" role="3IF6zZ">
      <property role="TrG5h" value="SportActivity" />
      <node concept="8tInM" id="2nvZ8XYW3yq" role="2tBhOy">
        <property role="EklAG" value="29" />
        <property role="TrG5h" value="sportActivityID" />
        <property role="__Elb" value="5l7YRmKfOvn/Produced" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="2nvZ8XYW3y2" resolve="Web Identification data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMGbY" role="2tBhOy">
        <property role="EklAG" value="30" />
        <property role="TrG5h" value="sportActivityname" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMGc0" role="2tBhOy">
        <property role="EklAG" value="31" />
        <property role="TrG5h" value="duration" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMGc3" role="2tBhOy">
        <property role="EklAG" value="32" />
        <property role="TrG5h" value="calorie" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
      <node concept="8tInM" id="LHr8hYMGc7" role="2tBhOy">
        <property role="EklAG" value="33" />
        <property role="TrG5h" value="date" />
        <property role="8tInw" value="12" />
        <ref role="1aEWHh" node="40NILoOZXiA" resolve="physical data" />
        <ref role="2qqJW3" node="2pxN2iW5OMm" resolve="user" />
      </node>
    </node>
    <node concept="2NV_G$" id="LHr8hYMGcc" role="3IF6zZ">
      <property role="TrG5h" value="Exercise" />
      <node concept="3e5x_0" id="LHr8hYMGgR" role="2tBhOz">
        <property role="EklAG" value="34" />
        <property role="TrG5h" value="exerciseCategory" />
      </node>
      <node concept="3e5x_0" id="LHr8hYMGeP" role="2tBhOz">
        <property role="EklAG" value="35" />
        <property role="TrG5h" value="exerciceDescription" />
      </node>
      <node concept="3e5x_0" id="LHr8hYMGhB" role="2tBhOz">
        <property role="EklAG" value="36" />
        <property role="TrG5h" value="metabolicEquivalent" />
      </node>
    </node>
  </node>
  <node concept="__ElT" id="SXiEYPJjhV">
    <property role="341Iwk" value="1" />
    <property role="TrG5h" value="Personal Prospection" />
    <property role="__ElR" value="12-10-2020" />
    <property role="__ElM" value="33K18miOFRE/publicInterest" />
    <property role="__ElF" value=" " />
    <node concept="__EDa" id="SXiEYPJjhW" role="__DUe">
      <property role="__ED9" value="Propose a personal prospection to my users" />
      <property role="__EDf" value="33K18miOIUz/Main" />
    </node>
    <node concept="__C6b" id="SXiEYPJjhX" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMGb8" resolve="userName" />
      <node concept="__Elc" id="SXiEYPJjhY" role="__C68">
        <property role="__E3M" value="true" />
      </node>
    </node>
  </node>
  <node concept="2y8F$I" id="SXiEYPJjhZ">
    <property role="Ed$TN" value="1" />
    <property role="TrG5h" value="anais" />
    <property role="2y8F$Q" value="12" />
    <property role="TxubU" value="4BkqmtKkjtV/USA" />
    <property role="Ef8nK" value="12587" />
    <ref role="Eclqg" node="2pxN2iW5PPU" resolve="user" />
    <ref role="3Jqs36" node="4TzkayQW2ES" resolve="Algeria" />
  </node>
  <node concept="3VIdaK" id="SXiEYPJji0">
    <property role="8UP9o" value="2" />
    <property role="2Rp6WO" value="51XxSBB6uz2/Rectification" />
    <property role="3VIdaR" value="20" />
    <ref role="2Rp6WH" node="SXiEYPJjhZ" resolve="anais" />
    <ref role="3VIlRo" node="SXiEYPJjhT" resolve="name" />
  </node>
  <node concept="EdaGU" id="SXiEYPJji1">
    <ref role="EdaF0" node="SXiEYPJji0" />
  </node>
  <node concept="EdaGU" id="SXiEYPJji2">
    <ref role="EdaF0" node="SXiEYPJji0" />
  </node>
  <node concept="2qqQer" id="SXiEYPJji3">
    <ref role="2qqQf_" node="SXiEYPJjhR" />
    <ref role="3dwKIQ" node="506pcQt$iJL" />
  </node>
  <node concept="__ElT" id="2nvZ8XYW0uv">
    <property role="341Iwk" value="2" />
    <property role="TrG5h" value="Mensuration Management" />
    <property role="__ElW" value="4Xqrfpm3WbS/Mandatory" />
    <property role="__ElR" value="2022/03/21" />
    <node concept="1vO6Rq" id="1qGzCsGjI1A" role="1vO6Rn" />
    <node concept="__EDa" id="2nvZ8XYW0uw" role="__DUe">
      <property role="__ED9" value="Weight loss tracker" />
      <property role="__EDf" value="33K18miOIUz/Main" />
    </node>
    <node concept="__EDa" id="2nvZ8XYW0uz" role="__DUe">
      <property role="__EDf" value="33K18miOIU$/Secondary" />
      <property role="__ED9" value="Estimate the progress and time it will take to reach the desired weight" />
    </node>
    <node concept="__C6b" id="2nvZ8XYW0ux" role="__Eln">
      <ref role="3e4$8_" node="2nvZ8XYW3yb" resolve="mensurationID" />
      <node concept="__Elc" id="2nvZ8XYW0uy" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3xj" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMG7C" resolve="newWeight" />
      <node concept="__Elc" id="2nvZ8XYW3xk" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
        <property role="__E3P" value="true" />
        <property role="__E3D" value="true" />
        <property role="__E3G" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3xp" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMG7E" resolve="newWaistSize" />
      <node concept="__Elc" id="2nvZ8XYW3xq" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
        <property role="__E3P" value="true" />
        <property role="__E3D" value="true" />
        <property role="__E3G" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3xx" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMG5u" resolve="fatMass" />
      <node concept="__Elc" id="2nvZ8XYW3xy" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
        <property role="__E3P" value="true" />
        <property role="__E3D" value="true" />
        <property role="__E3G" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3xF" role="__Eln">
      <ref role="3e4$8_" node="2nvZ8XYW3xR" resolve="userID" />
      <node concept="__Elc" id="2nvZ8XYW3xG" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
        <property role="__E3P" value="true" />
        <property role="__E3G" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3_4" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMGb8" resolve="userName" />
      <node concept="__Elc" id="2nvZ8XYW3_5" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3_i" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMG5c" resolve="firstName" />
      <node concept="__Elc" id="2nvZ8XYW3_j" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3_y" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMG7C" resolve="newWeight" />
      <node concept="__Elc" id="2nvZ8XYW3_z" role="__C68">
        <property role="__E3P" value="true" />
        <property role="__E3M" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3_O" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMG5o" resolve="waistSize" />
      <node concept="__Elc" id="2nvZ8XYW3_P" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
  </node>
  <node concept="__ElT" id="2nvZ8XYW3yg">
    <property role="341Iwk" value="3" />
    <property role="TrG5h" value="Monitoring of sport activities" />
    <property role="__ElR" value="2022/03/21" />
    <property role="__ElF" value=" " />
    <node concept="hKK2F" id="6vZ7qLQg03x" role="hKK2s">
      <ref role="hKK2$" node="LHr8hYMGeP" resolve="exerciceDescription" />
      <node concept="__Elc" id="6vZ7qLQg03y" role="hKK2A">
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="hKK2F" id="6vZ7qLQg03R" role="hKK2s">
      <ref role="hKK2$" node="LHr8hYMGgR" resolve="exerciseCategory" />
      <node concept="__Elc" id="6vZ7qLQg03S" role="hKK2A">
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="1vO6Rq" id="63QyxWZq7MN" role="1vO6Rn" />
    <node concept="__EDa" id="2nvZ8XYW3yh" role="__DUe">
      <property role="__EDf" value="33K18miOIUz/Main" />
      <property role="__ED9" value="monitoring the user's fitness and well-being any where any time" />
    </node>
    <node concept="__C6b" id="2nvZ8XYW3yi" role="__Eln">
      <ref role="3e4$8_" node="2nvZ8XYW3xR" resolve="userID" />
      <node concept="__Elc" id="2nvZ8XYW3yj" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
        <property role="__E3P" value="true" />
        <property role="__E3G" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3$q" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMGb8" resolve="userName" />
      <node concept="__Elc" id="2nvZ8XYW3$r" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3$I" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMG5c" resolve="firstName" />
      <node concept="__Elc" id="2nvZ8XYW3$J" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3P" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3yk" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMGbY" resolve="sportActivityname" />
      <node concept="__Elc" id="2nvZ8XYW3yl" role="__C68">
        <property role="__E3K" value="true" />
        <property role="__E3P" value="true" />
        <property role="__E3D" value="true" />
        <property role="__E3G" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3yw" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMGc0" resolve="duration" />
      <node concept="__Elc" id="2nvZ8XYW3yx" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
        <property role="__E3P" value="true" />
        <property role="__E3D" value="true" />
        <property role="__E3G" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3yC" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMGc3" resolve="calorie" />
      <node concept="__Elc" id="2nvZ8XYW3yD" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
        <property role="__E3P" value="true" />
        <property role="__E3D" value="true" />
        <property role="__E3G" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3yM" role="__Eln">
      <ref role="3e4$8_" node="LHr8hYMGc7" resolve="date" />
      <node concept="__Elc" id="2nvZ8XYW3yN" role="__C68">
        <property role="__E3K" value="true" />
        <property role="__E3P" value="true" />
        <property role="__E3D" value="true" />
        <property role="__E3G" value="true" />
      </node>
    </node>
    <node concept="__C6b" id="2nvZ8XYW3yY" role="__Eln">
      <ref role="3e4$8_" node="2nvZ8XYW3xR" resolve="userID" />
      <node concept="__Elc" id="2nvZ8XYW3yZ" role="__C68">
        <property role="__E3M" value="true" />
        <property role="__E3K" value="true" />
        <property role="__E3P" value="true" />
        <property role="__E3G" value="true" />
      </node>
    </node>
  </node>
  <node concept="3dvUri" id="506pcQt$iJL">
    <node concept="3VIdaP" id="506pcQt$iJM" role="3dvUrH">
      <ref role="3VIlOA" node="2nvZ8XYW0uv" resolve="Mensuration Management" />
    </node>
    <node concept="3VIdaP" id="506pcQt$iJN" role="3dvUrH">
      <ref role="3VIlOA" node="2nvZ8XYW3yg" resolve="Monitoring of sport activities" />
    </node>
    <node concept="3VIdaP" id="506pcQt$iJQ" role="3dvUrH">
      <ref role="3VIlOA" node="SXiEYPJjhV" resolve="Personal Prospection" />
    </node>
  </node>
  <node concept="1vMTcA" id="63QyxWZgeMK" />
  <node concept="3SFxMw" id="4TzkayQW2ER">
    <node concept="3Jqs3Q" id="4TzkayQW2ES" role="3SFxMz">
      <property role="3Jqs3b" value="1" />
      <property role="TrG5h" value="Algeria" />
      <property role="3Jqs3e" value="12" />
    </node>
  </node>
</model>

