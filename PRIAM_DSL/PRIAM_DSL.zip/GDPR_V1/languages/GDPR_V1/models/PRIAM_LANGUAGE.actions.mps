<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:ae9a234e-2f2b-4d0a-a548-06e4e6ac0b45(PRIAM_LANGUAGE.actions)">
  <persistence version="9" />
  <languages>
    <use id="aee9cad2-acd4-4608-aef2-0004f6a1cdbd" name="jetbrains.mps.lang.actions" version="4" />
    <devkit ref="fbc25dd2-5da4-483a-8b19-70928e1b62d7(jetbrains.mps.devkit.general-purpose)" />
  </languages>
  <imports>
    <import index="20wa" ref="r:515d5f51-79c9-42c9-bba4-54c97b772d5b(PRIAM_LANGUAGE.structure)" implicit="true" />
    <import index="oniz" ref="r:e7beee50-bad0-4e7e-a2a7-f43f7868ae0a(PRIAM_LANGUAGE.behavior)" implicit="true" />
  </imports>
  <registry>
    <language id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage">
      <concept id="1215693861676" name="jetbrains.mps.baseLanguage.structure.BaseAssignmentExpression" flags="nn" index="d038R">
        <child id="1068498886297" name="rValue" index="37vLTx" />
        <child id="1068498886295" name="lValue" index="37vLTJ" />
      </concept>
      <concept id="4836112446988635817" name="jetbrains.mps.baseLanguage.structure.UndefinedType" flags="in" index="2jxLKc" />
      <concept id="1197027756228" name="jetbrains.mps.baseLanguage.structure.DotExpression" flags="nn" index="2OqwBi">
        <child id="1197027771414" name="operand" index="2Oq$k0" />
        <child id="1197027833540" name="operation" index="2OqNvi" />
      </concept>
      <concept id="1137021947720" name="jetbrains.mps.baseLanguage.structure.ConceptFunction" flags="in" index="2VMwT0">
        <child id="1137022507850" name="body" index="2VODD2" />
      </concept>
      <concept id="1068498886296" name="jetbrains.mps.baseLanguage.structure.VariableReference" flags="nn" index="37vLTw">
        <reference id="1068581517664" name="variableDeclaration" index="3cqZAo" />
      </concept>
      <concept id="1068498886294" name="jetbrains.mps.baseLanguage.structure.AssignmentExpression" flags="nn" index="37vLTI" />
      <concept id="4972933694980447171" name="jetbrains.mps.baseLanguage.structure.BaseVariableDeclaration" flags="ng" index="19Szcq">
        <child id="5680397130376446158" name="type" index="1tU5fm" />
      </concept>
      <concept id="1068580123155" name="jetbrains.mps.baseLanguage.structure.ExpressionStatement" flags="nn" index="3clFbF">
        <child id="1068580123156" name="expression" index="3clFbG" />
      </concept>
      <concept id="1068580123136" name="jetbrains.mps.baseLanguage.structure.StatementList" flags="sn" stub="5293379017992965193" index="3clFbS">
        <child id="1068581517665" name="statement" index="3cqZAp" />
      </concept>
      <concept id="1068580123137" name="jetbrains.mps.baseLanguage.structure.BooleanConstant" flags="nn" index="3clFbT">
        <property id="1068580123138" name="value" index="3clFbU" />
      </concept>
      <concept id="1068580320020" name="jetbrains.mps.baseLanguage.structure.IntegerConstant" flags="nn" index="3cmrfG">
        <property id="1068580320021" name="value" index="3cmrfH" />
      </concept>
      <concept id="1068581242875" name="jetbrains.mps.baseLanguage.structure.PlusExpression" flags="nn" index="3cpWs3" />
      <concept id="1204053956946" name="jetbrains.mps.baseLanguage.structure.IMethodCall" flags="ng" index="1ndlxa">
        <reference id="1068499141037" name="baseMethodDeclaration" index="37wK5l" />
        <child id="1068499141038" name="actualArgument" index="37wK5m" />
      </concept>
      <concept id="1081773326031" name="jetbrains.mps.baseLanguage.structure.BinaryOperation" flags="nn" index="3uHJSO">
        <child id="1081773367579" name="rightExpression" index="3uHU7w" />
        <child id="1081773367580" name="leftExpression" index="3uHU7B" />
      </concept>
    </language>
    <language id="fd392034-7849-419d-9071-12563d152375" name="jetbrains.mps.baseLanguage.closures">
      <concept id="1199569711397" name="jetbrains.mps.baseLanguage.closures.structure.ClosureLiteral" flags="nn" index="1bVj0M">
        <child id="1199569906740" name="parameter" index="1bW2Oz" />
        <child id="1199569916463" name="body" index="1bW5cS" />
      </concept>
    </language>
    <language id="aee9cad2-acd4-4608-aef2-0004f6a1cdbd" name="jetbrains.mps.lang.actions">
      <concept id="1158700664498" name="jetbrains.mps.lang.actions.structure.NodeFactories" flags="ng" index="37WguZ">
        <child id="1158700779049" name="nodeFactory" index="37WGs$" />
      </concept>
      <concept id="1158700725281" name="jetbrains.mps.lang.actions.structure.NodeFactory" flags="ig" index="37WvkG">
        <reference id="1158700943156" name="applicableConcept" index="37XkoT" />
        <child id="1158701448518" name="setupFunction" index="37ZfLb" />
      </concept>
      <concept id="1158701162220" name="jetbrains.mps.lang.actions.structure.NodeSetupFunction" flags="in" index="37Y9Zx" />
      <concept id="5584396657084912703" name="jetbrains.mps.lang.actions.structure.NodeSetupFunction_NewNode" flags="nn" index="1r4Lsj" />
      <concept id="5584396657084920670" name="jetbrains.mps.lang.actions.structure.NodeSetupFunction_EnclosingNode" flags="nn" index="1r4N1M" />
    </language>
    <language id="7866978e-a0f0-4cc7-81bc-4d213d9375e1" name="jetbrains.mps.lang.smodel">
      <concept id="1177026924588" name="jetbrains.mps.lang.smodel.structure.RefConcept_Reference" flags="nn" index="chp4Y">
        <reference id="1177026940964" name="conceptDeclaration" index="cht4Q" />
      </concept>
      <concept id="1179409122411" name="jetbrains.mps.lang.smodel.structure.Node_ConceptMethodCall" flags="nn" index="2qgKlT" />
      <concept id="4693937538533521280" name="jetbrains.mps.lang.smodel.structure.OfConceptOperation" flags="ng" index="v3k3i">
        <child id="4693937538533538124" name="requestedConcept" index="v3oSu" />
      </concept>
      <concept id="1171500988903" name="jetbrains.mps.lang.smodel.structure.Node_GetChildrenOperation" flags="nn" index="32TBzR" />
      <concept id="1138056022639" name="jetbrains.mps.lang.smodel.structure.SPropertyAccess" flags="nn" index="3TrcHB">
        <reference id="1138056395725" name="property" index="3TsBF5" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1133920641626" name="jetbrains.mps.lang.core.structure.BaseConcept" flags="ng" index="2VYdi">
        <child id="5169995583184591170" name="smodelAttribute" index="lGtFl" />
      </concept>
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ng" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
      <concept id="709746936026466394" name="jetbrains.mps.lang.core.structure.ChildAttribute" flags="ng" index="3VBwX9">
        <property id="709746936026609031" name="linkId" index="3V$3ak" />
        <property id="709746936026609029" name="role_DebugInfo" index="3V$3am" />
      </concept>
      <concept id="4452961908202556907" name="jetbrains.mps.lang.core.structure.BaseCommentAttribute" flags="ng" index="1X3_iC">
        <child id="3078666699043039389" name="commentedNode" index="8Wnug" />
      </concept>
    </language>
    <language id="83888646-71ce-4f1c-9c53-c54016f6ad4f" name="jetbrains.mps.baseLanguage.collections">
      <concept id="1204796164442" name="jetbrains.mps.baseLanguage.collections.structure.InternalSequenceOperation" flags="nn" index="23sCx2">
        <child id="1204796294226" name="closure" index="23t8la" />
      </concept>
      <concept id="1203518072036" name="jetbrains.mps.baseLanguage.collections.structure.SmartClosureParameterDeclaration" flags="ig" index="Rh6nW" />
      <concept id="1205679737078" name="jetbrains.mps.baseLanguage.collections.structure.SortOperation" flags="nn" index="2S7cBI">
        <child id="1205679832066" name="ascending" index="2S7zOq" />
      </concept>
      <concept id="1178286324487" name="jetbrains.mps.baseLanguage.collections.structure.SortDirection" flags="nn" index="1nlBCl" />
      <concept id="1165595910856" name="jetbrains.mps.baseLanguage.collections.structure.GetLastOperation" flags="nn" index="1yVyf7" />
    </language>
  </registry>
  <node concept="37WguZ" id="4TzkayQXjmp">
    <property role="TrG5h" value="DataSubjectFactory" />
    <node concept="37WvkG" id="4TzkayQXjmq" role="37WGs$">
      <ref role="37XkoT" to="20wa:33K18miOFQF" resolve="DataSubject" />
      <node concept="37Y9Zx" id="4TzkayQXjmr" role="37ZfLb">
        <node concept="3clFbS" id="4TzkayQXjms" role="2VODD2">
          <node concept="3clFbF" id="4TzkayQXjmM" role="3cqZAp">
            <node concept="37vLTI" id="4TzkayQXkD3" role="3clFbG">
              <node concept="3cpWs3" id="4TzkayQXsxk" role="37vLTx">
                <node concept="3cmrfG" id="4TzkayQXsxn" role="3uHU7w">
                  <property role="3cmrfH" value="1" />
                </node>
                <node concept="2OqwBi" id="4TzkayQXpT7" role="3uHU7B">
                  <node concept="2OqwBi" id="4TzkayQXp69" role="2Oq$k0">
                    <node concept="2OqwBi" id="4TzkayQXmmX" role="2Oq$k0">
                      <node concept="2OqwBi" id="4TzkayQXkX_" role="2Oq$k0">
                        <node concept="1r4N1M" id="4TzkayQXkMz" role="2Oq$k0" />
                        <node concept="32TBzR" id="4TzkayQYMLI" role="2OqNvi" />
                      </node>
                      <node concept="v3k3i" id="4TzkayQXoDb" role="2OqNvi">
                        <node concept="chp4Y" id="4TzkayQXoNx" role="v3oSu">
                          <ref role="cht4Q" to="20wa:33K18miOFQF" resolve="DataSubject" />
                        </node>
                      </node>
                    </node>
                    <node concept="1yVyf7" id="4TzkayQXpAV" role="2OqNvi" />
                  </node>
                  <node concept="2qgKlT" id="4TzkayQXrKe" role="2OqNvi">
                    <ref role="37wK5l" to="oniz:4TzkayQXqlc" resolve="getDsId" />
                  </node>
                </node>
              </node>
              <node concept="2OqwBi" id="4TzkayQXjz6" role="37vLTJ">
                <node concept="1r4Lsj" id="4TzkayQXjmL" role="2Oq$k0" />
                <node concept="3TrcHB" id="4TzkayQXjJZ" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                </node>
              </node>
            </node>
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="37WguZ" id="1qGzCsG1Pvu">
    <property role="TrG5h" value="PdFactory" />
    <node concept="37WvkG" id="4TzkayRkW_k" role="37WGs$">
      <ref role="37XkoT" to="20wa:AQqjC1K8N8" resolve="PersonalData" />
      <node concept="37Y9Zx" id="4TzkayRkW_l" role="37ZfLb">
        <node concept="3clFbS" id="4TzkayRkW_m" role="2VODD2">
          <node concept="3clFbF" id="4TzkayRl5MM" role="3cqZAp">
            <node concept="37vLTI" id="4TzkayRl5MN" role="3clFbG">
              <node concept="3cpWs3" id="4TzkayRl5MO" role="37vLTx">
                <node concept="3cmrfG" id="4TzkayRl5MP" role="3uHU7w">
                  <property role="3cmrfH" value="1" />
                </node>
                <node concept="2OqwBi" id="4TzkayRl5MQ" role="3uHU7B">
                  <node concept="2OqwBi" id="4TzkayRl5MR" role="2Oq$k0">
                    <node concept="2OqwBi" id="4TzkayRl5MS" role="2Oq$k0">
                      <node concept="2OqwBi" id="4TzkayRl5MT" role="2Oq$k0">
                        <node concept="1r4N1M" id="4TzkayRl5MU" role="2Oq$k0" />
                        <node concept="32TBzR" id="4TzkayRl5MV" role="2OqNvi" />
                      </node>
                      <node concept="v3k3i" id="4TzkayRl5MW" role="2OqNvi">
                        <node concept="chp4Y" id="4TzkayRl5MX" role="v3oSu">
                          <ref role="cht4Q" to="20wa:5VnHNHVgh9D" resolve="Data" />
                        </node>
                      </node>
                    </node>
                    <node concept="1yVyf7" id="4TzkayRl5MY" role="2OqNvi" />
                  </node>
                  <node concept="2qgKlT" id="4TzkayRl5MZ" role="2OqNvi">
                    <ref role="37wK5l" to="oniz:4TzkayR2C$D" resolve="getDataId" />
                  </node>
                </node>
              </node>
              <node concept="2OqwBi" id="4TzkayRl5N0" role="37vLTJ">
                <node concept="1r4Lsj" id="4TzkayRl5N1" role="2Oq$k0" />
                <node concept="3TrcHB" id="4TzkayRl5N2" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                </node>
              </node>
            </node>
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="37WguZ" id="1qGzCsG1QdL">
    <property role="TrG5h" value="DataFactory" />
    <node concept="37WvkG" id="1qGzCsG1QdN" role="37WGs$">
      <ref role="37XkoT" to="20wa:5VnHNHVgh9D" resolve="Data" />
      <node concept="37Y9Zx" id="1qGzCsG1QdO" role="37ZfLb">
        <node concept="3clFbS" id="1qGzCsG1QdP" role="2VODD2">
          <node concept="1X3_iC" id="6lD_mJXygA7" role="lGtFl">
            <property role="3V$3am" value="statement" />
            <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
            <node concept="3clFbF" id="1qGzCsG1QdQ" role="8Wnug">
              <node concept="37vLTI" id="1qGzCsG1QdR" role="3clFbG">
                <node concept="3cpWs3" id="1qGzCsG1QdS" role="37vLTx">
                  <node concept="3cmrfG" id="1qGzCsG1QdT" role="3uHU7w">
                    <property role="3cmrfH" value="1" />
                  </node>
                  <node concept="2OqwBi" id="1qGzCsG1QdU" role="3uHU7B">
                    <node concept="2OqwBi" id="1qGzCsG1QdV" role="2Oq$k0">
                      <node concept="2OqwBi" id="1qGzCsG1QdW" role="2Oq$k0">
                        <node concept="2OqwBi" id="1qGzCsG1QdX" role="2Oq$k0">
                          <node concept="1r4N1M" id="1qGzCsG1QdY" role="2Oq$k0" />
                          <node concept="32TBzR" id="1qGzCsG1QdZ" role="2OqNvi" />
                        </node>
                        <node concept="v3k3i" id="1qGzCsG1Qe0" role="2OqNvi">
                          <node concept="chp4Y" id="1qGzCsG1Qe1" role="v3oSu">
                            <ref role="cht4Q" to="20wa:5VnHNHVgh9D" resolve="Data" />
                          </node>
                        </node>
                      </node>
                      <node concept="1yVyf7" id="1qGzCsG1Qe2" role="2OqNvi" />
                    </node>
                    <node concept="2qgKlT" id="1qGzCsG1Qe3" role="2OqNvi">
                      <ref role="37wK5l" to="oniz:4TzkayR2C$D" resolve="getDataId" />
                    </node>
                  </node>
                </node>
                <node concept="2OqwBi" id="1qGzCsG1Qe4" role="37vLTJ">
                  <node concept="1r4Lsj" id="1qGzCsG1Qe5" role="2Oq$k0" />
                  <node concept="3TrcHB" id="1qGzCsG1Qe6" role="2OqNvi">
                    <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                  </node>
                </node>
              </node>
            </node>
          </node>
          <node concept="3clFbF" id="6lD_mJXy5e6" role="3cqZAp">
            <node concept="37vLTI" id="6lD_mJXy7kC" role="3clFbG">
              <node concept="3cpWs3" id="6lD_mJXydCV" role="37vLTx">
                <node concept="3cmrfG" id="6lD_mJXydQh" role="3uHU7w">
                  <property role="3cmrfH" value="1" />
                </node>
                <node concept="2OqwBi" id="6lD_mJXyf1n" role="3uHU7B">
                  <node concept="2OqwBi" id="6lD_mJXycoH" role="2Oq$k0">
                    <node concept="2OqwBi" id="6lD_mJXyasF" role="2Oq$k0">
                      <node concept="2OqwBi" id="6lD_mJXy8X9" role="2Oq$k0">
                        <node concept="2OqwBi" id="6lD_mJXy7Dq" role="2Oq$k0">
                          <node concept="1r4N1M" id="6lD_mJXy7uL" role="2Oq$k0" />
                          <node concept="32TBzR" id="6lD_mJXy7Sh" role="2OqNvi" />
                        </node>
                        <node concept="v3k3i" id="6lD_mJXya05" role="2OqNvi">
                          <node concept="chp4Y" id="6lD_mJXyact" role="v3oSu">
                            <ref role="cht4Q" to="20wa:5VnHNHVgh9D" resolve="Data" />
                          </node>
                        </node>
                      </node>
                      <node concept="2S7cBI" id="6lD_mJXyb5V" role="2OqNvi">
                        <node concept="1bVj0M" id="6lD_mJXyb5X" role="23t8la">
                          <node concept="3clFbS" id="6lD_mJXyb5Y" role="1bW5cS">
                            <node concept="3clFbF" id="6lD_mJXybaM" role="3cqZAp">
                              <node concept="2OqwBi" id="6lD_mJXybqA" role="3clFbG">
                                <node concept="37vLTw" id="6lD_mJXybaL" role="2Oq$k0">
                                  <ref role="3cqZAo" node="6lD_mJXyb5Z" resolve="it" />
                                </node>
                                <node concept="3TrcHB" id="6lD_mJXybPv" role="2OqNvi">
                                  <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                                </node>
                              </node>
                            </node>
                          </node>
                          <node concept="Rh6nW" id="6lD_mJXyb5Z" role="1bW2Oz">
                            <property role="TrG5h" value="it" />
                            <node concept="2jxLKc" id="6lD_mJXyb60" role="1tU5fm" />
                          </node>
                        </node>
                        <node concept="1nlBCl" id="6lD_mJXyb61" role="2S7zOq">
                          <property role="3clFbU" value="true" />
                        </node>
                      </node>
                    </node>
                    <node concept="1yVyf7" id="6lD_mJXyd4t" role="2OqNvi" />
                  </node>
                  <node concept="2qgKlT" id="6lD_mJXyg9f" role="2OqNvi">
                    <ref role="37wK5l" to="oniz:4TzkayR2C$D" resolve="getDataId" />
                  </node>
                </node>
              </node>
              <node concept="2OqwBi" id="6lD_mJXy5F$" role="37vLTJ">
                <node concept="1r4Lsj" id="6lD_mJXy5e5" role="2Oq$k0" />
                <node concept="3TrcHB" id="6lD_mJXy636" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                </node>
              </node>
            </node>
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="37WguZ" id="17LsDUMnRl4">
    <property role="TrG5h" value="NPD_Ref" />
    <node concept="37WvkG" id="17LsDUMnRl5" role="37WGs$">
      <ref role="37XkoT" to="20wa:6vZ7qLQf1O7" resolve="DataRefNpd" />
      <node concept="37Y9Zx" id="17LsDUMnRl6" role="37ZfLb">
        <node concept="3clFbS" id="17LsDUMnRl7" role="2VODD2">
          <node concept="3clFbF" id="17LsDUMnRlj" role="3cqZAp">
            <node concept="2OqwBi" id="17LsDUMnRsL" role="3clFbG">
              <node concept="1r4Lsj" id="17LsDUMnRli" role="2Oq$k0" />
              <node concept="2qgKlT" id="17LsDUMoX_S" role="2OqNvi">
                <ref role="37wK5l" to="oniz:17LsDUMnS6v" resolve="setStatus" />
                <node concept="3clFbT" id="17LsDUMoXCy" role="37wK5m" />
              </node>
            </node>
          </node>
        </node>
      </node>
    </node>
  </node>
</model>

