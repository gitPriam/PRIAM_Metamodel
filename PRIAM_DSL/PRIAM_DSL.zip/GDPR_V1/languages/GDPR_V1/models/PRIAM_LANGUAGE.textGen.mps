<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:0504ed10-6c07-440f-84d5-21e63be24e6f(PRIAM_LANGUAGE.textGen)">
  <persistence version="9" />
  <languages>
    <use id="b83431fe-5c8f-40bc-8a36-65e25f4dd253" name="jetbrains.mps.lang.textGen" version="1" />
    <use id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core" version="2" />
    <use id="e02dfeab-630f-4f6d-86a8-a0833a3f70fc" name="PRIAM_LANGUAGE" version="0" />
    <devkit ref="fa73d85a-ac7f-447b-846c-fcdc41caa600(jetbrains.mps.devkit.aspect.textgen)" />
  </languages>
  <imports>
    <import index="20wa" ref="r:515d5f51-79c9-42c9-bba4-54c97b772d5b(PRIAM_LANGUAGE.structure)" />
    <import index="tpck" ref="r:00000000-0000-4000-0000-011c89590288(jetbrains.mps.lang.core.structure)" implicit="true" />
    <import index="c17a" ref="8865b7a8-5271-43d3-884c-6fd1d9cfdd34/java:org.jetbrains.mps.openapi.language(MPS.OpenAPI/)" implicit="true" />
    <import index="wyt6" ref="6354ebe7-c22a-4a0f-ac54-50b52ab9b065/java:java.lang(JDK/)" implicit="true" />
    <import index="oniz" ref="r:e7beee50-bad0-4e7e-a2a7-f43f7868ae0a(PRIAM_LANGUAGE.behavior)" implicit="true" />
  </imports>
  <registry>
    <language id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage">
      <concept id="1215693861676" name="jetbrains.mps.baseLanguage.structure.BaseAssignmentExpression" flags="nn" index="d038R">
        <child id="1068498886297" name="rValue" index="37vLTx" />
        <child id="1068498886295" name="lValue" index="37vLTJ" />
      </concept>
      <concept id="1202948039474" name="jetbrains.mps.baseLanguage.structure.InstanceMethodCallOperation" flags="nn" index="liA8E" />
      <concept id="1239714755177" name="jetbrains.mps.baseLanguage.structure.AbstractUnaryNumberOperation" flags="nn" index="2$Kvd9">
        <child id="1239714902950" name="expression" index="2$L3a6" />
      </concept>
      <concept id="1154032098014" name="jetbrains.mps.baseLanguage.structure.AbstractLoopStatement" flags="nn" index="2LF5Ji">
        <child id="1154032183016" name="body" index="2LFqv$" />
      </concept>
      <concept id="1197027756228" name="jetbrains.mps.baseLanguage.structure.DotExpression" flags="nn" index="2OqwBi">
        <child id="1197027771414" name="operand" index="2Oq$k0" />
        <child id="1197027833540" name="operation" index="2OqNvi" />
      </concept>
      <concept id="1137021947720" name="jetbrains.mps.baseLanguage.structure.ConceptFunction" flags="in" index="2VMwT0">
        <child id="1137022507850" name="body" index="2VODD2" />
      </concept>
      <concept id="1070475926800" name="jetbrains.mps.baseLanguage.structure.StringLiteral" flags="nn" index="Xl_RD">
        <property id="1070475926801" name="value" index="Xl_RC" />
      </concept>
      <concept id="1070534370425" name="jetbrains.mps.baseLanguage.structure.IntegerType" flags="in" index="10Oyi0" />
      <concept id="1068431474542" name="jetbrains.mps.baseLanguage.structure.VariableDeclaration" flags="ng" index="33uBYm">
        <child id="1068431790190" name="initializer" index="33vP2m" />
      </concept>
      <concept id="1068498886296" name="jetbrains.mps.baseLanguage.structure.VariableReference" flags="nn" index="37vLTw">
        <reference id="1068581517664" name="variableDeclaration" index="3cqZAo" />
      </concept>
      <concept id="1068498886294" name="jetbrains.mps.baseLanguage.structure.AssignmentExpression" flags="nn" index="37vLTI" />
      <concept id="1225271177708" name="jetbrains.mps.baseLanguage.structure.StringType" flags="in" index="17QB3L" />
      <concept id="4972933694980447171" name="jetbrains.mps.baseLanguage.structure.BaseVariableDeclaration" flags="ng" index="19Szcq">
        <child id="5680397130376446158" name="type" index="1tU5fm" />
      </concept>
      <concept id="1068580123152" name="jetbrains.mps.baseLanguage.structure.EqualsExpression" flags="nn" index="3clFbC" />
      <concept id="1068580123155" name="jetbrains.mps.baseLanguage.structure.ExpressionStatement" flags="nn" index="3clFbF">
        <child id="1068580123156" name="expression" index="3clFbG" />
      </concept>
      <concept id="1068580123157" name="jetbrains.mps.baseLanguage.structure.Statement" flags="nn" index="3clFbH" />
      <concept id="1068580123159" name="jetbrains.mps.baseLanguage.structure.IfStatement" flags="nn" index="3clFbJ">
        <child id="1068580123160" name="condition" index="3clFbw" />
        <child id="1068580123161" name="ifTrue" index="3clFbx" />
      </concept>
      <concept id="1068580123136" name="jetbrains.mps.baseLanguage.structure.StatementList" flags="sn" stub="5293379017992965193" index="3clFbS">
        <child id="1068581517665" name="statement" index="3cqZAp" />
      </concept>
      <concept id="1068580320020" name="jetbrains.mps.baseLanguage.structure.IntegerConstant" flags="nn" index="3cmrfG">
        <property id="1068580320021" name="value" index="3cmrfH" />
      </concept>
      <concept id="1068581242875" name="jetbrains.mps.baseLanguage.structure.PlusExpression" flags="nn" index="3cpWs3" />
      <concept id="1068581242864" name="jetbrains.mps.baseLanguage.structure.LocalVariableDeclarationStatement" flags="nn" index="3cpWs8">
        <child id="1068581242865" name="localVariableDeclaration" index="3cpWs9" />
      </concept>
      <concept id="1068581242863" name="jetbrains.mps.baseLanguage.structure.LocalVariableDeclaration" flags="nr" index="3cpWsn" />
      <concept id="1204053956946" name="jetbrains.mps.baseLanguage.structure.IMethodCall" flags="ng" index="1ndlxa">
        <reference id="1068499141037" name="baseMethodDeclaration" index="37wK5l" />
      </concept>
      <concept id="1081773326031" name="jetbrains.mps.baseLanguage.structure.BinaryOperation" flags="nn" index="3uHJSO">
        <child id="1081773367579" name="rightExpression" index="3uHU7w" />
        <child id="1081773367580" name="leftExpression" index="3uHU7B" />
      </concept>
      <concept id="1214918800624" name="jetbrains.mps.baseLanguage.structure.PostfixIncrementExpression" flags="nn" index="3uNrnE" />
      <concept id="1073239437375" name="jetbrains.mps.baseLanguage.structure.NotEqualsExpression" flags="nn" index="3y3z36" />
      <concept id="6329021646629104954" name="jetbrains.mps.baseLanguage.structure.SingleLineComment" flags="nn" index="3SKdUt">
        <child id="8356039341262087992" name="line" index="1aUNEU" />
      </concept>
    </language>
    <language id="b83431fe-5c8f-40bc-8a36-65e25f4dd253" name="jetbrains.mps.lang.textGen">
      <concept id="45307784116571022" name="jetbrains.mps.lang.textGen.structure.FilenameFunction" flags="ig" index="29tfMY" />
      <concept id="8931911391946696733" name="jetbrains.mps.lang.textGen.structure.ExtensionDeclaration" flags="in" index="9MYSb" />
      <concept id="1237305208784" name="jetbrains.mps.lang.textGen.structure.NewLineAppendPart" flags="ng" index="l8MVK" />
      <concept id="1237305334312" name="jetbrains.mps.lang.textGen.structure.NodeAppendPart" flags="ng" index="l9hG8">
        <child id="1237305790512" name="value" index="lb14g" />
      </concept>
      <concept id="1237305557638" name="jetbrains.mps.lang.textGen.structure.ConstantStringAppendPart" flags="ng" index="la8eA">
        <property id="1237305576108" name="value" index="lacIc" />
      </concept>
      <concept id="1237306079178" name="jetbrains.mps.lang.textGen.structure.AppendOperation" flags="nn" index="lc7rE">
        <child id="1237306115446" name="part" index="lcghm" />
      </concept>
      <concept id="1233670071145" name="jetbrains.mps.lang.textGen.structure.ConceptTextGenDeclaration" flags="ig" index="WtQ9Q">
        <reference id="1233670257997" name="conceptDeclaration" index="WuzLi" />
        <child id="45307784116711884" name="filename" index="29tGrW" />
        <child id="1233749296504" name="textGenBlock" index="11c4hB" />
        <child id="7991274449437422201" name="extension" index="33IsuW" />
      </concept>
      <concept id="1233748055915" name="jetbrains.mps.lang.textGen.structure.NodeParameter" flags="nn" index="117lpO" />
      <concept id="1233749247888" name="jetbrains.mps.lang.textGen.structure.GenerateTextDeclaration" flags="in" index="11bSqf" />
    </language>
    <language id="7866978e-a0f0-4cc7-81bc-4d213d9375e1" name="jetbrains.mps.lang.smodel">
      <concept id="1179409122411" name="jetbrains.mps.lang.smodel.structure.Node_ConceptMethodCall" flags="nn" index="2qgKlT" />
      <concept id="3562215692195599741" name="jetbrains.mps.lang.smodel.structure.SLinkImplicitSelect" flags="nn" index="13MTOL">
        <reference id="3562215692195600259" name="link" index="13MTZf" />
      </concept>
      <concept id="1139613262185" name="jetbrains.mps.lang.smodel.structure.Node_GetParentOperation" flags="nn" index="1mfA1w" />
      <concept id="1138056022639" name="jetbrains.mps.lang.smodel.structure.SPropertyAccess" flags="nn" index="3TrcHB">
        <reference id="1138056395725" name="property" index="3TsBF5" />
      </concept>
      <concept id="1138056143562" name="jetbrains.mps.lang.smodel.structure.SLinkAccess" flags="nn" index="3TrEf2">
        <reference id="1138056516764" name="link" index="3Tt5mk" />
      </concept>
      <concept id="1138056282393" name="jetbrains.mps.lang.smodel.structure.SLinkListAccess" flags="nn" index="3Tsc0h">
        <reference id="1138056546658" name="link" index="3TtcxE" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1133920641626" name="jetbrains.mps.lang.core.structure.BaseConcept" flags="ng" index="2VYdi">
        <child id="5169995583184591170" name="smodelAttribute" index="lGtFl" />
      </concept>
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ng" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
      <concept id="709746936026466394" name="jetbrains.mps.lang.core.structure.ChildAttribute" flags="ng" index="3VBwX9">
        <property id="709746936026609031" name="linkId" index="3V$3ak" />
        <property id="709746936026609029" name="role_DebugInfo" index="3V$3am" />
      </concept>
      <concept id="4452961908202556907" name="jetbrains.mps.lang.core.structure.BaseCommentAttribute" flags="ng" index="1X3_iC">
        <child id="3078666699043039389" name="commentedNode" index="8Wnug" />
      </concept>
    </language>
    <language id="c7fb639f-be78-4307-89b0-b5959c3fa8c8" name="jetbrains.mps.lang.text">
      <concept id="155656958578482948" name="jetbrains.mps.lang.text.structure.Word" flags="nn" index="3oM_SD">
        <property id="155656958578482949" name="value" index="3oM_SC" />
      </concept>
      <concept id="2535923850359271782" name="jetbrains.mps.lang.text.structure.Line" flags="nn" index="1PaTwC">
        <child id="2535923850359271783" name="elements" index="1PaTwD" />
      </concept>
    </language>
    <language id="83888646-71ce-4f1c-9c53-c54016f6ad4f" name="jetbrains.mps.baseLanguage.collections">
      <concept id="540871147943773365" name="jetbrains.mps.baseLanguage.collections.structure.SingleArgumentSequenceOperation" flags="nn" index="25WWJ4">
        <child id="540871147943773366" name="argument" index="25WWJ7" />
      </concept>
      <concept id="1153943597977" name="jetbrains.mps.baseLanguage.collections.structure.ForEachStatement" flags="nn" index="2Gpval">
        <child id="1153944400369" name="variable" index="2Gsz3X" />
        <child id="1153944424730" name="inputSequence" index="2GsD0m" />
      </concept>
      <concept id="1153944193378" name="jetbrains.mps.baseLanguage.collections.structure.ForEachVariable" flags="nr" index="2GrKxI" />
      <concept id="1153944233411" name="jetbrains.mps.baseLanguage.collections.structure.ForEachVariableReference" flags="nn" index="2GrUjf">
        <reference id="1153944258490" name="variable" index="2Gs0qQ" />
      </concept>
      <concept id="1162934736510" name="jetbrains.mps.baseLanguage.collections.structure.GetElementOperation" flags="nn" index="34jXtK" />
      <concept id="9042586985346099698" name="jetbrains.mps.baseLanguage.collections.structure.MultiForEachStatement" flags="nn" index="1_o_46">
        <child id="9042586985346099734" name="forEach" index="1_o_by" />
      </concept>
      <concept id="9042586985346099733" name="jetbrains.mps.baseLanguage.collections.structure.MultiForEachPair" flags="ng" index="1_o_bx">
        <child id="9042586985346099778" name="variable" index="1_o_aQ" />
        <child id="9042586985346099735" name="input" index="1_o_bz" />
      </concept>
      <concept id="9042586985346099736" name="jetbrains.mps.baseLanguage.collections.structure.MultiForEachVariable" flags="ng" index="1_o_bG" />
      <concept id="8293956702609956630" name="jetbrains.mps.baseLanguage.collections.structure.MultiForEachVariableReference" flags="nn" index="3M$PaV">
        <reference id="8293956702609966325" name="variable" index="3M$S_o" />
      </concept>
      <concept id="1178894719932" name="jetbrains.mps.baseLanguage.collections.structure.DistinctOperation" flags="nn" index="1VAtEI" />
    </language>
  </registry>
  <node concept="WtQ9Q" id="7bfLM_U7Gt1">
    <ref role="WuzLi" to="20wa:5VnHNHVgh92" resolve="Processing" />
    <node concept="29tfMY" id="7bfLM_U7Gt2" role="29tGrW">
      <node concept="3clFbS" id="7bfLM_U7Gt3" role="2VODD2">
        <node concept="3clFbF" id="7bfLM_U7G_S" role="3cqZAp">
          <node concept="2OqwBi" id="7bfLM_U7GKo" role="3clFbG">
            <node concept="117lpO" id="7bfLM_U7G_R" role="2Oq$k0" />
            <node concept="3TrcHB" id="7bfLM_U7GXH" role="2OqNvi">
              <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="7bfLM_U7H4B" role="33IsuW">
      <node concept="3clFbS" id="7bfLM_U7H4C" role="2VODD2">
        <node concept="3clFbF" id="7bfLM_U7H5_" role="3cqZAp">
          <node concept="Xl_RD" id="7bfLM_U7H5$" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="7bfLM_U7HbX" role="11c4hB">
      <node concept="3clFbS" id="7bfLM_U7HbY" role="2VODD2">
        <node concept="3cpWs8" id="7bfLM_U7ZSC" role="3cqZAp">
          <node concept="3cpWsn" id="7bfLM_U7ZS$" role="3cpWs9">
            <property role="TrG5h" value="datesString" />
            <node concept="17QB3L" id="7bfLM_U7ZUV" role="1tU5fm" />
            <node concept="3cpWs3" id="7bfLM_U84nS" role="33vP2m">
              <node concept="Xl_RD" id="7bfLM_U84ow" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="7bfLM_U83yD" role="3uHU7B">
                <node concept="117lpO" id="7bfLM_U83sw" role="2Oq$k0" />
                <node concept="3TrcHB" id="7bfLM_U83F0" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5VnHNHVgh9c" resolve="createDate" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="7bfLM_U7Hhz" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7HhS" role="lcghm">
            <property role="lacIc" value="insert into gdpr_processing (processingID, processingName, processingType, processingCategory, creationDate) values (" />
          </node>
        </node>
        <node concept="lc7rE" id="7bfLM_U7Hli" role="3cqZAp">
          <node concept="l9hG8" id="1PjvIwH_fIO" role="lcghm">
            <node concept="3cpWs3" id="1PjvIwH_gYs" role="lb14g">
              <node concept="Xl_RD" id="1PjvIwH_gYw" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="1PjvIwH_fYp" role="3uHU7B">
                <node concept="117lpO" id="1PjvIwH_fR9" role="2Oq$k0" />
                <node concept="3TrcHB" id="1PjvIwH_g7l" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:7jX2EUKYYaU" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="1PjvIwH_f8X" role="lcghm">
            <property role="lacIc" value=", '" />
          </node>
          <node concept="l9hG8" id="7bfLM_U7HKQ" role="lcghm">
            <node concept="2OqwBi" id="7bfLM_U7HT2" role="lb14g">
              <node concept="117lpO" id="7bfLM_U7HLF" role="2Oq$k0" />
              <node concept="3TrcHB" id="7bfLM_U7I1Z" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="7bfLM_U7I9$" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="7bfLM_U7Ivq" role="lcghm">
            <node concept="2OqwBi" id="4Xqrfpm45lq" role="lb14g">
              <node concept="2OqwBi" id="7bfLM_U7IC3" role="2Oq$k0">
                <node concept="117lpO" id="7bfLM_U7IwG" role="2Oq$k0" />
                <node concept="3TrcHB" id="7bfLM_U7IKZ" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5VnHNHVgh97" resolve="tp" />
                </node>
              </node>
              <node concept="liA8E" id="4Xqrfpm45IB" role="2OqNvi">
                <ref role="37wK5l" to="c17a:~SEnumerationLiteral.getName()" resolve="getName" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="7bfLM_U7IMM" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="7bfLM_U7IR$" role="lcghm">
            <node concept="2OqwBi" id="33K18miPvHG" role="lb14g">
              <node concept="2OqwBi" id="33K18miPvoo" role="2Oq$k0">
                <node concept="117lpO" id="7bfLM_U7ITi" role="2Oq$k0" />
                <node concept="3TrcHB" id="33K18miPvy7" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5VnHNHVgh99" resolve="pc" />
                </node>
              </node>
              <node concept="liA8E" id="33K18miPNTE" role="2OqNvi">
                <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="7bfLM_U7JbO" role="lcghm">
            <property role="lacIc" value="', &quot;" />
          </node>
          <node concept="l9hG8" id="7bfLM_U867r" role="lcghm">
            <node concept="37vLTw" id="7bfLM_U869B" role="lb14g">
              <ref role="3cqZAo" node="7bfLM_U7ZS$" resolve="datesString" />
            </node>
          </node>
          <node concept="la8eA" id="7bfLM_U7JBQ" role="lcghm">
            <property role="lacIc" value="&quot;);" />
          </node>
          <node concept="l8MVK" id="2NO6V5fWi$w" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7K5K" role="3cqZAp">
          <node concept="l8MVK" id="7bfLM_U7K7W" role="lcghm" />
        </node>
        <node concept="3clFbH" id="7bfLM_U9epa" role="3cqZAp" />
        <node concept="3cpWs8" id="33K18miT1H_" role="3cqZAp">
          <node concept="3cpWsn" id="33K18miT1HC" role="3cpWs9">
            <property role="TrG5h" value="i" />
            <node concept="10Oyi0" id="33K18miT1Hz" role="1tU5fm" />
            <node concept="3cmrfG" id="33K18miT1Rh" role="33vP2m">
              <property role="3cmrfH" value="-1" />
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="4Xqrfpmf$9H" role="3cqZAp">
          <node concept="2GrKxI" id="4Xqrfpmf$9J" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="4Xqrfpmf_zY" role="2GsD0m">
            <node concept="117lpO" id="4Xqrfpmf$mW" role="2Oq$k0" />
            <node concept="2qgKlT" id="4Xqrfpmf_Lo" role="2OqNvi">
              <ref role="37wK5l" to="oniz:4Xqrfpm5qCx" resolve="getAllDescriptionPurpose" />
            </node>
          </node>
          <node concept="3clFbS" id="4Xqrfpmf$9N" role="2LFqv$">
            <node concept="3clFbF" id="33K18miT21M" role="3cqZAp">
              <node concept="3uNrnE" id="33K18miT2CX" role="3clFbG">
                <node concept="37vLTw" id="33K18miT2CZ" role="2$L3a6">
                  <ref role="3cqZAo" node="33K18miT1HC" resolve="i" />
                </node>
              </node>
            </node>
            <node concept="lc7rE" id="4Xqrfpmf_Sb" role="3cqZAp">
              <node concept="la8eA" id="4Xqrfpmf_Sv" role="lcghm">
                <property role="lacIc" value="insert into gdpr_Purpose (description, type, processing) values('" />
              </node>
              <node concept="l9hG8" id="4Xqrfpmf_VT" role="lcghm">
                <node concept="2GrUjf" id="4XqrfpmfAgc" role="lb14g">
                  <ref role="2Gs0qQ" node="4Xqrfpmf$9J" resolve="e" />
                </node>
              </node>
              <node concept="la8eA" id="4XqrfpmfKId" role="lcghm">
                <property role="lacIc" value="', '" />
              </node>
              <node concept="l9hG8" id="4XqrfpmfB4j" role="lcghm">
                <node concept="2OqwBi" id="4XqrfpmfP4C" role="lb14g">
                  <node concept="2OqwBi" id="4XqrfpmfCzN" role="2Oq$k0">
                    <node concept="2OqwBi" id="4XqrfpmfBeB" role="2Oq$k0">
                      <node concept="117lpO" id="4XqrfpmfBc1" role="2Oq$k0" />
                      <node concept="2qgKlT" id="4XqrfpmfBgh" role="2OqNvi">
                        <ref role="37wK5l" to="oniz:4Xqrfpm6wZE" resolve="getAllTypePurpose" />
                      </node>
                    </node>
                    <node concept="34jXtK" id="4XqrfpmfDLb" role="2OqNvi">
                      <node concept="37vLTw" id="33K18miSiFX" role="25WWJ7">
                        <ref role="3cqZAo" node="33K18miT1HC" resolve="i" />
                      </node>
                    </node>
                  </node>
                  <node concept="liA8E" id="4XqrfpmfP_L" role="2OqNvi">
                    <ref role="37wK5l" to="wyt6:~String.toString()" resolve="toString" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="4XqrfpmfKoG" role="lcghm">
                <property role="lacIc" value="', '" />
              </node>
              <node concept="l9hG8" id="IIjfDnUGee" role="lcghm">
                <node concept="3cpWs3" id="7McLYwdKmSo" role="lb14g">
                  <node concept="Xl_RD" id="7McLYwdKmSs" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="IIjfDnUGqB" role="3uHU7B">
                    <node concept="117lpO" id="IIjfDnUGij" role="2Oq$k0" />
                    <node concept="3TrcHB" id="7McLYwdKm2$" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:7jX2EUKYYaU" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="IIjfDnUGM6" role="lcghm">
                <property role="lacIc" value="');" />
              </node>
              <node concept="l8MVK" id="2NO6V5fWio_" role="lcghm" />
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="2NO6V5fTG43" role="3cqZAp">
          <node concept="2GrKxI" id="2NO6V5fTG45" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="2NO6V5fTGzw" role="2GsD0m">
            <node concept="117lpO" id="2NO6V5fTGkt" role="2Oq$k0" />
            <node concept="3Tsc0h" id="2NO6V5fTGMD" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:5VnHNHVgh9G" resolve="dataUsedPd" />
            </node>
          </node>
          <node concept="3clFbS" id="2NO6V5fTG49" role="2LFqv$">
            <node concept="3SKdUt" id="6vZ7qLQg577" role="3cqZAp">
              <node concept="1PaTwC" id="6vZ7qLQg578" role="1aUNEU">
                <node concept="3oM_SD" id="6vZ7qLQg5aF" role="1PaTwD">
                  <property role="3oM_SC" value="personal" />
                </node>
                <node concept="3oM_SD" id="6vZ7qLQg5aP" role="1PaTwD">
                  <property role="3oM_SC" value="data" />
                </node>
                <node concept="3oM_SD" id="6vZ7qLQg5aX" role="1PaTwD">
                  <property role="3oM_SC" value="" />
                </node>
              </node>
            </node>
            <node concept="lc7rE" id="2NO6V5fTPS4" role="3cqZAp">
              <node concept="la8eA" id="2NO6V5fU41p" role="lcghm">
                <property role="lacIc" value="insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (" />
              </node>
              <node concept="l9hG8" id="2NO6V5fU4IJ" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fU5PE" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fU5QL" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fU4ZB" role="3uHU7B">
                    <node concept="117lpO" id="2NO6V5fU4Rj" role="2Oq$k0" />
                    <node concept="3TrcHB" id="2NO6V5fU58z" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:7jX2EUKYYaU" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fU608" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="2NO6V5fTPSo" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fU7Ar" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fU7Jt" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fU3qw" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fU2tI" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fU2n1" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fU2M0" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:2olOl3C1TdP" resolve="dataref1" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fU3Je" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fX_yT" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="2NO6V5fX_Ay" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fXBSS" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fXC4X" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fXABf" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fX_Jw" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fX_CN" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fXAiR" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fXBqQ" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghv9" resolve="hasPersonalUsage" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fU8t3" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="2NO6V5fU8Ky" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fUbeV" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fUbo$" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fU9PI" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fU90I" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fU8U1" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fU9hV" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fUapH" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghvb" resolve="c" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fUaP6" role="lcghm">
                <property role="lacIc" value="," />
              </node>
              <node concept="l9hG8" id="2NO6V5fUcf1" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fUeb2" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fUeb6" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fUdvs" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fUcvX" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fUcpg" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fUdcT" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fUdMo" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghve" resolve="r" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fUf38" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="2NO6V5fUfog" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fUhkv" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fUhkz" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fUgCi" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fUfDW" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fUfzf" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fUgl8" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fUgVe" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghvi" resolve="u" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fUidW" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="2NO6V5fUi$$" role="lcghm">
                <node concept="3cpWs3" id="2NO6V5fUkCX" role="lb14g">
                  <node concept="Xl_RD" id="2NO6V5fUkD1" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="2NO6V5fUjvA" role="3uHU7B">
                    <node concept="2OqwBi" id="2NO6V5fUiR0" role="2Oq$k0">
                      <node concept="2GrUjf" id="2NO6V5fUiKj" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2NO6V5fTG45" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="2NO6V5fUjbP" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="2NO6V5fUjN9" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghvn" resolve="d" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="2NO6V5fUlpu" role="lcghm">
                <property role="lacIc" value=");" />
              </node>
              <node concept="l8MVK" id="2NO6V5fUZmy" role="lcghm" />
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="6vZ7qLQg6K4" role="3cqZAp">
          <node concept="2GrKxI" id="6vZ7qLQg6K5" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="6vZ7qLQg6K6" role="2GsD0m">
            <node concept="117lpO" id="6vZ7qLQg6K7" role="2Oq$k0" />
            <node concept="3Tsc0h" id="6vZ7qLQg6K8" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:6vZ7qLQf1OK" resolve="dataUsedNpd" />
            </node>
          </node>
          <node concept="3clFbS" id="6vZ7qLQg6K9" role="2LFqv$">
            <node concept="3SKdUt" id="6vZ7qLQg6Ka" role="3cqZAp">
              <node concept="1PaTwC" id="6vZ7qLQg6Kb" role="1aUNEU">
                <node concept="3oM_SD" id="6vZ7qLQg6Kc" role="1PaTwD">
                  <property role="3oM_SC" value="Non" />
                </node>
                <node concept="3oM_SD" id="6vZ7qLQg8aR" role="1PaTwD">
                  <property role="3oM_SC" value="personal" />
                </node>
                <node concept="3oM_SD" id="6vZ7qLQg8ac" role="1PaTwD">
                  <property role="3oM_SC" value="data" />
                </node>
              </node>
            </node>
            <node concept="lc7rE" id="6vZ7qLQg6Kf" role="3cqZAp">
              <node concept="la8eA" id="6vZ7qLQg6Kg" role="lcghm">
                <property role="lacIc" value="insert into gdpr_datausage (processing, data, personalStatus, c, r, u, d ) values (" />
              </node>
              <node concept="l9hG8" id="6vZ7qLQg6Kh" role="lcghm">
                <node concept="3cpWs3" id="6vZ7qLQg6Ki" role="lb14g">
                  <node concept="Xl_RD" id="6vZ7qLQg6Kj" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="6vZ7qLQg6Kk" role="3uHU7B">
                    <node concept="117lpO" id="6vZ7qLQg6Kl" role="2Oq$k0" />
                    <node concept="3TrcHB" id="6vZ7qLQg6Km" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:7jX2EUKYYaU" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="6vZ7qLQg6Kn" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="6vZ7qLQg6Ko" role="lcghm">
                <node concept="3cpWs3" id="6vZ7qLQg6Kp" role="lb14g">
                  <node concept="Xl_RD" id="6vZ7qLQg6Kq" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="6vZ7qLQg6Kr" role="3uHU7B">
                    <node concept="2OqwBi" id="6vZ7qLQg6Ks" role="2Oq$k0">
                      <node concept="2GrUjf" id="6vZ7qLQg6Kt" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="6vZ7qLQg6K5" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="6vZ7qLQg6Ku" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:6vZ7qLQf1O8" resolve="dataref2" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="6vZ7qLQg6Kv" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="6vZ7qLQg6Kw" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="6vZ7qLQg6Kx" role="lcghm">
                <node concept="3cpWs3" id="6vZ7qLQg6Ky" role="lb14g">
                  <node concept="Xl_RD" id="6vZ7qLQg6Kz" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="6vZ7qLQg6K$" role="3uHU7B">
                    <node concept="2OqwBi" id="6vZ7qLQg6K_" role="2Oq$k0">
                      <node concept="2GrUjf" id="6vZ7qLQg6KA" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="6vZ7qLQg6K5" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="6vZ7qLQg6KB" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:6vZ7qLQf1Oa" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="6vZ7qLQg6KC" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghv9" resolve="hasPersonalUsage" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="6vZ7qLQg6KD" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="6vZ7qLQg6KE" role="lcghm">
                <node concept="3cpWs3" id="6vZ7qLQg6KF" role="lb14g">
                  <node concept="Xl_RD" id="6vZ7qLQg6KG" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="6vZ7qLQg6KH" role="3uHU7B">
                    <node concept="2OqwBi" id="6vZ7qLQg6KI" role="2Oq$k0">
                      <node concept="2GrUjf" id="6vZ7qLQg6KJ" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="6vZ7qLQg6K5" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="6vZ7qLQg6KK" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:6vZ7qLQf1Oa" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="6vZ7qLQg6KL" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghvb" resolve="c" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="6vZ7qLQg6KM" role="lcghm">
                <property role="lacIc" value="," />
              </node>
              <node concept="l9hG8" id="6vZ7qLQg6KN" role="lcghm">
                <node concept="3cpWs3" id="6vZ7qLQg6KO" role="lb14g">
                  <node concept="Xl_RD" id="6vZ7qLQg6KP" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="6vZ7qLQg6KQ" role="3uHU7B">
                    <node concept="2OqwBi" id="6vZ7qLQg6KR" role="2Oq$k0">
                      <node concept="2GrUjf" id="6vZ7qLQg6KS" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="6vZ7qLQg6K5" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="6vZ7qLQg6KT" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:6vZ7qLQf1Oa" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="6vZ7qLQg6KU" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghve" resolve="r" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="6vZ7qLQg6KV" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="6vZ7qLQg6KW" role="lcghm">
                <node concept="3cpWs3" id="6vZ7qLQg6KX" role="lb14g">
                  <node concept="Xl_RD" id="6vZ7qLQg6KY" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="6vZ7qLQg6KZ" role="3uHU7B">
                    <node concept="2OqwBi" id="6vZ7qLQg6L0" role="2Oq$k0">
                      <node concept="2GrUjf" id="6vZ7qLQg6L1" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="6vZ7qLQg6K5" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="6vZ7qLQg6L2" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:6vZ7qLQf1Oa" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="6vZ7qLQg6L3" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghvi" resolve="u" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="6vZ7qLQg6L4" role="lcghm">
                <property role="lacIc" value=", " />
              </node>
              <node concept="l9hG8" id="6vZ7qLQg6L5" role="lcghm">
                <node concept="3cpWs3" id="6vZ7qLQg6L6" role="lb14g">
                  <node concept="Xl_RD" id="6vZ7qLQg6L7" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="6vZ7qLQg6L8" role="3uHU7B">
                    <node concept="2OqwBi" id="6vZ7qLQg6L9" role="2Oq$k0">
                      <node concept="2GrUjf" id="6vZ7qLQg6La" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="6vZ7qLQg6K5" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="6vZ7qLQg6Lb" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:6vZ7qLQf1Oa" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="6vZ7qLQg6Lc" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghvn" resolve="d" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="6vZ7qLQg6Ld" role="lcghm">
                <property role="lacIc" value=");" />
              </node>
              <node concept="l8MVK" id="6vZ7qLQg6Le" role="lcghm" />
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="6vZ7qLQg6sG" role="3cqZAp" />
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="3WaPWgleQE8">
    <ref role="WuzLi" to="20wa:33K18miOFQF" resolve="DataSubject" />
    <node concept="29tfMY" id="3WaPWgleQE9" role="29tGrW">
      <node concept="3clFbS" id="3WaPWgleQEa" role="2VODD2">
        <node concept="3clFbF" id="3WaPWgleQIL" role="3cqZAp">
          <node concept="2OqwBi" id="3WaPWgleQUR" role="3clFbG">
            <node concept="117lpO" id="3WaPWgleQIK" role="2Oq$k0" />
            <node concept="3TrcHB" id="3WaPWgleR7t" role="2OqNvi">
              <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="3WaPWgleRMT" role="33IsuW">
      <node concept="3clFbS" id="3WaPWgleRMU" role="2VODD2">
        <node concept="3clFbF" id="3WaPWgleRNQ" role="3cqZAp">
          <node concept="Xl_RD" id="3WaPWgleRNP" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="3WaPWgleS0w" role="11c4hB">
      <node concept="3clFbS" id="3WaPWgleS0x" role="2VODD2">
        <node concept="lc7rE" id="3WaPWgleS1P" role="3cqZAp">
          <node concept="la8eA" id="3WaPWgleS29" role="lcghm">
            <property role="lacIc" value="insert into gdpr_datasubject (datasubjectID, userName, age, Country, dsCategory, tutor," />
          </node>
          <node concept="l9hG8" id="IIjfDnTogk" role="lcghm">
            <node concept="2OqwBi" id="IIjfDnToLZ" role="lb14g">
              <node concept="2OqwBi" id="IIjfDnTos2" role="2Oq$k0">
                <node concept="117lpO" id="IIjfDnToro" role="2Oq$k0" />
                <node concept="3TrEf2" id="IIjfDnToD0" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                </node>
              </node>
              <node concept="3TrcHB" id="IIjfDnToXy" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
              </node>
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWgleSff" role="3cqZAp">
          <node concept="la8eA" id="IIjfDnTocD" role="lcghm">
            <property role="lacIc" value=") values(" />
          </node>
          <node concept="l9hG8" id="1PjvIwH_aR2" role="lcghm">
            <node concept="3cpWs3" id="1PjvIwHB6wg" role="lb14g">
              <node concept="Xl_RD" id="1PjvIwHB6wk" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="1PjvIwH_b4o" role="3uHU7B">
                <node concept="117lpO" id="1PjvIwH_aVz" role="2Oq$k0" />
                <node concept="3TrcHB" id="1PjvIwH_bhm" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="1PjvIwH_aIr" role="lcghm">
            <property role="lacIc" value=", '" />
          </node>
          <node concept="l9hG8" id="3WaPWgleSg_" role="lcghm">
            <node concept="2OqwBi" id="3WaPWgleSqn" role="lb14g">
              <node concept="117lpO" id="3WaPWgleShp" role="2Oq$k0" />
              <node concept="3TrcHB" id="3WaPWgleSBl" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgleSF5" role="lcghm">
            <property role="lacIc" value="', " />
          </node>
          <node concept="l9hG8" id="3WaPWgleVkI" role="lcghm">
            <node concept="3cpWs3" id="3WaPWgleWxn" role="lb14g">
              <node concept="Xl_RD" id="3WaPWgleWyu" role="3uHU7w" />
              <node concept="2OqwBi" id="3WaPWgleVu$" role="3uHU7B">
                <node concept="117lpO" id="3WaPWgleVms" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWgleVFy" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:33K18miOFQN" resolve="age" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgleXed" role="lcghm">
            <property role="lacIc" value=",'" />
          </node>
          <node concept="l9hG8" id="3FQc_NktjGG" role="lcghm">
            <node concept="2OqwBi" id="3Oj0nN94Mtz" role="lb14g">
              <node concept="2OqwBi" id="4BkqmtKkp_t" role="2Oq$k0">
                <node concept="2OqwBi" id="3FQc_NktjUF" role="2Oq$k0">
                  <node concept="117lpO" id="3FQc_NktjKp" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3Oj0nN94LBd" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:5TuIUILdRHH" resolve="country" />
                  </node>
                </node>
                <node concept="3TrcHB" id="3Oj0nN94M87" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5TuIUILdRHy" resolve="name" />
                </node>
              </node>
              <node concept="liA8E" id="3Oj0nN94MN1" role="2OqNvi">
                <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3FQc_Nktke0" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWgleXpR" role="lcghm">
            <node concept="2OqwBi" id="3WaPWgleXVU" role="lb14g">
              <node concept="2OqwBi" id="3WaPWgleX$o" role="2Oq$k0">
                <node concept="117lpO" id="3WaPWgleXsg" role="2Oq$k0" />
                <node concept="3TrEf2" id="3WaPWgleXLT" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                </node>
              </node>
              <node concept="3TrcHB" id="7jX2EUL01g_" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgleYwM" role="lcghm">
            <property role="lacIc" value="'," />
          </node>
          <node concept="l9hG8" id="3WaPWglf46G" role="lcghm">
            <node concept="3cpWs3" id="3WaPWglfyG5" role="lb14g">
              <node concept="Xl_RD" id="3WaPWglfyHn" role="3uHU7w" />
              <node concept="2OqwBi" id="3WaPWglfxys" role="3uHU7B">
                <node concept="2OqwBi" id="3WaPWglf4hJ" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWglf49B" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWglf4uH" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:3WaPWgleThq" resolve="tutor" />
                  </node>
                </node>
                <node concept="3TrcHB" id="3WaPWglfxNK" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="IIjfDnTpNE" role="lcghm">
            <property role="lacIc" value=", " />
          </node>
          <node concept="l9hG8" id="IIjfDnTplW" role="lcghm">
            <node concept="2OqwBi" id="IIjfDnTpyu" role="lb14g">
              <node concept="117lpO" id="IIjfDnTppD" role="2Oq$k0" />
              <node concept="3TrcHB" id="IIjfDnTpJs" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:3WaPWgld_8O" resolve="idRef" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglf4_m" role="lcghm">
            <property role="lacIc" value=");" />
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="3WaPWglkpg4">
    <ref role="WuzLi" to="20wa:5VnHNHVg8Bi" resolve="Contract" />
    <node concept="29tfMY" id="3WaPWglkpg5" role="29tGrW">
      <node concept="3clFbS" id="3WaPWglkpg6" role="2VODD2">
        <node concept="3clFbF" id="3WaPWglkpkE" role="3cqZAp">
          <node concept="3cpWs3" id="3WaPWglkqhM" role="3clFbG">
            <node concept="Xl_RD" id="3WaPWglkqiJ" role="3uHU7B">
              <property role="Xl_RC" value="contract" />
            </node>
            <node concept="2OqwBi" id="3WaPWglkpQ9" role="3uHU7w">
              <node concept="2OqwBi" id="3WaPWglkpyg" role="2Oq$k0">
                <node concept="117lpO" id="3WaPWglkpkD" role="2Oq$k0" />
                <node concept="3TrEf2" id="3WaPWglkpDq" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:51XxSBB41yU" resolve="dataSubject" />
                </node>
              </node>
              <node concept="3TrcHB" id="3WaPWglkq4C" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="3WaPWglkqox" role="33IsuW">
      <node concept="3clFbS" id="3WaPWglkqoy" role="2VODD2">
        <node concept="3clFbF" id="3WaPWglkqAj" role="3cqZAp">
          <node concept="Xl_RD" id="3WaPWglkqAi" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="3WaPWglkqCS" role="11c4hB">
      <node concept="3clFbS" id="3WaPWglkqCT" role="2VODD2">
        <node concept="3clFbH" id="3WaPWglkr29" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglkssC" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglksut" role="lcghm">
            <property role="lacIc" value="insert into gdpr_contract (datasubject, signaturedate, expirationdate) values ('" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglksyz" role="3cqZAp">
          <node concept="l9hG8" id="3WaPWglksTs" role="lcghm">
            <node concept="3cpWs3" id="7McLYwdJRBo" role="lb14g">
              <node concept="Xl_RD" id="7McLYwdJRBC" role="3uHU7w" />
              <node concept="2OqwBi" id="7McLYwdJQFf" role="3uHU7B">
                <node concept="2OqwBi" id="3WaPWglkt1Y" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWglksUj" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWglkt9_" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:51XxSBB41yU" resolve="dataSubject" />
                  </node>
                </node>
                <node concept="3TrcHB" id="7McLYwdJQUa" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglkteb" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWglktgm" role="lcghm">
            <node concept="3cpWs3" id="3WaPWglkui8" role="lb14g">
              <node concept="Xl_RD" id="3WaPWglkuic" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="3WaPWglktik" role="3uHU7B">
                <node concept="117lpO" id="3WaPWglkthD" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWglktjZ" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5VnHNHVg8Bl" resolve="Signaturedate" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglkwYy" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWglkuy3" role="lcghm">
            <node concept="3cpWs3" id="3WaPWglkLhl" role="lb14g">
              <node concept="Xl_RD" id="3WaPWglkLhp" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="3WaPWglkuFv" role="3uHU7B">
                <node concept="117lpO" id="3WaPWglku$0" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWglkwvX" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5VnHNHVg8BP" resolve="Expirationdate" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgllDVq" role="lcghm">
            <property role="lacIc" value="');" />
          </node>
        </node>
        <node concept="3clFbH" id="3WaPWgloUID" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWgllE39" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWgllE8J" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWgloocA" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWgloUb2" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWglpki2" role="3cqZAp" />
        <node concept="2Gpval" id="3WaPWglkrnq" role="3cqZAp">
          <node concept="2GrKxI" id="3WaPWglkrnr" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="3WaPWglkrns" role="2GsD0m">
            <node concept="117lpO" id="3WaPWglkrnt" role="2Oq$k0" />
            <node concept="3Tsc0h" id="3WaPWglkr$n" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:5VnHNHVgh90" resolve="consent" />
            </node>
          </node>
          <node concept="3clFbS" id="3WaPWglkrnv" role="2LFqv$">
            <node concept="lc7rE" id="3WaPWglkrnw" role="3cqZAp">
              <node concept="la8eA" id="3WaPWglkrnx" role="lcghm">
                <property role="lacIc" value="insert into gdpr_consent(datasubject, contract, processing, startdate, enddate) values ('" />
              </node>
              <node concept="l9hG8" id="3WaPWglk_YU" role="lcghm">
                <node concept="3cpWs3" id="7McLYwdJPR0" role="lb14g">
                  <node concept="Xl_RD" id="7McLYwdJPR4" role="3uHU7w" />
                  <node concept="2OqwBi" id="7McLYwdJOJO" role="3uHU7B">
                    <node concept="2OqwBi" id="3WaPWglkA8A" role="2Oq$k0">
                      <node concept="117lpO" id="3WaPWglkA01" role="2Oq$k0" />
                      <node concept="3TrEf2" id="3WaPWglkAgd" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:51XxSBB41yU" resolve="dataSubject" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="7McLYwdJOYJ" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3WaPWglpkK8" role="lcghm">
                <property role="lacIc" value="', " />
              </node>
              <node concept="l9hG8" id="3WaPWglkAmQ" role="lcghm">
                <node concept="3cpWs3" id="3WaPWglkJQw" role="lb14g">
                  <node concept="Xl_RD" id="3WaPWglkJQ$" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="3WaPWglkAp3" role="3uHU7B">
                    <node concept="117lpO" id="3WaPWglkAoo" role="2Oq$k0" />
                    <node concept="3TrcHB" id="3WaPWglkIYR" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:3WaPWglkAyp" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3WaPWglpkOa" role="lcghm">
                <property role="lacIc" value=", '" />
              </node>
              <node concept="l9hG8" id="3WaPWglkrny" role="lcghm">
                <node concept="3cpWs3" id="7jX2EUKZ85g" role="lb14g">
                  <node concept="Xl_RD" id="7jX2EUKZ8o5" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="3WaPWglpJe7" role="3uHU7B">
                    <node concept="2OqwBi" id="3WaPWglpI9_" role="2Oq$k0">
                      <node concept="2OqwBi" id="3WaPWglkrnz" role="2Oq$k0">
                        <node concept="2GrUjf" id="3WaPWglkrn$" role="2Oq$k0">
                          <ref role="2Gs0qQ" node="3WaPWglkrnr" resolve="e" />
                        </node>
                        <node concept="3TrEf2" id="3WaPWglk$xi" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:5VnHNHVgh95" resolve="processing" />
                        </node>
                      </node>
                      <node concept="3TrEf2" id="3WaPWglpIUg" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:2ry5VKd0yKm" resolve="processing" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="7jX2EUKZ7dr" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:7jX2EUKYYaU" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3WaPWglkrnA" role="lcghm">
                <property role="lacIc" value="', '" />
              </node>
              <node concept="l9hG8" id="3WaPWglkrnB" role="lcghm">
                <node concept="2OqwBi" id="3WaPWglkrnC" role="lb14g">
                  <node concept="2GrUjf" id="3WaPWglkrnE" role="2Oq$k0">
                    <ref role="2Gs0qQ" node="3WaPWglkrnr" resolve="e" />
                  </node>
                  <node concept="3TrcHB" id="3WaPWglk$D7" role="2OqNvi">
                    <ref role="3TsBF5" to="20wa:5VnHNHVgh9$" resolve="startDate" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3WaPWglkrnF" role="lcghm">
                <property role="lacIc" value="', '" />
              </node>
              <node concept="l9hG8" id="3WaPWglk_nK" role="lcghm">
                <node concept="2OqwBi" id="3WaPWglk_vj" role="lb14g">
                  <node concept="2GrUjf" id="3WaPWglk_oM" role="2Oq$k0">
                    <ref role="2Gs0qQ" node="3WaPWglkrnr" resolve="e" />
                  </node>
                  <node concept="3TrcHB" id="3WaPWglk_Vg" role="2OqNvi">
                    <ref role="3TsBF5" to="20wa:5VnHNHVgh9A" resolve="endDate" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3WaPWglk_X_" role="lcghm">
                <property role="lacIc" value="');" />
              </node>
            </node>
            <node concept="lc7rE" id="3WaPWgllE9$" role="3cqZAp">
              <node concept="l8MVK" id="3WaPWgllEbk" role="lcghm" />
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="3WaPWglkrn9" role="3cqZAp" />
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="w$4DGO$wJ4">
    <ref role="WuzLi" to="20wa:w$4DGO$wJ3" resolve="PRIAM_GDPR" />
    <node concept="9MYSb" id="w$4DGO$wJ5" role="33IsuW">
      <node concept="3clFbS" id="w$4DGO$wJ6" role="2VODD2">
        <node concept="3clFbF" id="7bfLM_U7AOW" role="3cqZAp">
          <node concept="Xl_RD" id="7bfLM_U7AOV" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="w$4DGO$wNH" role="11c4hB">
      <node concept="3clFbS" id="w$4DGO$wNI" role="2VODD2">
        <node concept="3clFbH" id="3FQc_NkmzJ3" role="3cqZAp" />
        <node concept="lc7rE" id="1PjvIwH_clc" role="3cqZAp">
          <node concept="la8eA" id="1PjvIwH_cld" role="lcghm">
            <property role="lacIc" value="-- Personal Data Category annotation table creation" />
          </node>
          <node concept="l8MVK" id="1PjvIwH_cle" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1PjvIwH_ccY" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur7cv" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur7hD" role="lcghm">
            <property role="lacIc" value="create table gdpr_PersonalDataCategory(" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_P_" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur7oE" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur7tQ" role="lcghm">
            <property role="lacIc" value="PDCategoryID int primary key," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_Qc" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur7O3" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur7Tk" role="lcghm">
            <property role="lacIc" value="personalDataCategory varchar(150));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_QN" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur7u9" role="3cqZAp" />
        <node concept="3clFbH" id="3casRoZzpob" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7tXA" role="3cqZAp">
          <node concept="l8MVK" id="7bfLM_U7tXB" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7tsz" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7ts$" role="lcghm">
            <property role="lacIc" value="-- Data Annotation table Creation --" />
          </node>
          <node concept="l8MVK" id="1ZMIcpur2Xw" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur32e" role="3cqZAp" />
        <node concept="lc7rE" id="3FQc_NkmyZz" role="3cqZAp">
          <node concept="l8MVK" id="3FQc_Nkmzb4" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3FQc_NkmznP" role="3cqZAp">
          <node concept="la8eA" id="3FQc_Nkmzv_" role="lcghm">
            <property role="lacIc" value="-- DataType table creation" />
          </node>
          <node concept="l8MVK" id="40yFoui0RF_" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3FQc_NkmzUz" role="3cqZAp">
          <node concept="la8eA" id="3FQc_Nkm$2n" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataType (" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_Rq" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3FQc_Nkm$g4" role="3cqZAp">
          <node concept="la8eA" id="3FQc_Nkm$nU" role="lcghm">
            <property role="lacIc" value="dataTypeName varchar(40) primary key);" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_S1" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3FQc_NkmzCp" role="3cqZAp" />
        <node concept="lc7rE" id="40yFouhZGKW" role="3cqZAp">
          <node concept="l8MVK" id="40yFouhZGWO" role="lcghm" />
        </node>
        <node concept="lc7rE" id="40yFoui1yxU" role="3cqZAp">
          <node concept="la8eA" id="40yFoui1yxV" role="lcghm">
            <property role="lacIc" value="-- Data table creation" />
          </node>
          <node concept="l8MVK" id="40yFoui1yxW" role="lcghm" />
        </node>
        <node concept="3clFbH" id="40yFoui1ypG" role="3cqZAp" />
        <node concept="3clFbH" id="40yFouhZGX7" role="3cqZAp" />
        <node concept="lc7rE" id="w$4DGO$wOn" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wOo" role="lcghm">
            <property role="lacIc" value="create table gdpr_Data( " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_SC" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglmrU$" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglms0s" role="lcghm">
            <property role="lacIc" value="dataID int primary key," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_Tf" role="lcghm" />
        </node>
        <node concept="1X3_iC" id="3casRoZyJau" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="w$4DGO$wOt" role="8Wnug">
            <node concept="la8eA" id="w$4DGO$wOu" role="lcghm">
              <property role="lacIc" value="attributeName varchar(25), " />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="w$4DGO$wOz" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wO$" role="lcghm">
            <property role="lacIc" value="dataSource varchar(25) check  (dataSource in('Direct', 'Indirect', 'Produced')), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_TQ" role="lcghm" />
        </node>
        <node concept="lc7rE" id="w$4DGO$wOA" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wOB" role="lcghm">
            <property role="lacIc" value="dataConservation int, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_Ut" role="lcghm" />
        </node>
        <node concept="lc7rE" id="w$4DGO$wOD" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wOE" role="lcghm">
            <property role="lacIc" value="isPersonal boolean," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_V4" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdUWC" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdUWD" role="lcghm">
            <property role="lacIc" value="isPortable boolean," />
          </node>
          <node concept="l8MVK" id="5TuIUILdUWE" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3FQc_Nkm_4P" role="3cqZAp">
          <node concept="la8eA" id="3FQc_Nkm_4Q" role="lcghm">
            <property role="lacIc" value="dataTypeName varchar(40)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_VF" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur6Ul" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur6Zs" role="lcghm">
            <property role="lacIc" value="personalDataCategory int," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_Wi" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3FQc_Nkm$yG" role="3cqZAp">
          <node concept="la8eA" id="3FQc_Nkm$yH" role="lcghm">
            <property role="lacIc" value="foreign key (dataTypeName) references gdpr_DataType(dataTypeName)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_WT" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w3Yu" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w3Yv" role="lcghm">
            <property role="lacIc" value="foreign key(personalDataCategory) references gdpr_PersonalDataCategory(PDCategoryID));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_Xw" role="lcghm" />
        </node>
        <node concept="1X3_iC" id="6vZ7qLQib6y" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="23QIlu3v35F" role="8Wnug">
            <node concept="la8eA" id="23QIlu3v3bz" role="lcghm">
              <property role="lacIc" value="constraint const1 check  (source in ('Direct', 'Indirect', 'Produced')));" />
            </node>
            <node concept="l8MVK" id="23QIlu3vZHN" role="lcghm" />
          </node>
        </node>
        <node concept="3clFbH" id="w$4DGO$wPT" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7tar" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7tcz" role="lcghm">
            <property role="lacIc" value="-- Processing Annotation table Creation --" />
          </node>
          <node concept="l8MVK" id="1ZMIcpur2Su" role="lcghm" />
        </node>
        <node concept="3clFbH" id="7bfLM_U7ti7" role="3cqZAp" />
        <node concept="lc7rE" id="2yHMJEzijGW" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzijSu" role="lcghm">
            <property role="lacIc" value="create table gdpr_context (" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_Y7" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2yHMJEzik2v" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzike3" role="lcghm">
            <property role="lacIc" value="environmentName varchar(100) primary key);" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_YI" role="lcghm" />
        </node>
        <node concept="3clFbH" id="2yHMJEzikil" role="3cqZAp" />
        <node concept="lc7rE" id="2yHMJEzik_H" role="3cqZAp">
          <node concept="l8MVK" id="2yHMJEzikLk" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2yHMJEzikTy" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzil1$" role="lcghm">
            <property role="lacIc" value="create table gdpr_ontology (" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_Zl" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2yHMJEzilen" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzilmr" role="lcghm">
            <property role="lacIc" value="ontologyName varchar(100) primary key, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYU_ZW" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2yHMJEzilvz" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzilFg" role="lcghm">
            <property role="lacIc" value="context varchar(100), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAlx" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2yHMJEzilSO" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzim0W" role="lcghm">
            <property role="lacIc" value="foreign key (context) references gdpr_Context(environmentName));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAmD" role="lcghm" />
        </node>
        <node concept="3clFbH" id="2yHMJEzimhO" role="3cqZAp" />
        <node concept="lc7rE" id="2yHMJEziol1" role="3cqZAp">
          <node concept="l8MVK" id="2yHMJEziotj" role="lcghm" />
        </node>
        <node concept="3clFbH" id="2yHMJEzinSR" role="3cqZAp" />
        <node concept="lc7rE" id="w$4DGO$wR4" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wR5" role="lcghm">
            <property role="lacIc" value="create table gdpr_Processing (" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAng" role="lcghm" />
        </node>
        <node concept="lc7rE" id="w$4DGO$wR7" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wR8" role="lcghm">
            <property role="lacIc" value="processingID int primary key , " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAnR" role="lcghm" />
        </node>
        <node concept="lc7rE" id="w$4DGO$wRa" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wRb" role="lcghm">
            <property role="lacIc" value="processingName varchar(25), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAou" role="lcghm" />
        </node>
        <node concept="lc7rE" id="w$4DGO$wRd" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wRe" role="lcghm">
            <property role="lacIc" value="processingType varchar(25) check (processingType in('Default','Mandatory','Optional', 'Necessary')), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAp5" role="lcghm" />
        </node>
        <node concept="lc7rE" id="w$4DGO$wRg" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wRh" role="lcghm">
            <property role="lacIc" value="processingCategory varchar(25) check (processingCategory in('Consent_Contract','Legitimate interest','Legal Obligation','Public interest','Vital interest')), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUApG" role="lcghm" />
        </node>
        <node concept="lc7rE" id="w$4DGO$wRj" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wRk" role="lcghm">
            <property role="lacIc" value="creationDate date, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAqj" role="lcghm" />
        </node>
        <node concept="lc7rE" id="w$4DGO$wRm" role="3cqZAp">
          <node concept="la8eA" id="w$4DGO$wRn" role="lcghm">
            <property role="lacIc" value="updatingDate date," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAqU" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3FQc_NkmyeB" role="3cqZAp">
          <node concept="la8eA" id="3FQc_NkmyeC" role="lcghm">
            <property role="lacIc" value="isService boolean," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUArx" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2yHMJEzind9" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzinda" role="lcghm">
            <property role="lacIc" value="context varchar(100), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAs8" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2yHMJEzimWQ" role="3cqZAp">
          <node concept="la8eA" id="2yHMJEzimWR" role="lcghm">
            <property role="lacIc" value="foreign key (context) references gdpr_Context(environmentName)); " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAsJ" role="lcghm" />
        </node>
        <node concept="1X3_iC" id="6vZ7qLQibp8" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="23QIlu3vZOA" role="8Wnug">
            <node concept="la8eA" id="23QIlu3vZOB" role="lcghm">
              <property role="lacIc" value="constraint const1 check (processingType in('Default','Mandatory','Optional', 'Necessary'))," />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUAtm" role="lcghm" />
          </node>
        </node>
        <node concept="1X3_iC" id="6vZ7qLQibE$" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="23QIlu3w06X" role="8Wnug">
            <node concept="la8eA" id="23QIlu3w06Y" role="lcghm">
              <property role="lacIc" value="constraint const2 check (processingCategory in('Consent_Contract','Legitimate interest','Legal Obligation','Public interest','Vital interest')));" />
            </node>
            <node concept="l8MVK" id="23QIlu3w06Z" role="lcghm" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3vZIN" role="3cqZAp" />
        <node concept="lc7rE" id="5TuIUILdVAr" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdVAs" role="lcghm">
            <property role="lacIc" value="create table gdpr_Measure (" />
          </node>
          <node concept="l8MVK" id="5TuIUILdVAt" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdVAu" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdVAv" role="lcghm">
            <property role="lacIc" value="measureID int primary key , " />
          </node>
          <node concept="l8MVK" id="5TuIUILdVAw" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdVAx" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdVAy" role="lcghm">
            <property role="lacIc" value="description varchar(255), " />
          </node>
          <node concept="l8MVK" id="5TuIUILdVAz" role="lcghm" />
        </node>
        <node concept="lc7rE" id="6vZ7qLQic7V" role="3cqZAp">
          <node concept="la8eA" id="6vZ7qLQic7W" role="lcghm">
            <property role="lacIc" value="measureType varchar(15) check (measureType in('Organisational','Technical')), " />
          </node>
          <node concept="l8MVK" id="6vZ7qLQic7X" role="lcghm" />
        </node>
        <node concept="lc7rE" id="6vZ7qLQicA7" role="3cqZAp">
          <node concept="la8eA" id="6vZ7qLQicA8" role="lcghm">
            <property role="lacIc" value="measureCategory varchar(20) check (measureCategory in('Cryption','Anonymisation'))); " />
          </node>
          <node concept="l8MVK" id="6vZ7qLQicA9" role="lcghm" />
        </node>
        <node concept="1X3_iC" id="6vZ7qLQidjK" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="5TuIUILdVAT" role="8Wnug">
            <node concept="la8eA" id="5TuIUILdVAU" role="lcghm">
              <property role="lacIc" value="constraint const3 check (measureType in('Organisational','Technical'))," />
            </node>
            <node concept="l8MVK" id="5TuIUILdVAV" role="lcghm" />
          </node>
        </node>
        <node concept="1X3_iC" id="6vZ7qLQid$Q" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="5TuIUILdVAW" role="8Wnug">
            <node concept="la8eA" id="5TuIUILdVAX" role="lcghm">
              <property role="lacIc" value="constraint const4 check (measureCategory in('Cryption','Anonymisation')));" />
            </node>
            <node concept="l8MVK" id="5TuIUILdVAY" role="lcghm" />
          </node>
        </node>
        <node concept="3clFbH" id="5TuIUILdVnR" role="3cqZAp" />
        <node concept="3clFbH" id="2yHMJEzim5e" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqV7K" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpuqVay" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqUYE" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqV1o" role="lcghm">
            <property role="lacIc" value="create table gdpr_Purpose (" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUAtX" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqVmx" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVmy" role="lcghm">
            <property role="lacIc" value="purposeID int primary key auto_increment, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBif" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqV51" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqV52" role="lcghm">
            <property role="lacIc" value="description varchar(200) not null," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBvq" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqVdy" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVgm" role="lcghm">
            <property role="lacIc" value="type varchar(10) check(type in('Main', 'Secondary')) ," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBw1" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqVjo" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVme" role="lcghm">
            <property role="lacIc" value="processing int," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBwC" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w0rb" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w0rc" role="lcghm">
            <property role="lacIc" value="foreign key (processing) references  gdpr_Processing(processingID));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBxf" role="lcghm" />
        </node>
        <node concept="1X3_iC" id="6vZ7qLQidNw" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="23QIlu3w8VW" role="8Wnug">
            <node concept="la8eA" id="23QIlu3w8VX" role="lcghm">
              <property role="lacIc" value="constraint const1 check(type in('Main', 'Secondary')));" />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUBxQ" role="lcghm" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3w92E" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqVyX" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpuqV_R" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMut0f" role="3cqZAp">
          <node concept="l8MVK" id="ML4nhMut0g" role="lcghm" />
        </node>
        <node concept="3clFbH" id="23QIlu3w9n2" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqVCZ" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVG8" role="lcghm">
            <property role="lacIc" value="create table gdpr_ProcessingLink(" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUByt" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqVL9" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVO7" role="lcghm">
            <property role="lacIc" value="processing1 int, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBz4" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqVSK" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqVVK" role="lcghm">
            <property role="lacIc" value="processing2 int, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBzF" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqW0o" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqW3q" role="lcghm">
            <property role="lacIc" value="typeLink varchar(20)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUB$i" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqW6E" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqW9I" role="lcghm">
            <property role="lacIc" value="primary key(processing1, processing2)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUB$T" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w8vR" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w8Az" role="lcghm">
            <property role="lacIc" value="foreign key (processing1) references  gdpr_Processing(processingID)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUB_w" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w8Ip" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w8Iq" role="lcghm">
            <property role="lacIc" value="foreign key (processing2) references  gdpr_Processing(processingID)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBA7" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w0Es" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w0Et" role="lcghm">
            <property role="lacIc" value="constraint const1 check (typelink in('SimilarityLink', 'IndusionLink', 'AgregationLink')));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBAI" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpuqV2o" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqWr5" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpuqWr6" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1PjvIwH_bTS" role="3cqZAp" />
        <node concept="3clFbH" id="1PjvIwH_c12" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqWEJ" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqWHX" role="lcghm">
            <property role="lacIc" value="-- actors creation ---" />
          </node>
          <node concept="l8MVK" id="1ZMIcpur2RR" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpuqZX7" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpur2Eb" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur0Jf" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur0Np" role="lcghm">
            <property role="lacIc" value="-- Creation of static table Country --" />
          </node>
          <node concept="l8MVK" id="1ZMIcpusvWE" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpusvWY" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur04I" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur08J" role="lcghm">
            <property role="lacIc" value="create Table gdpr_Country( " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBBl" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur0o$" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur0sD" role="lcghm">
            <property role="lacIc" value="countryName varchar(100) primary key," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBBW" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdUtB" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdUtC" role="lcghm">
            <property role="lacIc" value="minorAge int);" />
          </node>
          <node concept="l8MVK" id="5TuIUILdUtD" role="lcghm" />
        </node>
        <node concept="3clFbH" id="5TuIUILdUk7" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpur0vx" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur2_G" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpur2_H" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur2xj" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqWMN" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqWQ3" role="lcghm">
            <property role="lacIc" value="create table gdpr_Provider(" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBCz" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqX9D" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXcX" role="lcghm">
            <property role="lacIc" value="providerID int primary key auto_increment," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBDa" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXi8" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXlu" role="lcghm">
            <property role="lacIc" value="prName varchar(40) not null," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBDL" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqY5N" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqY5O" role="lcghm">
            <property role="lacIc" value="username varchar(25), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBEo" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXr9" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXra" role="lcghm">
            <property role="lacIc" value="prAdress varchar(250) not null," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBEZ" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXyx" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXyy" role="lcghm">
            <property role="lacIc" value="prPostalCode varchar(40)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBFA" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXEt" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXEu" role="lcghm">
            <property role="lacIc" value="city varchar(40)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBGd" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXM1" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXM2" role="lcghm">
            <property role="lacIc" value="prPhone varchar(40)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBGO" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqXTF" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqXTG" role="lcghm">
            <property role="lacIc" value="prEmail varchar(40), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBHr" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqZxg" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqZ_m" role="lcghm">
            <property role="lacIc" value="country varchar(100), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBI2" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w0Zo" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w15v" role="lcghm">
            <property role="lacIc" value="foreign key(country) references gdpr_Country(countryName));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBID" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpuqXQe" role="3cqZAp" />
        <node concept="lc7rE" id="3Oj0nN93MjS" role="3cqZAp">
          <node concept="l8MVK" id="3Oj0nN93MjT" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3Oj0nN93MjU" role="3cqZAp" />
        <node concept="lc7rE" id="3Oj0nN93MjV" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93MjW" role="lcghm">
            <property role="lacIc" value="create table gdpr_DPO(" />
          </node>
          <node concept="l8MVK" id="3Oj0nN93MjX" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3Oj0nN93MjY" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93MjZ" role="lcghm">
            <property role="lacIc" value="dpID int primary key auto_increment," />
          </node>
          <node concept="l8MVK" id="3Oj0nN93Mk0" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3Oj0nN93Mk1" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93Mk2" role="lcghm">
            <property role="lacIc" value="dpName varchar(40) not null," />
          </node>
          <node concept="l8MVK" id="3Oj0nN93Mk3" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3Oj0nN93Mk4" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93Mk5" role="lcghm">
            <property role="lacIc" value="username varchar(25), " />
          </node>
          <node concept="l8MVK" id="3Oj0nN93Mk6" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3Oj0nN93Mk7" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93Mk8" role="lcghm">
            <property role="lacIc" value="dpAdress varchar(250) not null," />
          </node>
          <node concept="l8MVK" id="3Oj0nN93Mk9" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3Oj0nN93Mka" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93Mkb" role="lcghm">
            <property role="lacIc" value="dpPostalCode varchar(40)," />
          </node>
          <node concept="l8MVK" id="3Oj0nN93Mkc" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3Oj0nN93Mkd" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93Mke" role="lcghm">
            <property role="lacIc" value="city varchar(40)," />
          </node>
          <node concept="l8MVK" id="3Oj0nN93Mkf" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3Oj0nN93Mkg" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93Mkh" role="lcghm">
            <property role="lacIc" value="dpPhone varchar(40)," />
          </node>
          <node concept="l8MVK" id="3Oj0nN93Mki" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3Oj0nN93Mkj" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93Mkk" role="lcghm">
            <property role="lacIc" value="dpEmail varchar(40), " />
          </node>
          <node concept="l8MVK" id="3Oj0nN93Mkl" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3Oj0nN93Mkm" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93Mkn" role="lcghm">
            <property role="lacIc" value="country varchar(100), " />
          </node>
          <node concept="l8MVK" id="3Oj0nN93Mko" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3Oj0nN93Mkp" role="3cqZAp">
          <node concept="la8eA" id="3Oj0nN93Mkq" role="lcghm">
            <property role="lacIc" value="foreign key(country) references gdpr_Country(countryName));" />
          </node>
          <node concept="l8MVK" id="3Oj0nN93Mkr" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3Oj0nN93M45" role="3cqZAp" />
        <node concept="lc7rE" id="3Oj0nN93LK6" role="3cqZAp">
          <node concept="l8MVK" id="3Oj0nN93LK7" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3Oj0nN93LK8" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpuqYeG" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYeH" role="lcghm">
            <property role="lacIc" value="create table gdpr_Tutor(" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBJg" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqYeI" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYeJ" role="lcghm">
            <property role="lacIc" value="tutorID int primary key auto_increment," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBJR" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqYeK" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYeL" role="lcghm">
            <property role="lacIc" value="tutorName varchar(40) not null," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBKu" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqYeM" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqYeN" role="lcghm">
            <property role="lacIc" value="username varchar(25), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBL5" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpuqZGW" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpuqZGX" role="lcghm">
            <property role="lacIc" value="country varchar(100), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBLG" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w1nE" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w1nF" role="lcghm">
            <property role="lacIc" value="foreign key(country) references gdpr_Country(countryName));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUBMj" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpuqZCV" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur2fO" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpur2fP" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur2kc" role="3cqZAp" />
        <node concept="1X3_iC" id="63QyxWZ9DH7" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="1ZMIcpur1eR" role="8Wnug">
            <node concept="la8eA" id="1ZMIcpur1eS" role="lcghm">
              <property role="lacIc" value="create table gdpr_DataConsumerCategory(" />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUC0q" role="lcghm" />
          </node>
        </node>
        <node concept="1X3_iC" id="63QyxWZ9DH8" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="1ZMIcpur1eT" role="8Wnug">
            <node concept="la8eA" id="1ZMIcpur1eU" role="lcghm">
              <property role="lacIc" value="dcCategoryID int primary key auto_increment," />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUC11" role="lcghm" />
          </node>
        </node>
        <node concept="1X3_iC" id="63QyxWZ9DH9" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="1ZMIcpur1eV" role="8Wnug">
            <node concept="la8eA" id="1ZMIcpur1eW" role="lcghm">
              <property role="lacIc" value="dcCategoryName varchar(40) );" />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUC1C" role="lcghm" />
          </node>
        </node>
        <node concept="lc7rE" id="63QyxWZ9DYa" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9DYb" role="lcghm">
            <property role="lacIc" value="create table gdpr_SecondaryActorCategory(" />
          </node>
          <node concept="l8MVK" id="63QyxWZ9DYc" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9DYd" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9DYe" role="lcghm">
            <property role="lacIc" value="saCategoryID int primary key auto_increment," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9DYf" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9DYg" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9DYh" role="lcghm">
            <property role="lacIc" value="saCategoryName varchar(40));" />
          </node>
          <node concept="l8MVK" id="63QyxWZ9DYi" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur1Mg" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur22U" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpur22V" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpuqYoF" role="3cqZAp" />
        <node concept="1X3_iC" id="63QyxWZ9CjY" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="1ZMIcpuqYwa" role="8Wnug">
            <node concept="la8eA" id="1ZMIcpuqYwb" role="lcghm">
              <property role="lacIc" value="create table gdpr_DataConsumer(" />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUC2f" role="lcghm" />
          </node>
        </node>
        <node concept="1X3_iC" id="63QyxWZ9CjZ" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="1ZMIcpuqYwc" role="8Wnug">
            <node concept="la8eA" id="1ZMIcpuqYwd" role="lcghm">
              <property role="lacIc" value="dataConsumerID int primary key auto_increment," />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUC2Q" role="lcghm" />
          </node>
        </node>
        <node concept="1X3_iC" id="63QyxWZ9Ck0" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="1ZMIcpuqYwe" role="8Wnug">
            <node concept="la8eA" id="1ZMIcpuqYwf" role="lcghm">
              <property role="lacIc" value="dconsumerName varchar(40) not null," />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUC3t" role="lcghm" />
          </node>
        </node>
        <node concept="1X3_iC" id="63QyxWZ9Ck1" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="1ZMIcpur1n_" role="8Wnug">
            <node concept="la8eA" id="1ZMIcpur1nA" role="lcghm">
              <property role="lacIc" value="dcCategory int," />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUC44" role="lcghm" />
          </node>
        </node>
        <node concept="1X3_iC" id="63QyxWZ9Ck2" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="1ZMIcpuqZTb" role="8Wnug">
            <node concept="la8eA" id="1ZMIcpuqZTc" role="lcghm">
              <property role="lacIc" value="country varchar(100)," />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUC4F" role="lcghm" />
          </node>
        </node>
        <node concept="1X3_iC" id="63QyxWZ9Ck3" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="23QIlu3w2hj" role="8Wnug">
            <node concept="la8eA" id="23QIlu3w2hk" role="lcghm">
              <property role="lacIc" value="foreign key(dcCategory) references gdpr_DataConsumerCategory(dcCategoryID)," />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUC5i" role="lcghm" />
          </node>
        </node>
        <node concept="1X3_iC" id="63QyxWZ9Ck4" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="23QIlu3w1_0" role="8Wnug">
            <node concept="la8eA" id="23QIlu3w1_1" role="lcghm">
              <property role="lacIc" value="foreign key(country) references gdpr_Country(countryName));" />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUC5T" role="lcghm" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3w1uW" role="3cqZAp" />
        <node concept="lc7rE" id="63QyxWZ9C$Q" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9C$R" role="lcghm">
            <property role="lacIc" value="create table gdpr_SecondaryActor(" />
          </node>
          <node concept="l8MVK" id="63QyxWZ9C$S" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9C$T" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9C$U" role="lcghm">
            <property role="lacIc" value="secondaryActorID int primary key auto_increment," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9C$V" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9Dck" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9Dcl" role="lcghm">
            <property role="lacIc" value="saType varchar(40) check(saType in('DataConsumer', 'DataProcessor', 'ThirdParty'))," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9Dcm" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9C$W" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9C$X" role="lcghm">
            <property role="lacIc" value="saName varchar(40) not null," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9C$Y" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9Gnl" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9Gnm" role="lcghm">
            <property role="lacIc" value="saAdress varchar(250) not null," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9Gnn" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9Gno" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9Gnp" role="lcghm">
            <property role="lacIc" value="saPostalCode varchar(40)," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9Gnq" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9Gnr" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9Gns" role="lcghm">
            <property role="lacIc" value="city varchar(40)," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9Gnt" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9Gnu" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9Gnv" role="lcghm">
            <property role="lacIc" value="saPhone varchar(40)," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9Gnw" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9Gnx" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9Gny" role="lcghm">
            <property role="lacIc" value="saEmail varchar(40), " />
          </node>
          <node concept="l8MVK" id="63QyxWZ9Gnz" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9H9I" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9H9J" role="lcghm">
            <property role="lacIc" value="garanties varchar(255), " />
          </node>
          <node concept="l8MVK" id="63QyxWZ9H9K" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9C$Z" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9C_0" role="lcghm">
            <property role="lacIc" value="saCategory int," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9C_1" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9C_2" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9C_3" role="lcghm">
            <property role="lacIc" value="country varchar(100)," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9C_4" role="lcghm" />
        </node>
        <node concept="lc7rE" id="63QyxWZ9C_5" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9C_6" role="lcghm">
            <property role="lacIc" value="foreign key(saCategory) references gdpr_SecondaryActorCategory(saCategoryID)," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9C_7" role="lcghm" />
        </node>
        <node concept="1X3_iC" id="6vZ7qLQie6e" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="63QyxWZ9F$3" role="8Wnug">
            <node concept="la8eA" id="63QyxWZ9F$4" role="lcghm">
              <property role="lacIc" value="constraint const6 check(saType in('DataConsumer', 'DataProcessor', 'ThirdParty')));" />
            </node>
            <node concept="l8MVK" id="63QyxWZ9F$5" role="lcghm" />
          </node>
        </node>
        <node concept="lc7rE" id="63QyxWZ9C_8" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9C_9" role="lcghm">
            <property role="lacIc" value="foreign key(country) references gdpr_Country(countryName));" />
          </node>
          <node concept="l8MVK" id="63QyxWZ9C_a" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpuqZPl" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpuqYsq" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7t_k" role="3cqZAp">
          <node concept="l8MVK" id="7bfLM_U7t_l" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7t_h" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7t_i" role="lcghm">
            <property role="lacIc" value="-- DataSubject table gdpr_Creation --" />
          </node>
          <node concept="l8MVK" id="7bfLM_U7t_j" role="lcghm" />
        </node>
        <node concept="3clFbH" id="7bfLM_U7u88" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcnDh" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcnDi" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataSubjectCategory (" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUC6w" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglcnDj" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcnDk" role="lcghm">
            <property role="lacIc" value="dsCategory varchar(25) primary key , " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUC77" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglcnDl" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcnDm" role="lcghm">
            <property role="lacIc" value="locationID varchar(40));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUC7I" role="lcghm" />
        </node>
        <node concept="3clFbH" id="23QIlu3w1SC" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcnDt" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcnDu" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglcnDv" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcpao" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcpap" role="lcghm">
            <property role="lacIc" value="insert into gdpr_DatasubjectCategory (locationID, dsCategory) values ('" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCdc" role="lcghm" />
          <node concept="l9hG8" id="5Erw5yf9OQl" role="lcghm">
            <node concept="2OqwBi" id="5Erw5yf9PkG" role="lb14g">
              <node concept="2OqwBi" id="5Erw5yf9OZR" role="2Oq$k0">
                <node concept="117lpO" id="5Erw5yf9ORc" role="2Oq$k0" />
                <node concept="3TrEf2" id="5Erw5yf9P9m" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:4Xqrfpmh_pD" resolve="dataSubjectCategory" />
                </node>
              </node>
              <node concept="3TrcHB" id="3FQc_NkokT2" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="5Erw5yf9PAY" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="5Erw5yf9PD6" role="lcghm">
            <node concept="2OqwBi" id="3FQc_Nkol8Y" role="lb14g">
              <node concept="2OqwBi" id="5Erw5yf9PLb" role="2Oq$k0">
                <node concept="117lpO" id="5Erw5yf9PEv" role="2Oq$k0" />
                <node concept="3TrEf2" id="5Erw5yf9PU7" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:4Xqrfpmh_pD" resolve="dataSubjectCategory" />
                </node>
              </node>
              <node concept="3TrcHB" id="3FQc_NkolaV" role="2OqNvi">
                <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="5Erw5yf9Qyu" role="lcghm">
            <property role="lacIc" value="');" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCjJ" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglcpaq" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcpar" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglcpau" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcpav" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglcpgD" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWglcnzA" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcm7v" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcmdg" role="lcghm">
            <property role="lacIc" value="delimiter $\n CREATE DEFINER=`root`@`localhost` PROCEDURE `CreateDataSubject`()\n    NO SQL\nBEGIN\n\n    DECLARE id_ref Varchar(200);\n    DECLARE tab_ref Varchar(200);\n    DECLARE req Varchar(200);\n\n\n\n    select  dsCategory into tab_ref FROM `gdpr_datasubjectcategory`   ;\n    select  locationID into id_ref FROM `gdpr_datasubjectcategory`;\n\n\n    set req = CONCAT('create table gdpr_DataSubject as Select ', id_ref);\n    set req = CONCAT(req, ' from ');\n    set req = CONCAT(req,tab_ref );\n    set req = CONCAT(req, ' where 1&lt;0;' );\n\n    set @query = null;\n    \n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD dataSubjectID int primary key FIRST;';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD userName varchar(40);';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD password varchar(40);';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD age int;';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD country varchar(100) references gdpr_Country ;';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD dsCategory varchar(40) ;';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD tutor int ;';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\n    set req= 'ALTER TABLE gdpr_DataSubject ADD constraint const1 foreign key(dsCategory) references gdpr_DataSubjectCategory(dsCategory);';\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n    set req=CONCAT('ALTER TABLE gdpr_DataSubject ADD CONSTRAINT const2 foreign key (', id_ref);\n    set req=CONCAT(req,') references  ');\n    set req=CONCAT(req, tab_ref);\n    set req=CONCAT(req, '(');\n    set req=CONCAT(req , id_ref);\n    set req=CONCAT(req,');');\n\n\n    select req into @query;\n    prepare stmt FROM @query;\n    execute stmt;\n\n\nend\n$\n" />
          </node>
        </node>
        <node concept="3clFbH" id="3WaPWglco0O" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcn1n" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcn76" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglcnV6" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcmNF" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcmT_" role="lcghm">
            <property role="lacIc" value="call CreateDataSubject();" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUClr" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglcnPp" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcn7p" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcnd9" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur1Ux" role="3cqZAp" />
        <node concept="3clFbH" id="7bfLM_U7u3Y" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur4y8" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur4AR" role="lcghm">
            <property role="lacIc" value="-- DataUsage Annotation --" />
          </node>
          <node concept="l8MVK" id="1ZMIcpur4N8" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur4Dw" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpur72A" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpur7Wc" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur4S9" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur4WX" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataUsage(" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCm2" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur53a" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur580" role="lcghm">
            <property role="lacIc" value="id int primary key auto_increment," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCmD" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur5q6" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur5uY" role="lcghm">
            <property role="lacIc" value="personalStatus boolean default 0," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCng" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur5Ab" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur5F5" role="lcghm">
            <property role="lacIc" value="C boolean default 0," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCnR" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur5KF" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur5PB" role="lcghm">
            <property role="lacIc" value="r boolean default 0," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCou" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur5VK" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur60I" role="lcghm">
            <property role="lacIc" value="u boolean default 0," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCp5" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur6hi" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur6mi" role="lcghm">
            <property role="lacIc" value="d boolean default 0," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCpG" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur6ss" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur6xu" role="lcghm">
            <property role="lacIc" value="data int," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCqj" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur6C8" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur6Hc" role="lcghm">
            <property role="lacIc" value="processing int," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCqU" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w3_e" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w3_f" role="lcghm">
            <property role="lacIc" value="foreign key(data) references gdpr_Data(dataID)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCrx" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w3LN" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w3LO" role="lcghm">
            <property role="lacIc" value="foreign key(processing) references gdpr_Processing(processingID));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCs8" role="lcghm" />
        </node>
        <node concept="3clFbH" id="23QIlu3w3Sa" role="3cqZAp" />
        <node concept="3clFbH" id="23QIlu3w3Fy" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcpur6Ic" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7urv" role="3cqZAp">
          <node concept="l8MVK" id="7bfLM_U7urw" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur8lU" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur8JY" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur8Pi" role="lcghm">
            <property role="lacIc" value="-- annotation of all transfert data to any receiver --" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCsJ" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpus3Rx" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpus3Xe" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur92S" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur98f" role="lcghm">
            <property role="lacIc" value="create table gdpr_PersonalDataReception(" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCtm" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur9ex" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur9jU" role="lcghm">
            <property role="lacIc" value="data int, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCtX" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur9ra" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur9rb" role="lcghm">
            <property role="lacIc" value="processing int," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCu$" role="lcghm" />
        </node>
        <node concept="1X3_iC" id="63QyxWZ9EiC" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="1ZMIcpur9Dd" role="8Wnug">
            <node concept="la8eA" id="1ZMIcpur9IF" role="lcghm">
              <property role="lacIc" value="dataConsumer int," />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUCvb" role="lcghm" />
          </node>
        </node>
        <node concept="lc7rE" id="63QyxWZ9EKX" role="3cqZAp">
          <node concept="la8eA" id="63QyxWZ9EKY" role="lcghm">
            <property role="lacIc" value="secondaryActor int," />
          </node>
          <node concept="l8MVK" id="63QyxWZ9EKZ" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur9QH" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur9Wd" role="lcghm">
            <property role="lacIc" value="primary key (data, processing, secondaryActor)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCvM" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3xvQV" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3xvQW" role="lcghm">
            <property role="lacIc" value="foreign key(data) references gdpr_Data(dataID)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCwp" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w2_j" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w2_k" role="lcghm">
            <property role="lacIc" value="foreign key(processing) references gdpr_Processing(processingID)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCx0" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w2_l" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w2_m" role="lcghm">
            <property role="lacIc" value="foreign key(secondaryActor) references gdpr_SecondaryActor(secondaryActorID));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCxB" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur9lQ" role="3cqZAp" />
        <node concept="lc7rE" id="5TuIUILdWUy" role="3cqZAp">
          <node concept="l8MVK" id="5TuIUILdWUz" role="lcghm" />
        </node>
        <node concept="3clFbH" id="5TuIUILdWU$" role="3cqZAp" />
        <node concept="lc7rE" id="5TuIUILdWU_" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdWUA" role="lcghm">
            <property role="lacIc" value="-- annotation of all tranfert data to any receiver --" />
          </node>
          <node concept="l8MVK" id="5TuIUILdWUB" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdWUC" role="3cqZAp">
          <node concept="l8MVK" id="5TuIUILdWUD" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdWUE" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdWUF" role="lcghm">
            <property role="lacIc" value="create table gdpr_ProcessingMeasure(" />
          </node>
          <node concept="l8MVK" id="5TuIUILdWUG" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdWUH" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdWUI" role="lcghm">
            <property role="lacIc" value="measure int, " />
          </node>
          <node concept="l8MVK" id="5TuIUILdWUJ" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdWUK" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdWUL" role="lcghm">
            <property role="lacIc" value="processing int," />
          </node>
          <node concept="l8MVK" id="5TuIUILdWUM" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdWUQ" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdWUR" role="lcghm">
            <property role="lacIc" value="primary key (measure, processing)," />
          </node>
          <node concept="l8MVK" id="5TuIUILdWUS" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdWUT" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdWUU" role="lcghm">
            <property role="lacIc" value="foreign key(measure) references gdpr_Measure(measureID)," />
          </node>
          <node concept="l8MVK" id="5TuIUILdWUV" role="lcghm" />
        </node>
        <node concept="lc7rE" id="5TuIUILdWUW" role="3cqZAp">
          <node concept="la8eA" id="5TuIUILdWUX" role="lcghm">
            <property role="lacIc" value="foreign key(processing) references gdpr_Processing(processingID));" />
          </node>
          <node concept="l8MVK" id="5TuIUILdWUY" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpur8EL" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur8w1" role="3cqZAp">
          <node concept="l8MVK" id="1ZMIcpur8_i" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7urx" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7ury" role="lcghm">
            <property role="lacIc" value="-- DataSubject Rights Creation--" />
          </node>
          <node concept="l8MVK" id="7bfLM_U7urz" role="lcghm" />
        </node>
        <node concept="3clFbH" id="7bfLM_U7upl" role="3cqZAp" />
        <node concept="lc7rE" id="7bfLM_U7sJI" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJJ" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataRequest ( " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCye" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7sJL" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJM" role="lcghm">
            <property role="lacIc" value="DataRequestID int primary key , " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCyP" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7sJO" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJP" role="lcghm">
            <property role="lacIc" value="claim varchar(250), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCzs" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7sJR" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJS" role="lcghm">
            <property role="lacIc" value="claimDate datetime, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUC$3" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7sJU" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJV" role="lcghm">
            <property role="lacIc" value="newValue varchar(250), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUC$E" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2cm5$ryb8Cx" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb8S0" role="lcghm">
            <property role="lacIc" value="dataReqType varchar(25) check (dataReqType in('Rectification', 'Erasure', 'Access'))," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUC_h" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7sJX" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7sJY" role="lcghm">
            <property role="lacIc" value="dataSubject int," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUC_S" role="lcghm" />
        </node>
        <node concept="lc7rE" id="7bfLM_U7sZW" role="3cqZAp">
          <node concept="la8eA" id="7bfLM_U7t1M" role="lcghm">
            <property role="lacIc" value="dataID int," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCAv" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w2OO" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w2OP" role="lcghm">
            <property role="lacIc" value="foreign key(dataID) references gdpr_Data(dataID)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCB6" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w2OQ" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w2OR" role="lcghm">
            <property role="lacIc" value="foreign key(dataSubject) references gdpr_DataSubject(datasubjectID));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCBH" role="lcghm" />
        </node>
        <node concept="1X3_iC" id="6vZ7qLQieoL" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="23QIlu3w5RJ" role="8Wnug">
            <node concept="la8eA" id="23QIlu3w5RK" role="lcghm">
              <property role="lacIc" value="constraint const1 check (dataReqType in('Rectification', 'Erasure', 'Access')));" />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUCCk" role="lcghm" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3w2IG" role="3cqZAp" />
        <node concept="3clFbH" id="2cm5$ryb92B" role="3cqZAp" />
        <node concept="lc7rE" id="2cm5$ryb98v" role="3cqZAp">
          <node concept="l8MVK" id="2cm5$ryb9b8" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglg3bn" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglg3xU" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg3C9" role="lcghm">
            <property role="lacIc" value="create table gdpr_DataRequestAnswer(" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCCV" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglg3KT" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg3RG" role="lcghm">
            <property role="lacIc" value="dataRequestAnswerid int primary key ," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCDy" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglg3Zx" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg45j" role="lcghm">
            <property role="lacIc" value="answer boolean," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCE9" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglg4bL" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg4h_" role="lcghm">
            <property role="lacIc" value="justification varchar(150)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCEK" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglg4p1" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg4uR" role="lcghm">
            <property role="lacIc" value="datarequest int," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCFn" role="lcghm" />
        </node>
        <node concept="lc7rE" id="IIjfDnQJ$w" role="3cqZAp">
          <node concept="la8eA" id="IIjfDnQJEp" role="lcghm">
            <property role="lacIc" value="foreign key (datarequest) references gdpr_DataRequest(DataRequestID));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCFY" role="lcghm" />
        </node>
        <node concept="3clFbH" id="IIjfDnQI8y" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglg3mk" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglg3s0" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2cm5$ryb9du" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9fC" role="lcghm">
            <property role="lacIc" value="create table gdpr_ProcessingRequest(" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCG_" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2cm5$ryb9if" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9kr" role="lcghm">
            <property role="lacIc" value="id int primary key, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCHc" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2cm5$ryb9pS" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9s6" role="lcghm">
            <property role="lacIc" value="claim varchar(250), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCHB" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2cm5$ryb9wG" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9yW" role="lcghm">
            <property role="lacIc" value="claimDate datetime, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCIe" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2cm5$ryb9HZ" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9KL" role="lcghm">
            <property role="lacIc" value="procReqType varchar(25) check (procReqType in('Objection', 'Knowldge'))," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCIP" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2cm5$ryb9B3" role="3cqZAp">
          <node concept="la8eA" id="2cm5$ryb9Dl" role="lcghm">
            <property role="lacIc" value="dataSubject int, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCJg" role="lcghm" />
        </node>
        <node concept="lc7rE" id="2cm5$rybadC" role="3cqZAp">
          <node concept="la8eA" id="2cm5$rybafX" role="lcghm">
            <property role="lacIc" value="processing int, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCJR" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w4tv" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w4tw" role="lcghm">
            <property role="lacIc" value="foreign key (dataSubject) references gdpr_DataSubject(datasubjectID)," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCKu" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w4_k" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w4_l" role="lcghm">
            <property role="lacIc" value="foreign key (processing) references gdpr_Processing(processingID));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCL5" role="lcghm" />
        </node>
        <node concept="1X3_iC" id="6vZ7qLQieE_" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="23QIlu3w4NO" role="8Wnug">
            <node concept="la8eA" id="23QIlu3w4NP" role="lcghm">
              <property role="lacIc" value="constraint const1 check (procReqType in('Objection', 'Knowldge')));" />
            </node>
            <node concept="l8MVK" id="2nvZ8XYUCLG" role="lcghm" />
          </node>
        </node>
        <node concept="3clFbH" id="23QIlu3w4Hq" role="3cqZAp" />
        <node concept="3clFbH" id="7bfLM_U7t52" role="3cqZAp" />
        <node concept="lc7rE" id="2cm5$ryb96g" role="3cqZAp">
          <node concept="l8MVK" id="2cm5$ryb96h" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpurIH3" role="3cqZAp" />
        <node concept="3clFbH" id="1ZMIcput64H" role="3cqZAp" />
        <node concept="lc7rE" id="2cm5$rybH5P" role="3cqZAp">
          <node concept="la8eA" id="2cm5$rybH8i" role="lcghm">
            <property role="lacIc" value="-- Contract and consent management --" />
          </node>
          <node concept="l8MVK" id="2cm5$rybHca" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpus4tM" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglco6M" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcocC" role="lcghm">
            <property role="lacIc" value="create table gdpr_Contract(" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCMj" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglcojC" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcopw" role="lcghm">
            <property role="lacIc" value="contractID int primary key auto_increment," />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCMU" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglcoxH" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcoBB" role="lcghm">
            <property role="lacIc" value="signaturedate date, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCNx" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglcoIU" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcoOQ" role="lcghm">
            <property role="lacIc" value="expirationDate date, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCO8" role="lcghm" />
        </node>
        <node concept="lc7rE" id="3WaPWglcoWq" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglcp2o" role="lcghm">
            <property role="lacIc" value="dataSubject int, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCOJ" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w4WH" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w4WI" role="lcghm">
            <property role="lacIc" value="foreign key (dataSubject) references gdpr_Datasubject(datasubjectID));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCPm" role="lcghm" />
        </node>
        <node concept="3clFbH" id="1ZMIcpusaao" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglcpyk" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglcpCi" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglcpC_" role="3cqZAp" />
        <node concept="lc7rE" id="1ZMIcpur3t6" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur3t7" role="lcghm">
            <property role="lacIc" value="create table gdpr_Consent (" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCPX" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur3t8" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur3t9" role="lcghm">
            <property role="lacIc" value="consentID int primary key auto_increment,  " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCR2" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur3tg" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur3th" role="lcghm">
            <property role="lacIc" value="startDate date, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCRD" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur3ti" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur3tj" role="lcghm">
            <property role="lacIc" value="endDate date, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCSg" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur3VS" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur40$" role="lcghm">
            <property role="lacIc" value="processing int, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCSR" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur46D" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur4bn" role="lcghm">
            <property role="lacIc" value="contract int, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCTu" role="lcghm" />
        </node>
        <node concept="lc7rE" id="1ZMIcpur4hi" role="3cqZAp">
          <node concept="la8eA" id="1ZMIcpur4m2" role="lcghm">
            <property role="lacIc" value="dataSubject int, " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCU5" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w5DQ" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w5DR" role="lcghm">
            <property role="lacIc" value="foreign key (processing) references gdpr_Processing(processingID), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCUG" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w5k4" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w5k5" role="lcghm">
            <property role="lacIc" value="foreign key (contract) references gdpr_Contract(contractID), " />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCVj" role="lcghm" />
        </node>
        <node concept="lc7rE" id="23QIlu3w55_" role="3cqZAp">
          <node concept="la8eA" id="23QIlu3w55A" role="lcghm">
            <property role="lacIc" value="foreign key (dataSubject) references gdpr_Datasubject(datasubjectID));" />
          </node>
          <node concept="l8MVK" id="2nvZ8XYUCVU" role="lcghm" />
        </node>
        <node concept="3clFbH" id="7bfLM_U7syQ" role="3cqZAp" />
        <node concept="3SKdUt" id="ML4nhMuw5z" role="3cqZAp">
          <node concept="1PaTwC" id="ML4nhMuw5$" role="1aUNEU">
            <node concept="3oM_SD" id="ML4nhMuwmE" role="1PaTwD">
              <property role="3oM_SC" value="Breach" />
            </node>
            <node concept="3oM_SD" id="ML4nhMuwmM" role="1PaTwD">
              <property role="3oM_SC" value="part" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="ML4nhMuxZA" role="3cqZAp">
          <node concept="l8MVK" id="ML4nhMuxZB" role="lcghm" />
        </node>
        <node concept="3clFbH" id="ML4nhMuxZC" role="3cqZAp" />
        <node concept="lc7rE" id="ML4nhMuxZD" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuxZE" role="lcghm">
            <property role="lacIc" value="create table gdpr_Breach (" />
          </node>
          <node concept="l8MVK" id="ML4nhMuxZF" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuxZG" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuxZH" role="lcghm">
            <property role="lacIc" value="breachID int primary key , " />
          </node>
          <node concept="l8MVK" id="ML4nhMuxZI" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuxZJ" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuxZK" role="lcghm">
            <property role="lacIc" value="nature varchar(40), " />
          </node>
          <node concept="l8MVK" id="ML4nhMuxZL" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuxZM" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuxZN" role="lcghm">
            <property role="lacIc" value="riskLevel varchar(7) check (riskLevel in('NoRisk','Average','High')), " />
          </node>
          <node concept="l8MVK" id="ML4nhMuxZO" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuxZS" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuxZT" role="lcghm">
            <property role="lacIc" value="creationDate date, " />
          </node>
          <node concept="l8MVK" id="ML4nhMuxZU" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuzpY" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuzpZ" role="lcghm">
            <property role="lacIc" value="sprvAuthNonNotifReason varchar(255), " />
          </node>
          <node concept="l8MVK" id="ML4nhMuzq0" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMu$8P" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMu$8Q" role="lcghm">
            <property role="lacIc" value="dataSubjNonNotifReason varchar(255)); " />
          </node>
          <node concept="l8MVK" id="ML4nhMu$8R" role="lcghm" />
        </node>
        <node concept="3clFbH" id="ML4nhMuzC0" role="3cqZAp" />
        <node concept="lc7rE" id="ML4nhMuxo1" role="3cqZAp">
          <node concept="l8MVK" id="ML4nhMuxo2" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuxo3" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuxo4" role="lcghm">
            <property role="lacIc" value="-- Consequence table gdpr_Creation --" />
          </node>
          <node concept="l8MVK" id="ML4nhMuxo5" role="lcghm" />
        </node>
        <node concept="3clFbH" id="ML4nhMuxo6" role="3cqZAp" />
        <node concept="lc7rE" id="ML4nhMuxo7" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuxo8" role="lcghm">
            <property role="lacIc" value="create table gdpr_Consequence (" />
          </node>
          <node concept="l8MVK" id="ML4nhMuxo9" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuxoa" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuxob" role="lcghm">
            <property role="lacIc" value="impactID int primary key , " />
          </node>
          <node concept="l8MVK" id="ML4nhMuxoc" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuxod" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuxoe" role="lcghm">
            <property role="lacIc" value="description varchar(255));" />
          </node>
          <node concept="l8MVK" id="ML4nhMuxof" role="lcghm" />
        </node>
        <node concept="3clFbH" id="ML4nhMuxaH" role="3cqZAp" />
        <node concept="3SKdUt" id="ML4nhMu_LS" role="3cqZAp">
          <node concept="1PaTwC" id="ML4nhMu_LT" role="1aUNEU">
            <node concept="3oM_SD" id="ML4nhMuA0e" role="1PaTwD">
              <property role="3oM_SC" value="many" />
            </node>
            <node concept="3oM_SD" id="ML4nhMuA0k" role="1PaTwD">
              <property role="3oM_SC" value="to" />
            </node>
            <node concept="3oM_SD" id="ML4nhMuA0q" role="1PaTwD">
              <property role="3oM_SC" value="many" />
            </node>
            <node concept="3oM_SD" id="ML4nhMuA0z" role="1PaTwD">
              <property role="3oM_SC" value="tables" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="ML4nhMu_cP" role="3cqZAp">
          <node concept="l8MVK" id="ML4nhMu_cQ" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMu_cR" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMu_cS" role="lcghm">
            <property role="lacIc" value="create table gdpr_BreachMeasure(" />
          </node>
          <node concept="l8MVK" id="ML4nhMu_cT" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMu_cU" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMu_cV" role="lcghm">
            <property role="lacIc" value="measure int, " />
          </node>
          <node concept="l8MVK" id="ML4nhMu_cW" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMu_cX" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMu_cY" role="lcghm">
            <property role="lacIc" value="breach int," />
          </node>
          <node concept="l8MVK" id="ML4nhMu_cZ" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMu_d0" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMu_d1" role="lcghm">
            <property role="lacIc" value="primary key (measure, breach)," />
          </node>
          <node concept="l8MVK" id="ML4nhMu_d2" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMu_d3" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMu_d4" role="lcghm">
            <property role="lacIc" value="foreign key(measure) references gdpr_Measure(measureID)," />
          </node>
          <node concept="l8MVK" id="ML4nhMu_d5" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMu_d6" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMu_d7" role="lcghm">
            <property role="lacIc" value="foreign key(breach) references gdpr_Breach(breachID));" />
          </node>
          <node concept="l8MVK" id="ML4nhMu_d8" role="lcghm" />
        </node>
        <node concept="3clFbH" id="ML4nhMu$V5" role="3cqZAp" />
        <node concept="lc7rE" id="ML4nhMuAjd" role="3cqZAp">
          <node concept="l8MVK" id="ML4nhMuAje" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAjf" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAjg" role="lcghm">
            <property role="lacIc" value="create table gdpr_BreachConsequence(" />
          </node>
          <node concept="l8MVK" id="ML4nhMuAjh" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAji" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAjj" role="lcghm">
            <property role="lacIc" value="consequence int, " />
          </node>
          <node concept="l8MVK" id="ML4nhMuAjk" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAjl" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAjm" role="lcghm">
            <property role="lacIc" value="breach int," />
          </node>
          <node concept="l8MVK" id="ML4nhMuAjn" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAjo" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAjp" role="lcghm">
            <property role="lacIc" value="primary key (consequence, breach)," />
          </node>
          <node concept="l8MVK" id="ML4nhMuAjq" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAjr" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAjs" role="lcghm">
            <property role="lacIc" value="foreign key(consequence) references gdpr_Consequence(impactID)," />
          </node>
          <node concept="l8MVK" id="ML4nhMuAjt" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAju" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAjv" role="lcghm">
            <property role="lacIc" value="foreign key(breach) references gdpr_Breach(breachID));" />
          </node>
          <node concept="l8MVK" id="ML4nhMuAjw" role="lcghm" />
        </node>
        <node concept="3clFbH" id="ML4nhMuA4X" role="3cqZAp" />
        <node concept="lc7rE" id="ML4nhMuAW9" role="3cqZAp">
          <node concept="l8MVK" id="ML4nhMuAWa" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAWb" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAWc" role="lcghm">
            <property role="lacIc" value="create table gdpr_BreachDataSubject(" />
          </node>
          <node concept="l8MVK" id="ML4nhMuAWd" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAWe" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAWf" role="lcghm">
            <property role="lacIc" value="dataSubject int, " />
          </node>
          <node concept="l8MVK" id="ML4nhMuAWg" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAWh" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAWi" role="lcghm">
            <property role="lacIc" value="breach int," />
          </node>
          <node concept="l8MVK" id="ML4nhMuAWj" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAWk" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAWl" role="lcghm">
            <property role="lacIc" value="primary key (dataSubject, breach)," />
          </node>
          <node concept="l8MVK" id="ML4nhMuAWm" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAWn" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAWo" role="lcghm">
            <property role="lacIc" value="foreign key(dataSubject) references gdpr_DataSubject(dataSubjectID)," />
          </node>
          <node concept="l8MVK" id="ML4nhMuAWp" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuAWq" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuAWr" role="lcghm">
            <property role="lacIc" value="foreign key(breach) references gdpr_Breach(breachID));" />
          </node>
          <node concept="l8MVK" id="ML4nhMuAWs" role="lcghm" />
        </node>
        <node concept="3clFbH" id="ML4nhMuAIy" role="3cqZAp" />
        <node concept="lc7rE" id="ML4nhMuBzT" role="3cqZAp">
          <node concept="l8MVK" id="ML4nhMuBzU" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuBzV" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuBzW" role="lcghm">
            <property role="lacIc" value="create table gdpr_BreachData(" />
          </node>
          <node concept="l8MVK" id="ML4nhMuBzX" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuBzY" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuBzZ" role="lcghm">
            <property role="lacIc" value="data int, " />
          </node>
          <node concept="l8MVK" id="ML4nhMuB$0" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuB$1" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuB$2" role="lcghm">
            <property role="lacIc" value="breach int," />
          </node>
          <node concept="l8MVK" id="ML4nhMuB$3" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuC7E" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuC7F" role="lcghm">
            <property role="lacIc" value="nbRecords int," />
          </node>
          <node concept="l8MVK" id="ML4nhMuC7G" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuB$4" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuB$5" role="lcghm">
            <property role="lacIc" value="primary key (data, breach)," />
          </node>
          <node concept="l8MVK" id="ML4nhMuB$6" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuB$7" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuB$8" role="lcghm">
            <property role="lacIc" value="foreign key(data) references gdpr_Data(dataID)," />
          </node>
          <node concept="l8MVK" id="ML4nhMuB$9" role="lcghm" />
        </node>
        <node concept="lc7rE" id="ML4nhMuB$a" role="3cqZAp">
          <node concept="la8eA" id="ML4nhMuB$b" role="lcghm">
            <property role="lacIc" value="foreign key(breach) references gdpr_Breach(breachID));" />
          </node>
          <node concept="l8MVK" id="ML4nhMuB$c" role="lcghm" />
        </node>
        <node concept="3clFbH" id="ML4nhMuB$d" role="3cqZAp" />
        <node concept="3clFbH" id="ML4nhMuBlX" role="3cqZAp" />
      </node>
    </node>
    <node concept="29tfMY" id="7bfLM_U7Bnw" role="29tGrW">
      <node concept="3clFbS" id="7bfLM_U7Bnx" role="2VODD2">
        <node concept="3clFbF" id="7bfLM_U7Bs$" role="3cqZAp">
          <node concept="Xl_RD" id="5Erw5yfbvGZ" role="3clFbG">
            <property role="Xl_RC" value="PRIAM_GDPR" />
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="3FQc_NktoHw">
    <ref role="WuzLi" to="20wa:3FQc_Nkm_Ey" resolve="DataTypeList" />
    <node concept="29tfMY" id="3FQc_NktoHx" role="29tGrW">
      <node concept="3clFbS" id="3FQc_NktoHy" role="2VODD2">
        <node concept="3clFbF" id="3FQc_NktoM6" role="3cqZAp">
          <node concept="Xl_RD" id="3FQc_Nktsju" role="3clFbG">
            <property role="Xl_RC" value="Data type" />
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="3FQc_Nktsq9" role="33IsuW">
      <node concept="3clFbS" id="3FQc_Nktsqa" role="2VODD2">
        <node concept="3clFbF" id="3FQc_Nktsr3" role="3cqZAp">
          <node concept="Xl_RD" id="3FQc_Nktsr2" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="3FQc_Nktsu2" role="11c4hB">
      <node concept="3clFbS" id="3FQc_Nktsu3" role="2VODD2">
        <node concept="3cpWs8" id="2pxN2iW0jVd" role="3cqZAp">
          <node concept="3cpWsn" id="2pxN2iW0jVe" role="3cpWs9">
            <property role="TrG5h" value="p" />
            <node concept="17QB3L" id="2pxN2iW0jVf" role="1tU5fm" />
            <node concept="Xl_RD" id="2pxN2iW0jVg" role="33vP2m">
              <property role="Xl_RC" value="true" />
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="2pxN2iW0jkk" role="3cqZAp" />
        <node concept="2Gpval" id="3FQc_NktsUx" role="3cqZAp">
          <node concept="2GrKxI" id="3FQc_NktsUy" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="3FQc_NktsUz" role="2GsD0m">
            <node concept="117lpO" id="3FQc_NktsU$" role="2Oq$k0" />
            <node concept="3Tsc0h" id="3FQc_Nkttug" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:3FQc_Nkm_Ez" resolve="dataType" />
            </node>
          </node>
          <node concept="3clFbS" id="3FQc_NktsUA" role="2LFqv$">
            <node concept="lc7rE" id="3FQc_NktsUB" role="3cqZAp">
              <node concept="la8eA" id="3FQc_NktsUC" role="lcghm">
                <property role="lacIc" value="insert into gdpr_DataType(DataTypeName) values ('" />
              </node>
              <node concept="l9hG8" id="3FQc_NktsUD" role="lcghm">
                <node concept="2OqwBi" id="3FQc_NktsUE" role="lb14g">
                  <node concept="2GrUjf" id="3FQc_NktsUF" role="2Oq$k0">
                    <ref role="2Gs0qQ" node="3FQc_NktsUy" resolve="e" />
                  </node>
                  <node concept="3TrcHB" id="3FQc_Nktuvr" role="2OqNvi">
                    <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="3FQc_Nku2PL" role="lcghm">
                <property role="lacIc" value="');" />
              </node>
              <node concept="l8MVK" id="3FQc_NktsV2" role="lcghm" />
            </node>
            <node concept="3clFbH" id="2pxN2iW0aNm" role="3cqZAp" />
            <node concept="2Gpval" id="2pxN2iW0aNM" role="3cqZAp">
              <node concept="2GrKxI" id="2pxN2iW0aNN" role="2Gsz3X">
                <property role="TrG5h" value="f" />
              </node>
              <node concept="2OqwBi" id="2pxN2iW0dhK" role="2GsD0m">
                <node concept="2OqwBi" id="2pxN2iW0aNO" role="2Oq$k0">
                  <node concept="117lpO" id="2pxN2iW0aNP" role="2Oq$k0" />
                  <node concept="3Tsc0h" id="2pxN2iW0bXp" role="2OqNvi">
                    <ref role="3TtcxE" to="20wa:3FQc_Nkm_Ez" resolve="dataType" />
                  </node>
                </node>
                <node concept="13MTOL" id="2pxN2iW0eOz" role="2OqNvi">
                  <ref role="13MTZf" to="20wa:2pxN2iVZd46" resolve="personalData" />
                </node>
              </node>
              <node concept="3clFbS" id="2pxN2iW0aNR" role="2LFqv$">
                <node concept="lc7rE" id="2pxN2iW0aNS" role="3cqZAp">
                  <node concept="la8eA" id="2pxN2iW0aNT" role="lcghm">
                    <property role="lacIc" value="insert into gdpr_data(dataID, dataTypeName, source, dataConservation, isPersonal,personalDataCategory)" />
                  </node>
                  <node concept="l8MVK" id="2pxN2iW0aNU" role="lcghm" />
                  <node concept="la8eA" id="2pxN2iW0aNV" role="lcghm">
                    <property role="lacIc" value="   values (" />
                  </node>
                  <node concept="l9hG8" id="2pxN2iW0aNW" role="lcghm">
                    <node concept="3cpWs3" id="2pxN2iW0aNX" role="lb14g">
                      <node concept="Xl_RD" id="2pxN2iW0aNY" role="3uHU7w">
                        <property role="Xl_RC" value="" />
                      </node>
                      <node concept="2OqwBi" id="2pxN2iW0aNZ" role="3uHU7B">
                        <node concept="2GrUjf" id="2pxN2iW0aO0" role="2Oq$k0">
                          <ref role="2Gs0qQ" node="2pxN2iW0aNN" resolve="f" />
                        </node>
                        <node concept="3TrcHB" id="2pxN2iW0aO1" role="2OqNvi">
                          <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2pxN2iW0aO2" role="lcghm">
                    <property role="lacIc" value=", '" />
                  </node>
                  <node concept="l9hG8" id="2pxN2iW0aO3" role="lcghm">
                    <node concept="2OqwBi" id="2pxN2iW0aO4" role="lb14g">
                      <node concept="3TrcHB" id="2pxN2iW0aO8" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                      <node concept="2GrUjf" id="2pxN2iW5jBM" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="3FQc_NktsUy" resolve="e" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2pxN2iW0aO9" role="lcghm">
                    <property role="lacIc" value="', '" />
                  </node>
                  <node concept="l9hG8" id="2pxN2iW0aOa" role="lcghm">
                    <node concept="2OqwBi" id="2pxN2iW0aOb" role="lb14g">
                      <node concept="2OqwBi" id="2pxN2iW0aOc" role="2Oq$k0">
                        <node concept="2GrUjf" id="2pxN2iW0aOd" role="2Oq$k0">
                          <ref role="2Gs0qQ" node="2pxN2iW0aNN" resolve="f" />
                        </node>
                        <node concept="3TrcHB" id="2pxN2iW0aOe" role="2OqNvi">
                          <ref role="3TsBF5" to="20wa:5VnHNHVgh9K" resolve="source" />
                        </node>
                      </node>
                      <node concept="liA8E" id="2pxN2iW0aOf" role="2OqNvi">
                        <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2pxN2iW0aOg" role="lcghm">
                    <property role="lacIc" value="','" />
                  </node>
                  <node concept="l9hG8" id="2pxN2iW0aOh" role="lcghm">
                    <node concept="3cpWs3" id="2pxN2iW0aOi" role="lb14g">
                      <node concept="Xl_RD" id="2pxN2iW0aOj" role="3uHU7w" />
                      <node concept="2OqwBi" id="2pxN2iW0aOk" role="3uHU7B">
                        <node concept="2GrUjf" id="2pxN2iW0aOl" role="2Oq$k0">
                          <ref role="2Gs0qQ" node="2pxN2iW0aNN" resolve="f" />
                        </node>
                        <node concept="3TrcHB" id="2pxN2iW0aOm" role="2OqNvi">
                          <ref role="3TsBF5" to="20wa:AQqjC1K8Nq" resolve="dataConservation" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2pxN2iW0aOn" role="lcghm">
                    <property role="lacIc" value="'," />
                  </node>
                  <node concept="l9hG8" id="2pxN2iW0aOo" role="lcghm">
                    <node concept="37vLTw" id="2pxN2iW0aOp" role="lb14g">
                      <ref role="3cqZAo" node="2pxN2iW0jVe" resolve="p" />
                    </node>
                  </node>
                  <node concept="la8eA" id="2pxN2iW0aOq" role="lcghm">
                    <property role="lacIc" value=",'" />
                  </node>
                  <node concept="l9hG8" id="2pxN2iW0aOr" role="lcghm">
                    <node concept="3cpWs3" id="2pxN2iW0aOs" role="lb14g">
                      <node concept="Xl_RD" id="2pxN2iW0aOt" role="3uHU7w">
                        <property role="Xl_RC" value="" />
                      </node>
                      <node concept="2OqwBi" id="2pxN2iW0aOu" role="3uHU7B">
                        <node concept="2OqwBi" id="2pxN2iW0aOv" role="2Oq$k0">
                          <node concept="2GrUjf" id="2pxN2iW0aOw" role="2Oq$k0">
                            <ref role="2Gs0qQ" node="2pxN2iW0aNN" resolve="f" />
                          </node>
                          <node concept="3TrEf2" id="2pxN2iW0aOx" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:68$ZZoCzNiB" resolve="personalDataCategory" />
                          </node>
                        </node>
                        <node concept="3TrcHB" id="2pxN2iW0aOy" role="2OqNvi">
                          <ref role="3TsBF5" to="20wa:68$ZZoCzNiA" resolve="id" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2pxN2iW0aOz" role="lcghm">
                    <property role="lacIc" value="');" />
                  </node>
                  <node concept="l8MVK" id="2pxN2iW0aO$" role="lcghm" />
                </node>
              </node>
            </node>
            <node concept="3clFbH" id="2pxN2iW0aN$" role="3cqZAp" />
            <node concept="2Gpval" id="2pxN2iW0fFJ" role="3cqZAp">
              <node concept="2GrKxI" id="2pxN2iW0fFK" role="2Gsz3X">
                <property role="TrG5h" value="g" />
              </node>
              <node concept="2OqwBi" id="2pxN2iW0hC3" role="2GsD0m">
                <node concept="2OqwBi" id="2pxN2iW0fFL" role="2Oq$k0">
                  <node concept="117lpO" id="2pxN2iW0fFM" role="2Oq$k0" />
                  <node concept="3Tsc0h" id="2pxN2iW0glt" role="2OqNvi">
                    <ref role="3TtcxE" to="20wa:3FQc_Nkm_Ez" resolve="dataType" />
                  </node>
                </node>
                <node concept="13MTOL" id="2pxN2iW0j95" role="2OqNvi">
                  <ref role="13MTZf" to="20wa:2pxN2iVZd47" resolve="nonPersonalData" />
                </node>
              </node>
              <node concept="3clFbS" id="2pxN2iW0fFO" role="2LFqv$">
                <node concept="lc7rE" id="2pxN2iW0fFP" role="3cqZAp">
                  <node concept="la8eA" id="2pxN2iW0fFQ" role="lcghm">
                    <property role="lacIc" value="insert into gdpr_data(dataID, dataTypeName, isPersonal) values (" />
                  </node>
                  <node concept="l9hG8" id="2pxN2iW0fFR" role="lcghm">
                    <node concept="3cpWs3" id="2pxN2iW0fFS" role="lb14g">
                      <node concept="Xl_RD" id="2pxN2iW0fFT" role="3uHU7w">
                        <property role="Xl_RC" value="" />
                      </node>
                      <node concept="2OqwBi" id="2pxN2iW0fFU" role="3uHU7B">
                        <node concept="2GrUjf" id="2pxN2iW0fFV" role="2Oq$k0">
                          <ref role="2Gs0qQ" node="2pxN2iW0fFK" resolve="g" />
                        </node>
                        <node concept="3TrcHB" id="2pxN2iW0fFW" role="2OqNvi">
                          <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2pxN2iW0fFX" role="lcghm">
                    <property role="lacIc" value=", '" />
                  </node>
                  <node concept="l9hG8" id="2pxN2iW0fFY" role="lcghm">
                    <node concept="2OqwBi" id="2pxN2iW0fFZ" role="lb14g">
                      <node concept="2GrUjf" id="2pxN2iW5jdo" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="3FQc_NktsUy" resolve="e" />
                      </node>
                      <node concept="3TrcHB" id="2pxN2iW0fG3" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2pxN2iW0fG4" role="lcghm">
                    <property role="lacIc" value="', false" />
                  </node>
                  <node concept="la8eA" id="2pxN2iW0fG5" role="lcghm">
                    <property role="lacIc" value=");" />
                  </node>
                  <node concept="l8MVK" id="2pxN2iW0fG6" role="lcghm" />
                </node>
              </node>
            </node>
            <node concept="3clFbH" id="2pxN2iW0f9u" role="3cqZAp" />
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="3WaPWglg0GW">
    <ref role="WuzLi" to="20wa:3WaPWglfBNY" resolve="DataRequestAnswer" />
    <node concept="29tfMY" id="3WaPWglg1oX" role="29tGrW">
      <node concept="3clFbS" id="3WaPWglg1oY" role="2VODD2">
        <node concept="3clFbF" id="3WaPWglg1pm" role="3cqZAp">
          <node concept="3cpWs3" id="3WaPWglg2xE" role="3clFbG">
            <node concept="2OqwBi" id="3WaPWglg2KR" role="3uHU7w">
              <node concept="117lpO" id="3WaPWglg2yi" role="2Oq$k0" />
              <node concept="3TrcHB" id="3WaPWglg2S8" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:3WaPWglfBNZ" resolve="id" />
              </node>
            </node>
            <node concept="Xl_RD" id="3WaPWglg2i3" role="3uHU7B">
              <property role="Xl_RC" value="answer" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="3WaPWglg1L6" role="33IsuW">
      <node concept="3clFbS" id="3WaPWglg1L7" role="2VODD2">
        <node concept="3clFbF" id="3WaPWglg1M4" role="3cqZAp">
          <node concept="Xl_RD" id="3WaPWglg1M3" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="3WaPWglg1Oc" role="11c4hB">
      <node concept="3clFbS" id="3WaPWglg1Od" role="2VODD2">
        <node concept="3clFbH" id="3WaPWglkclH" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWglg2j$" role="3cqZAp">
          <node concept="la8eA" id="3WaPWglg30z" role="lcghm">
            <property role="lacIc" value="insert into gdpr_DataRequestAnswer(dataRequestAnswerid, answer, justification, datarequest) values (" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglg4yj" role="3cqZAp">
          <node concept="l9hG8" id="1PjvIwH_7Uc" role="lcghm">
            <node concept="3cpWs3" id="1PjvIwH_8Zq" role="lb14g">
              <node concept="Xl_RD" id="1PjvIwH_8Zu" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="1PjvIwH_8aI" role="3uHU7B">
                <node concept="117lpO" id="1PjvIwH_841" role="2Oq$k0" />
                <node concept="3TrcHB" id="1PjvIwH_8ik" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglfBNZ" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="1PjvIwH_9U9" role="lcghm">
            <property role="lacIc" value=", " />
          </node>
          <node concept="l9hG8" id="3WaPWglg4ze" role="lcghm">
            <node concept="3cpWs3" id="3WaPWglg5aQ" role="lb14g">
              <node concept="Xl_RD" id="3WaPWglg5aU" role="3uHU7w" />
              <node concept="2OqwBi" id="3WaPWglg4EK" role="3uHU7B">
                <node concept="117lpO" id="3WaPWglg4$3" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWglg4Mn" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglfBO1" resolve="answer" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglg5mm" role="lcghm">
            <property role="lacIc" value=", '" />
          </node>
          <node concept="l9hG8" id="3WaPWglg5oZ" role="lcghm">
            <node concept="2OqwBi" id="3WaPWglg5xe" role="lb14g">
              <node concept="117lpO" id="3WaPWglg5qx" role="2Oq$k0" />
              <node concept="3TrcHB" id="3WaPWglg5CP" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:3WaPWglfBO6" resolve="proof" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglg5HR" role="lcghm">
            <property role="lacIc" value="', " />
          </node>
          <node concept="l9hG8" id="3WaPWglg5KU" role="lcghm">
            <node concept="3cpWs3" id="3WaPWglg7nk" role="lb14g">
              <node concept="2OqwBi" id="3WaPWglg6k7" role="3uHU7B">
                <node concept="2OqwBi" id="3WaPWglg62u" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWglg5VL" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWglg6a5" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                  </node>
                </node>
                <node concept="3TrcHB" id="3WaPWglg6uS" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:7bfLM_U99lL" resolve="id" />
                </node>
              </node>
              <node concept="Xl_RD" id="3WaPWglg7zD" role="3uHU7w" />
            </node>
          </node>
          <node concept="la8eA" id="3WaPWglg$$s" role="lcghm">
            <property role="lacIc" value=");" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWglhuLN" role="3cqZAp">
          <node concept="l8MVK" id="3WaPWglhvwK" role="lcghm" />
        </node>
        <node concept="3clFbH" id="3WaPWglkdMR" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWglkcXD" role="3cqZAp" />
        <node concept="3clFbJ" id="3WaPWglg1Py" role="3cqZAp">
          <node concept="2OqwBi" id="3WaPWglg1Xc" role="3clFbw">
            <node concept="117lpO" id="3WaPWglg1PW" role="2Oq$k0" />
            <node concept="3TrcHB" id="3WaPWglg24g" role="2OqNvi">
              <ref role="3TsBF5" to="20wa:3WaPWglfBO1" resolve="answer" />
            </node>
          </node>
          <node concept="3clFbS" id="3WaPWglg1P$" role="3clFbx">
            <node concept="3clFbJ" id="3WaPWglgZpn" role="3cqZAp">
              <node concept="3clFbS" id="3WaPWglgZpp" role="3clFbx">
                <node concept="3clFbH" id="3WaPWgliQyx" role="3cqZAp" />
                <node concept="lc7rE" id="3WaPWglijAI" role="3cqZAp">
                  <node concept="la8eA" id="3WaPWglijCU" role="lcghm">
                    <property role="lacIc" value="update " />
                  </node>
                  <node concept="l9hG8" id="3WaPWglijDL" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWgliRJ7" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWgliRj_" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglijLm" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglijED" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglijSX" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWgliRwK" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                        </node>
                      </node>
                      <node concept="1mfA1w" id="SXiEYPIlw5" role="2OqNvi" />
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglil$Z" role="lcghm">
                    <property role="lacIc" value=" set " />
                  </node>
                </node>
                <node concept="lc7rE" id="3WaPWglilF$" role="3cqZAp">
                  <node concept="l9hG8" id="3WaPWglilIw" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglimFz" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglimhO" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglilQ4" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglilJn" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglim7M" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglimtc" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglimUY" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglimZa" role="lcghm">
                    <property role="lacIc" value="=&quot;" />
                  </node>
                  <node concept="l9hG8" id="3WaPWglin7Z" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglinxK" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglinh9" role="2Oq$k0">
                        <node concept="117lpO" id="3WaPWglin9u" role="2Oq$k0" />
                        <node concept="3TrEf2" id="3WaPWglinoK" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglinH8" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:424h5AVf9rI" resolve="newValue" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglio03" role="lcghm">
                    <property role="lacIc" value="&quot; " />
                  </node>
                </node>
                <node concept="lc7rE" id="3WaPWgliogq" role="3cqZAp">
                  <node concept="la8eA" id="3WaPWgliokx" role="lcghm">
                    <property role="lacIc" value="where " />
                  </node>
                  <node concept="l9hG8" id="3WaPWgliolQ" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglipIT" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglipe6" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglioI2" role="2Oq$k0">
                          <node concept="2OqwBi" id="3WaPWgliotr" role="2Oq$k0">
                            <node concept="117lpO" id="3WaPWgliomI" role="2Oq$k0" />
                            <node concept="3TrEf2" id="3WaPWglio_2" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                            </node>
                          </node>
                          <node concept="3TrEf2" id="3WaPWglioTq" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglipxF" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglipU8" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglipY0" role="lcghm">
                    <property role="lacIc" value=" in (select " />
                  </node>
                  <node concept="l9hG8" id="3WaPWgliq9i" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglirqn" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWgliqUb" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWgliqzH" role="2Oq$k0">
                          <node concept="2OqwBi" id="3WaPWgliqiz" role="2Oq$k0">
                            <node concept="117lpO" id="3WaPWgliqaS" role="2Oq$k0" />
                            <node concept="3TrEf2" id="3WaPWgliqqH" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                            </node>
                          </node>
                          <node concept="3TrEf2" id="3WaPWgliqJ5" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglirdK" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglirAd" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglitzT" role="lcghm">
                    <property role="lacIc" value=" from gdpr_datasubject as D where username='" />
                  </node>
                  <node concept="l9hG8" id="3WaPWglis55" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglit78" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglisvh" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglise7" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglis7q" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglismh" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglisE2" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglitq6" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWgljdwC" role="lcghm">
                    <property role="lacIc" value="');" />
                  </node>
                </node>
              </node>
              <node concept="3clFbC" id="3WaPWglh0JT" role="3clFbw">
                <node concept="Xl_RD" id="3WaPWglh0TI" role="3uHU7w">
                  <property role="Xl_RC" value="rectification" />
                </node>
                <node concept="2OqwBi" id="3WaPWglhSFb" role="3uHU7B">
                  <node concept="2OqwBi" id="3WaPWglgZRa" role="2Oq$k0">
                    <node concept="2OqwBi" id="3WaPWglgZyZ" role="2Oq$k0">
                      <node concept="117lpO" id="3WaPWglgZrJ" role="2Oq$k0" />
                      <node concept="3TrEf2" id="3WaPWglgZE3" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="3WaPWglh03b" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:51XxSBB6uyX" resolve="type" />
                    </node>
                  </node>
                  <node concept="liA8E" id="3WaPWglhSPb" role="2OqNvi">
                    <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
                  </node>
                </node>
              </node>
            </node>
            <node concept="3clFbJ" id="3WaPWglkfux" role="3cqZAp">
              <node concept="3clFbS" id="3WaPWglkfuz" role="3clFbx">
                <node concept="lc7rE" id="3WaPWglkgWE" role="3cqZAp">
                  <node concept="la8eA" id="3WaPWglkgWF" role="lcghm">
                    <property role="lacIc" value="update " />
                  </node>
                  <node concept="l9hG8" id="3WaPWglkgWG" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglkgWH" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglkgWI" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglkgWJ" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglkgWK" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglkgWL" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglkgWM" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                        </node>
                      </node>
                      <node concept="1mfA1w" id="SXiEYPIlKd" role="2OqNvi" />
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglkgWO" role="lcghm">
                    <property role="lacIc" value=" set ( " />
                  </node>
                </node>
                <node concept="lc7rE" id="3WaPWglkgWP" role="3cqZAp">
                  <node concept="l9hG8" id="3WaPWglkgWQ" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglkgWR" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglkgWS" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglkgWT" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglkgWU" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglkgWV" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglkgWW" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglkgWX" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglkgWY" role="lcghm">
                    <property role="lacIc" value="= null)" />
                  </node>
                </node>
                <node concept="lc7rE" id="3WaPWglkgX6" role="3cqZAp">
                  <node concept="la8eA" id="3WaPWglkgX7" role="lcghm">
                    <property role="lacIc" value="where " />
                  </node>
                  <node concept="l9hG8" id="3WaPWglkgX8" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglkgX9" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglkgXa" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglkgXb" role="2Oq$k0">
                          <node concept="2OqwBi" id="3WaPWglkgXc" role="2Oq$k0">
                            <node concept="117lpO" id="3WaPWglkgXd" role="2Oq$k0" />
                            <node concept="3TrEf2" id="3WaPWglkgXe" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                            </node>
                          </node>
                          <node concept="3TrEf2" id="3WaPWglkgXf" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglkgXg" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglkgXh" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglkgXi" role="lcghm">
                    <property role="lacIc" value="= select " />
                  </node>
                  <node concept="l9hG8" id="3WaPWglkgXj" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglkgXk" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglkgXl" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglkgXm" role="2Oq$k0">
                          <node concept="2OqwBi" id="3WaPWglkgXn" role="2Oq$k0">
                            <node concept="117lpO" id="3WaPWglkgXo" role="2Oq$k0" />
                            <node concept="3TrEf2" id="3WaPWglkgXp" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                            </node>
                          </node>
                          <node concept="3TrEf2" id="3WaPWglkgXq" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglkgXr" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:3WaPWgleS5k" resolve="dsCategory" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglkgXs" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:51XxSBB9rc0" resolve="locationId" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglkgXt" role="lcghm">
                    <property role="lacIc" value=" from gdpr_datasubject where username='" />
                  </node>
                  <node concept="l9hG8" id="3WaPWglkgXu" role="lcghm">
                    <node concept="2OqwBi" id="3WaPWglkgXv" role="lb14g">
                      <node concept="2OqwBi" id="3WaPWglkgXw" role="2Oq$k0">
                        <node concept="2OqwBi" id="3WaPWglkgXx" role="2Oq$k0">
                          <node concept="117lpO" id="3WaPWglkgXy" role="2Oq$k0" />
                          <node concept="3TrEf2" id="3WaPWglkgXz" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                          </node>
                        </node>
                        <node concept="3TrEf2" id="3WaPWglkgX$" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="3WaPWglkgX_" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="3WaPWglkgXA" role="lcghm">
                    <property role="lacIc" value="';" />
                  </node>
                </node>
                <node concept="3clFbH" id="3WaPWglkfuy" role="3cqZAp" />
                <node concept="3clFbH" id="3WaPWglkgWq" role="3cqZAp" />
              </node>
              <node concept="3clFbC" id="3WaPWglkgHq" role="3clFbw">
                <node concept="Xl_RD" id="3WaPWglkgRf" role="3uHU7w">
                  <property role="Xl_RC" value="erase" />
                </node>
                <node concept="2OqwBi" id="3WaPWglkgii" role="3uHU7B">
                  <node concept="2OqwBi" id="3WaPWglkfVq" role="2Oq$k0">
                    <node concept="2OqwBi" id="3WaPWglkfF2" role="2Oq$k0">
                      <node concept="117lpO" id="3WaPWglkfzM" role="2Oq$k0" />
                      <node concept="3TrEf2" id="3WaPWglkfMC" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:3WaPWglfBO4" resolve="request" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="3WaPWglkg81" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:51XxSBB6uyX" resolve="type" />
                    </node>
                  </node>
                  <node concept="liA8E" id="3WaPWglkgqH" role="2OqNvi">
                    <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
                  </node>
                </node>
              </node>
            </node>
            <node concept="3clFbH" id="3WaPWglkfps" role="3cqZAp" />
          </node>
        </node>
        <node concept="3clFbH" id="3WaPWgljKvc" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWgljKxa" role="3cqZAp" />
        <node concept="3clFbH" id="3WaPWgljKz9" role="3cqZAp" />
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="3WaPWgldDDm">
    <ref role="WuzLi" to="20wa:424h5AVf9rD" resolve="DataRequest" />
    <node concept="29tfMY" id="3WaPWgldDRQ" role="29tGrW">
      <node concept="3clFbS" id="3WaPWgldDRR" role="2VODD2">
        <node concept="3clFbF" id="3WaPWgldDWr" role="3cqZAp">
          <node concept="3cpWs3" id="3WaPWgldWzy" role="3clFbG">
            <node concept="3cpWs3" id="3WaPWgldY5G" role="3uHU7B">
              <node concept="2OqwBi" id="3WaPWgldYg3" role="3uHU7B">
                <node concept="117lpO" id="3WaPWgldY6S" role="2Oq$k0" />
                <node concept="3TrEf2" id="3WaPWgldYpa" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                </node>
              </node>
              <node concept="2OqwBi" id="3WaPWgldZMI" role="3uHU7w">
                <node concept="2OqwBi" id="3WaPWgldEf6" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWgldDWq" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWgldWi6" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                  </node>
                </node>
                <node concept="3TrcHB" id="3WaPWgle024" role="2OqNvi">
                  <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                </node>
              </node>
            </node>
            <node concept="2OqwBi" id="3WaPWgldXg$" role="3uHU7w">
              <node concept="2OqwBi" id="3WaPWgldWZm" role="2Oq$k0">
                <node concept="117lpO" id="3WaPWgldWKo" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWgldX83" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:51XxSBB6uyX" resolve="type" />
                </node>
              </node>
              <node concept="liA8E" id="3WaPWgldXo4" role="2OqNvi">
                <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
              </node>
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="3WaPWgldEGU" role="33IsuW">
      <node concept="3clFbS" id="3WaPWgldEGV" role="2VODD2">
        <node concept="3clFbF" id="3WaPWgldEO4" role="3cqZAp">
          <node concept="Xl_RD" id="3WaPWgldEO3" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
    <node concept="11bSqf" id="3WaPWgldEPa" role="11c4hB">
      <node concept="3clFbS" id="3WaPWgldEPb" role="2VODD2">
        <node concept="3clFbH" id="3WaPWgldP8K" role="3cqZAp" />
        <node concept="lc7rE" id="3WaPWgldF5q" role="3cqZAp">
          <node concept="la8eA" id="3WaPWgldF5I" role="lcghm">
            <property role="lacIc" value="insert into gdpr_datarequest (DataRequestID, claim, newValue, datareqType, datasubject, data) values(" />
          </node>
        </node>
        <node concept="lc7rE" id="3WaPWgldJ8R" role="3cqZAp">
          <node concept="l9hG8" id="1PjvIwH_2_V" role="lcghm">
            <node concept="3cpWs3" id="1PjvIwH_57a" role="lb14g">
              <node concept="Xl_RD" id="1PjvIwH_57e" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="1PjvIwH_2L9" role="3uHU7B">
                <node concept="117lpO" id="1PjvIwH_2DU" role="2Oq$k0" />
                <node concept="3TrcHB" id="1PjvIwH_2U5" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:7bfLM_U99lL" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="1PjvIwH_5Ud" role="lcghm">
            <property role="lacIc" value=", '" />
          </node>
          <node concept="l9hG8" id="3WaPWgldJYl" role="lcghm">
            <node concept="2OqwBi" id="3WaPWgldK9s" role="lb14g">
              <node concept="117lpO" id="3WaPWgldK25" role="2Oq$k0" />
              <node concept="3TrcHB" id="3WaPWgldKio" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:424h5AVf9rk" resolve="claim" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgldKlJ" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWgldL4T" role="lcghm">
            <node concept="2OqwBi" id="3WaPWgldLeV" role="lb14g">
              <node concept="117lpO" id="3WaPWgldL6B" role="2Oq$k0" />
              <node concept="3TrcHB" id="3WaPWgldLnR" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:424h5AVf9rI" resolve="newValue" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgldL$O" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWgldLCH" role="lcghm">
            <node concept="2OqwBi" id="3WaPWgldPAq" role="lb14g">
              <node concept="2OqwBi" id="3WaPWgldLMe" role="2Oq$k0">
                <node concept="117lpO" id="3WaPWgldLER" role="2Oq$k0" />
                <node concept="3TrcHB" id="3WaPWgldLVa" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:51XxSBB6uyX" resolve="type" />
                </node>
              </node>
              <node concept="liA8E" id="3WaPWgldPK9" role="2OqNvi">
                <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgldMdZ" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWgldMix" role="lcghm">
            <node concept="3cpWs3" id="2NO6V5fSoHX" role="lb14g">
              <node concept="Xl_RD" id="2NO6V5fSoI1" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="3WaPWgleL3c" role="3uHU7B">
                <node concept="2OqwBi" id="3WaPWgldM_0" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWgldMtD" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWgldMHW" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:51XxSBB6uy$" resolve="datasubject" />
                  </node>
                </node>
                <node concept="3TrcHB" id="2NO6V5fSo0J" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgldN6x" role="lcghm">
            <property role="lacIc" value="', '" />
          </node>
          <node concept="l9hG8" id="3WaPWgldNcp" role="lcghm">
            <node concept="3cpWs3" id="3WaPWgln8wp" role="lb14g">
              <node concept="Xl_RD" id="3WaPWgln8wt" role="3uHU7w">
                <property role="Xl_RC" value="" />
              </node>
              <node concept="2OqwBi" id="3WaPWgleLvs" role="3uHU7B">
                <node concept="2OqwBi" id="3WaPWgldNiG" role="2Oq$k0">
                  <node concept="117lpO" id="3WaPWgldNfr" role="2Oq$k0" />
                  <node concept="3TrEf2" id="3WaPWgldNsY" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:424h5AVfhA1" resolve="dataReq" />
                  </node>
                </node>
                <node concept="3TrcHB" id="3WaPWgln7nd" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                </node>
              </node>
            </node>
          </node>
          <node concept="la8eA" id="3WaPWgldNOw" role="lcghm">
            <property role="lacIc" value="');" />
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="68$ZZoCA2GX">
    <ref role="WuzLi" to="20wa:68$ZZoCzNiC" resolve="ListPersonalDataCat" />
    <node concept="11bSqf" id="68$ZZoCA2GY" role="11c4hB">
      <node concept="3clFbS" id="68$ZZoCA2GZ" role="2VODD2">
        <node concept="2Gpval" id="68$ZZoCA2Hg" role="3cqZAp">
          <node concept="2GrKxI" id="68$ZZoCA2Hh" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="68$ZZoCA2Hi" role="2GsD0m">
            <node concept="117lpO" id="68$ZZoCA2Hj" role="2Oq$k0" />
            <node concept="3Tsc0h" id="68$ZZoCA3Jp" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:68$ZZoCzNiD" resolve="personalDataCategory" />
            </node>
          </node>
          <node concept="3clFbS" id="68$ZZoCA2Hl" role="2LFqv$">
            <node concept="lc7rE" id="68$ZZoCA2Hm" role="3cqZAp">
              <node concept="la8eA" id="68$ZZoCA2Hn" role="lcghm">
                <property role="lacIc" value="insert into gdpr_PersonalDataCategory(PDCategoryID, personalDataCategory) values (" />
              </node>
              <node concept="l9hG8" id="68$ZZoCA2Ho" role="lcghm">
                <node concept="3cpWs3" id="68$ZZoCAh$W" role="lb14g">
                  <node concept="Xl_RD" id="68$ZZoCAh_0" role="3uHU7w">
                    <property role="Xl_RC" value="" />
                  </node>
                  <node concept="2OqwBi" id="68$ZZoCA2Hp" role="3uHU7B">
                    <node concept="2GrUjf" id="68$ZZoCA2Hq" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="68$ZZoCA2Hh" resolve="e" />
                    </node>
                    <node concept="3TrcHB" id="68$ZZoCAaXv" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:68$ZZoCzNiA" resolve="id" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="68$ZZoCA2Hs" role="lcghm">
                <property role="lacIc" value=", '" />
              </node>
              <node concept="l9hG8" id="68$ZZoCA2Ht" role="lcghm">
                <node concept="2OqwBi" id="68$ZZoCA2Hv" role="lb14g">
                  <node concept="2GrUjf" id="68$ZZoCA2Hx" role="2Oq$k0">
                    <ref role="2Gs0qQ" node="68$ZZoCA2Hh" resolve="e" />
                  </node>
                  <node concept="3TrcHB" id="68$ZZoCAbnc" role="2OqNvi">
                    <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                  </node>
                </node>
              </node>
              <node concept="la8eA" id="68$ZZoCA2Hz" role="lcghm">
                <property role="lacIc" value="');" />
              </node>
              <node concept="l8MVK" id="68$ZZoCA2HP" role="lcghm" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="29tfMY" id="68$ZZoCA4zN" role="29tGrW">
      <node concept="3clFbS" id="68$ZZoCA4zO" role="2VODD2">
        <node concept="3clFbF" id="68$ZZoCA4ER" role="3cqZAp">
          <node concept="Xl_RD" id="68$ZZoCA4EQ" role="3clFbG">
            <property role="Xl_RC" value="Definition of personal data categories" />
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="68$ZZoCA4KY" role="33IsuW">
      <node concept="3clFbS" id="68$ZZoCA4KZ" role="2VODD2">
        <node concept="3clFbF" id="68$ZZoCA5k6" role="3cqZAp">
          <node concept="Xl_RD" id="68$ZZoCA5k5" role="3clFbG">
            <property role="Xl_RC" value="sql" />
          </node>
        </node>
      </node>
    </node>
  </node>
  <node concept="WtQ9Q" id="2pxN2iW2EZ8">
    <ref role="WuzLi" to="20wa:2pxN2iW2EYZ" resolve="Requirements" />
    <node concept="11bSqf" id="2pxN2iW2FXj" role="11c4hB">
      <node concept="3clFbS" id="2pxN2iW2FXk" role="2VODD2">
        <node concept="lc7rE" id="2pxN2iW2FX_" role="3cqZAp">
          <node concept="la8eA" id="2pxN2iW2FXA" role="lcghm">
            <property role="lacIc" value="               USER STORIES                  " />
          </node>
          <node concept="l8MVK" id="2pxN2iW2FXB" role="lcghm" />
          <node concept="l8MVK" id="2pxN2iW2FXC" role="lcghm" />
        </node>
        <node concept="3SKdUt" id="2pxN2iW2FXD" role="3cqZAp">
          <node concept="1PaTwC" id="2pxN2iW2FXE" role="1aUNEU">
            <node concept="3oM_SD" id="2pxN2iW2FXF" role="1PaTwD">
              <property role="3oM_SC" value="ACCESS" />
            </node>
            <node concept="3oM_SD" id="2pxN2iW2FXG" role="1PaTwD">
              <property role="3oM_SC" value="RIGHT" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="2pxN2iW2FXH" role="3cqZAp">
          <node concept="la8eA" id="2pxN2iW2FXI" role="lcghm">
            <property role="lacIc" value="****************** ACCESS RIGHT ******************" />
          </node>
          <node concept="l8MVK" id="2pxN2iW2FXJ" role="lcghm" />
        </node>
        <node concept="3cpWs8" id="2pxN2iW38EN" role="3cqZAp">
          <node concept="3cpWsn" id="2pxN2iW38EO" role="3cpWs9">
            <property role="TrG5h" value="i" />
            <node concept="10Oyi0" id="2pxN2iW38EP" role="1tU5fm" />
            <node concept="3cmrfG" id="2pxN2iW38EQ" role="33vP2m">
              <property role="3cmrfH" value="1" />
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="2pxN2iW2FXT" role="3cqZAp">
          <node concept="2GrKxI" id="2pxN2iW2FXU" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="2$chU367KRU" role="2GsD0m">
            <node concept="2OqwBi" id="2pxN2iW2HeG" role="2Oq$k0">
              <node concept="2OqwBi" id="2pxN2iW2FXW" role="2Oq$k0">
                <node concept="117lpO" id="2pxN2iW2FXX" role="2Oq$k0" />
                <node concept="3TrEf2" id="2pxN2iW2H4r" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:2pxN2iW2EZ1" resolve="listDataType" />
                </node>
              </node>
              <node concept="3Tsc0h" id="2pxN2iW2Hpn" role="2OqNvi">
                <ref role="3TtcxE" to="20wa:3FQc_Nkm_Ez" resolve="dataType" />
              </node>
            </node>
            <node concept="1VAtEI" id="2$chU367MFf" role="2OqNvi" />
          </node>
          <node concept="3clFbS" id="2pxN2iW2FY0" role="2LFqv$">
            <node concept="lc7rE" id="2$chU366I39" role="3cqZAp">
              <node concept="l8MVK" id="2$chU366I5t" role="lcghm" />
            </node>
            <node concept="2Gpval" id="2pxN2iW33e4" role="3cqZAp">
              <node concept="2GrKxI" id="2pxN2iW33e5" role="2Gsz3X">
                <property role="TrG5h" value="f" />
              </node>
              <node concept="2OqwBi" id="2$chU366c2u" role="2GsD0m">
                <node concept="2OqwBi" id="2pxN2iW33e6" role="2Oq$k0">
                  <node concept="2OqwBi" id="2pxN2iW33e7" role="2Oq$k0">
                    <node concept="3Tsc0h" id="2pxN2iW347B" role="2OqNvi">
                      <ref role="3TtcxE" to="20wa:2pxN2iVZd46" resolve="personalData" />
                    </node>
                    <node concept="2GrUjf" id="2pxN2iW33WD" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="2pxN2iW2FXU" resolve="e" />
                    </node>
                  </node>
                  <node concept="13MTOL" id="2pxN2iW33ee" role="2OqNvi">
                    <ref role="13MTZf" to="20wa:2pxN2iW2NcB" resolve="dataSubjectCategory" />
                  </node>
                </node>
                <node concept="1VAtEI" id="2$chU366cvh" role="2OqNvi" />
              </node>
              <node concept="3clFbS" id="2pxN2iW33ef" role="2LFqv$">
                <node concept="lc7rE" id="2$chU365zlH" role="3cqZAp">
                  <node concept="l8MVK" id="2$chU36ha7n" role="lcghm" />
                  <node concept="la8eA" id="2$chU365zo1" role="lcghm">
                    <property role="lacIc" value="-------------- " />
                  </node>
                  <node concept="l9hG8" id="2$chU365zp2" role="lcghm">
                    <node concept="2OqwBi" id="2$chU365zwy" role="lb14g">
                      <node concept="2GrUjf" id="2$chU365zpQ" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2pxN2iW2FXU" resolve="e" />
                      </node>
                      <node concept="3TrcHB" id="2$chU365zXv" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2$chU365$7R" role="lcghm">
                    <property role="lacIc" value=" -------------------" />
                  </node>
                </node>
                <node concept="lc7rE" id="2$chU364wyz" role="3cqZAp">
                  <node concept="la8eA" id="2$chU369Qko" role="lcghm">
                    <property role="lacIc" value="     " />
                  </node>
                  <node concept="l8MVK" id="2$chU364w$R" role="lcghm" />
                </node>
                <node concept="lc7rE" id="2pxN2iW2FXK" role="3cqZAp">
                  <node concept="la8eA" id="2pxN2iW2FXL" role="lcghm">
                    <property role="lacIc" value="AS A " />
                  </node>
                  <node concept="l9hG8" id="2pxN2iW2FXM" role="lcghm">
                    <node concept="2OqwBi" id="2pxN2iW34_G" role="lb14g">
                      <node concept="2GrUjf" id="2pxN2iW34ve" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2pxN2iW33e5" resolve="f" />
                      </node>
                      <node concept="3TrcHB" id="2pxN2iW34KQ" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="l8MVK" id="2pxN2iW2FXQ" role="lcghm" />
                </node>
                <node concept="lc7rE" id="2pxN2iW2FXR" role="3cqZAp">
                  <node concept="la8eA" id="2pxN2iW2FXS" role="lcghm">
                    <property role="lacIc" value="I WANT to acces to all my personal data from which  " />
                  </node>
                  <node concept="l8MVK" id="2$chU369lum" role="lcghm" />
                </node>
                <node concept="2Gpval" id="2pxN2iW3778" role="3cqZAp">
                  <node concept="2GrKxI" id="2pxN2iW3779" role="2Gsz3X">
                    <property role="TrG5h" value="g" />
                  </node>
                  <node concept="3clFbS" id="2pxN2iW377f" role="2LFqv$">
                    <node concept="lc7rE" id="2pxN2iW377g" role="3cqZAp">
                      <node concept="la8eA" id="2$chU36jE4y" role="lcghm">
                        <property role="lacIc" value="     " />
                      </node>
                      <node concept="l9hG8" id="2pxN2iW377h" role="lcghm">
                        <node concept="2GrUjf" id="2pxN2iW377i" role="lb14g">
                          <ref role="2Gs0qQ" node="2pxN2iW3779" resolve="g" />
                        </node>
                      </node>
                      <node concept="la8eA" id="2pxN2iW377j" role="lcghm">
                        <property role="lacIc" value=", " />
                      </node>
                    </node>
                    <node concept="3clFbF" id="2pxN2iW377k" role="3cqZAp">
                      <node concept="37vLTI" id="2pxN2iW377l" role="3clFbG">
                        <node concept="3cpWs3" id="2pxN2iW377m" role="37vLTx">
                          <node concept="3cmrfG" id="2pxN2iW377n" role="3uHU7w">
                            <property role="3cmrfH" value="1" />
                          </node>
                          <node concept="37vLTw" id="2pxN2iW377o" role="3uHU7B">
                            <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                          </node>
                        </node>
                        <node concept="37vLTw" id="2pxN2iW377p" role="37vLTJ">
                          <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                        </node>
                      </node>
                    </node>
                    <node concept="3clFbJ" id="2pxN2iW377q" role="3cqZAp">
                      <node concept="3clFbS" id="2pxN2iW377r" role="3clFbx">
                        <node concept="3clFbF" id="2pxN2iW377s" role="3cqZAp">
                          <node concept="37vLTI" id="2pxN2iW377t" role="3clFbG">
                            <node concept="3cmrfG" id="2pxN2iW377u" role="37vLTx">
                              <property role="3cmrfH" value="1" />
                            </node>
                            <node concept="37vLTw" id="2pxN2iW377v" role="37vLTJ">
                              <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                            </node>
                          </node>
                        </node>
                        <node concept="lc7rE" id="2pxN2iW377w" role="3cqZAp">
                          <node concept="l8MVK" id="2$chU369lch" role="lcghm" />
                        </node>
                      </node>
                      <node concept="3clFbC" id="2pxN2iW377z" role="3clFbw">
                        <node concept="3cmrfG" id="2pxN2iW377$" role="3uHU7w">
                          <property role="3cmrfH" value="5" />
                        </node>
                        <node concept="37vLTw" id="2pxN2iW377_" role="3uHU7B">
                          <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="2OqwBi" id="2pxN2iW389J" role="2GsD0m">
                    <node concept="2GrUjf" id="2pxN2iW3810" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="2pxN2iW2FXU" resolve="e" />
                    </node>
                    <node concept="2qgKlT" id="2pxN2iW38zF" role="2OqNvi">
                      <ref role="37wK5l" to="oniz:5Erw5yfdx17" resolve="ReturnPersonalData" />
                    </node>
                  </node>
                </node>
                <node concept="lc7rE" id="SXiEYPJOdt" role="3cqZAp">
                  <node concept="l8MVK" id="SXiEYPJOdu" role="lcghm" />
                </node>
                <node concept="lc7rE" id="2pxN2iW2FY8" role="3cqZAp">
                  <node concept="la8eA" id="2pxN2iW2FY9" role="lcghm">
                    <property role="lacIc" value="SO THAT I exercise my right of access to all my personal data" />
                  </node>
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="2$chU36g7Y2" role="3cqZAp" />
        <node concept="1X3_iC" id="2$chU36g7vo" role="lGtFl">
          <property role="3V$3am" value="statement" />
          <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
          <node concept="lc7rE" id="2pxN2iW2FY5" role="8Wnug">
            <node concept="la8eA" id="2pxN2iW2FY6" role="lcghm">
              <property role="lacIc" value="." />
            </node>
            <node concept="l8MVK" id="2pxN2iW2FY7" role="lcghm" />
          </node>
        </node>
        <node concept="lc7rE" id="2pxN2iW3b7r" role="3cqZAp">
          <node concept="l8MVK" id="2pxN2iW3b7s" role="lcghm" />
          <node concept="l8MVK" id="2pxN2iW3b7t" role="lcghm" />
        </node>
        <node concept="3clFbH" id="2$chU36e4BW" role="3cqZAp" />
        <node concept="3SKdUt" id="2pxN2iW3b7u" role="3cqZAp">
          <node concept="1PaTwC" id="2pxN2iW3b7v" role="1aUNEU">
            <node concept="3oM_SD" id="2pxN2iW3b7w" role="1PaTwD">
              <property role="3oM_SC" value="RECTIFICATION" />
            </node>
            <node concept="3oM_SD" id="2pxN2iW3b7x" role="1PaTwD">
              <property role="3oM_SC" value="RIGHT" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="2pxN2iW3b7y" role="3cqZAp">
          <node concept="la8eA" id="2pxN2iW3b7z" role="lcghm">
            <property role="lacIc" value="***************** RECTIFICATION RIGHT *****************" />
          </node>
          <node concept="l8MVK" id="2pxN2iW3b7$" role="lcghm" />
        </node>
        <node concept="2Gpval" id="2pxN2iW3a1e" role="3cqZAp">
          <node concept="2GrKxI" id="2pxN2iW3a1f" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="2$chU36aW4o" role="2GsD0m">
            <node concept="2OqwBi" id="2pxN2iW3a1g" role="2Oq$k0">
              <node concept="2OqwBi" id="2pxN2iW3a1h" role="2Oq$k0">
                <node concept="117lpO" id="2pxN2iW3a1i" role="2Oq$k0" />
                <node concept="3TrEf2" id="2pxN2iW3a1j" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:2pxN2iW2EZ1" resolve="listDataType" />
                </node>
              </node>
              <node concept="3Tsc0h" id="2pxN2iW3a1k" role="2OqNvi">
                <ref role="3TtcxE" to="20wa:3FQc_Nkm_Ez" resolve="dataType" />
              </node>
            </node>
            <node concept="1VAtEI" id="2$chU36aXQY" role="2OqNvi" />
          </node>
          <node concept="3clFbS" id="2pxN2iW3a1l" role="2LFqv$">
            <node concept="lc7rE" id="2$chU36bJT4" role="3cqZAp">
              <node concept="l8MVK" id="2$chU36bJT5" role="lcghm" />
            </node>
            <node concept="2Gpval" id="2pxN2iW3a1m" role="3cqZAp">
              <node concept="2GrKxI" id="2pxN2iW3a1n" role="2Gsz3X">
                <property role="TrG5h" value="f" />
              </node>
              <node concept="2OqwBi" id="2$chU36b0jJ" role="2GsD0m">
                <node concept="2OqwBi" id="2pxN2iW3a1o" role="2Oq$k0">
                  <node concept="2OqwBi" id="2pxN2iW3a1p" role="2Oq$k0">
                    <node concept="3Tsc0h" id="2pxN2iW3a1q" role="2OqNvi">
                      <ref role="3TtcxE" to="20wa:2pxN2iVZd46" resolve="personalData" />
                    </node>
                    <node concept="2GrUjf" id="2pxN2iW3a1r" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="2pxN2iW3a1f" resolve="e" />
                    </node>
                  </node>
                  <node concept="13MTOL" id="2pxN2iW3a1s" role="2OqNvi">
                    <ref role="13MTZf" to="20wa:2pxN2iW2NcB" resolve="dataSubjectCategory" />
                  </node>
                </node>
                <node concept="1VAtEI" id="2$chU36b0HI" role="2OqNvi" />
              </node>
              <node concept="3clFbS" id="2pxN2iW3a1t" role="2LFqv$">
                <node concept="lc7rE" id="2$chU36b0Lc" role="3cqZAp">
                  <node concept="l8MVK" id="2$chU36hF8T" role="lcghm" />
                  <node concept="la8eA" id="2$chU36b0Ld" role="lcghm">
                    <property role="lacIc" value="-------------- " />
                  </node>
                  <node concept="l9hG8" id="2$chU36b0Le" role="lcghm">
                    <node concept="2OqwBi" id="2$chU36b0Lf" role="lb14g">
                      <node concept="2GrUjf" id="2$chU36b0Lg" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2pxN2iW3a1f" resolve="e" />
                      </node>
                      <node concept="3TrcHB" id="2$chU36b0Lh" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2$chU36b0Li" role="lcghm">
                    <property role="lacIc" value=" -------------------" />
                  </node>
                </node>
                <node concept="lc7rE" id="2$chU36b0Lj" role="3cqZAp">
                  <node concept="la8eA" id="2$chU36b0Lk" role="lcghm">
                    <property role="lacIc" value="     " />
                  </node>
                  <node concept="l8MVK" id="2$chU36b0Ll" role="lcghm" />
                </node>
                <node concept="lc7rE" id="2$chU36b0Lm" role="3cqZAp">
                  <node concept="la8eA" id="2$chU36b0Ln" role="lcghm">
                    <property role="lacIc" value="AS A " />
                  </node>
                  <node concept="l9hG8" id="2$chU36b0Lo" role="lcghm">
                    <node concept="2OqwBi" id="2$chU36b0Lp" role="lb14g">
                      <node concept="2GrUjf" id="2$chU36b0Lq" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="2pxN2iW3a1n" resolve="f" />
                      </node>
                      <node concept="3TrcHB" id="2$chU36b0Lr" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="l8MVK" id="2$chU36b0Ls" role="lcghm" />
                </node>
                <node concept="lc7rE" id="2pxN2iW3bHH" role="3cqZAp">
                  <node concept="la8eA" id="2pxN2iW3bHI" role="lcghm">
                    <property role="lacIc" value="I want to rectify any of my personal data " />
                  </node>
                  <node concept="l8MVK" id="2pxN2iW3bHJ" role="lcghm" />
                </node>
                <node concept="2Gpval" id="2pxN2iW3a1B" role="3cqZAp">
                  <node concept="2GrKxI" id="2pxN2iW3a1C" role="2Gsz3X">
                    <property role="TrG5h" value="g" />
                  </node>
                  <node concept="3clFbS" id="2pxN2iW3a1D" role="2LFqv$">
                    <node concept="lc7rE" id="2pxN2iW3a1E" role="3cqZAp">
                      <node concept="la8eA" id="2$chU36j9ds" role="lcghm">
                        <property role="lacIc" value="     " />
                      </node>
                      <node concept="l9hG8" id="2pxN2iW3a1F" role="lcghm">
                        <node concept="2GrUjf" id="2pxN2iW3a1G" role="lb14g">
                          <ref role="2Gs0qQ" node="2pxN2iW3a1C" resolve="g" />
                        </node>
                      </node>
                      <node concept="la8eA" id="2pxN2iW3a1H" role="lcghm">
                        <property role="lacIc" value=",  " />
                      </node>
                    </node>
                    <node concept="3clFbF" id="2pxN2iW3a1I" role="3cqZAp">
                      <node concept="37vLTI" id="2pxN2iW3a1J" role="3clFbG">
                        <node concept="3cpWs3" id="2pxN2iW3a1K" role="37vLTx">
                          <node concept="3cmrfG" id="2pxN2iW3a1L" role="3uHU7w">
                            <property role="3cmrfH" value="1" />
                          </node>
                          <node concept="37vLTw" id="2pxN2iW3a1M" role="3uHU7B">
                            <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                          </node>
                        </node>
                        <node concept="37vLTw" id="2pxN2iW3a1N" role="37vLTJ">
                          <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                        </node>
                      </node>
                    </node>
                    <node concept="3clFbJ" id="2pxN2iW3a1O" role="3cqZAp">
                      <node concept="3clFbS" id="2pxN2iW3a1P" role="3clFbx">
                        <node concept="3clFbF" id="2pxN2iW3a1Q" role="3cqZAp">
                          <node concept="37vLTI" id="2pxN2iW3a1R" role="3clFbG">
                            <node concept="3cmrfG" id="2pxN2iW3a1S" role="37vLTx">
                              <property role="3cmrfH" value="1" />
                            </node>
                            <node concept="37vLTw" id="2pxN2iW3a1T" role="37vLTJ">
                              <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                            </node>
                          </node>
                        </node>
                        <node concept="lc7rE" id="2$chU36b11P" role="3cqZAp">
                          <node concept="l8MVK" id="2$chU36b11R" role="lcghm" />
                        </node>
                      </node>
                      <node concept="3clFbC" id="2pxN2iW3a1X" role="3clFbw">
                        <node concept="3cmrfG" id="2pxN2iW3a1Y" role="3uHU7w">
                          <property role="3cmrfH" value="5" />
                        </node>
                        <node concept="37vLTw" id="2pxN2iW3a1Z" role="3uHU7B">
                          <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="2OqwBi" id="2pxN2iW3a22" role="2GsD0m">
                    <node concept="2GrUjf" id="2pxN2iW3a23" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="2pxN2iW3a1f" resolve="e" />
                    </node>
                    <node concept="2qgKlT" id="2pxN2iW3a24" role="2OqNvi">
                      <ref role="37wK5l" to="oniz:5Erw5yfdx17" resolve="ReturnPersonalData" />
                    </node>
                  </node>
                </node>
                <node concept="lc7rE" id="SXiEYPJOer" role="3cqZAp">
                  <node concept="l8MVK" id="SXiEYPJOes" role="lcghm" />
                </node>
                <node concept="lc7rE" id="2pxN2iW3bJh" role="3cqZAp">
                  <node concept="la8eA" id="2pxN2iW3bJi" role="lcghm">
                    <property role="lacIc" value="SO THAT I exercise my right to rectify personal data " />
                  </node>
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="2pxN2iW39HT" role="3cqZAp" />
        <node concept="lc7rE" id="LHr8hYMCw3" role="3cqZAp">
          <node concept="l8MVK" id="LHr8hYMCw4" role="lcghm" />
          <node concept="l8MVK" id="LHr8hYMCw5" role="lcghm" />
        </node>
        <node concept="3SKdUt" id="LHr8hYMCw6" role="3cqZAp">
          <node concept="1PaTwC" id="LHr8hYMCw7" role="1aUNEU">
            <node concept="3oM_SD" id="LHr8hYMDMb" role="1PaTwD">
              <property role="3oM_SC" value="RIGHT" />
            </node>
            <node concept="3oM_SD" id="LHr8hYMDO1" role="1PaTwD">
              <property role="3oM_SC" value="TO" />
            </node>
            <node concept="3oM_SD" id="LHr8hYMDO7" role="1PaTwD">
              <property role="3oM_SC" value="BE" />
            </node>
            <node concept="3oM_SD" id="LHr8hYMDOo" role="1PaTwD">
              <property role="3oM_SC" value="FORGOTTEN" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="LHr8hYMCwa" role="3cqZAp">
          <node concept="la8eA" id="LHr8hYMCwb" role="lcghm">
            <property role="lacIc" value="***************** RIGHT TO BE FORGOTTEN *****************" />
          </node>
          <node concept="l8MVK" id="LHr8hYMCwc" role="lcghm" />
        </node>
        <node concept="2Gpval" id="LHr8hYMCwd" role="3cqZAp">
          <node concept="2GrKxI" id="LHr8hYMCwe" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="2$chU36b2XD" role="2GsD0m">
            <node concept="2OqwBi" id="LHr8hYMCwf" role="2Oq$k0">
              <node concept="2OqwBi" id="LHr8hYMCwg" role="2Oq$k0">
                <node concept="117lpO" id="LHr8hYMCwh" role="2Oq$k0" />
                <node concept="3TrEf2" id="LHr8hYMCwi" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:2pxN2iW2EZ1" resolve="listDataType" />
                </node>
              </node>
              <node concept="3Tsc0h" id="LHr8hYMCwj" role="2OqNvi">
                <ref role="3TtcxE" to="20wa:3FQc_Nkm_Ez" resolve="dataType" />
              </node>
            </node>
            <node concept="1VAtEI" id="2$chU36b4Kf" role="2OqNvi" />
          </node>
          <node concept="3clFbS" id="LHr8hYMCwk" role="2LFqv$">
            <node concept="lc7rE" id="2$chU36bJZP" role="3cqZAp">
              <node concept="l8MVK" id="2$chU36bJZQ" role="lcghm" />
              <node concept="l8MVK" id="2$chU36bJZR" role="lcghm" />
            </node>
            <node concept="2Gpval" id="LHr8hYMCwl" role="3cqZAp">
              <node concept="2GrKxI" id="LHr8hYMCwm" role="2Gsz3X">
                <property role="TrG5h" value="f" />
              </node>
              <node concept="2OqwBi" id="2$chU36b7d0" role="2GsD0m">
                <node concept="2OqwBi" id="LHr8hYMCwn" role="2Oq$k0">
                  <node concept="2OqwBi" id="LHr8hYMCwo" role="2Oq$k0">
                    <node concept="3Tsc0h" id="LHr8hYMCwp" role="2OqNvi">
                      <ref role="3TtcxE" to="20wa:2pxN2iVZd46" resolve="personalData" />
                    </node>
                    <node concept="2GrUjf" id="LHr8hYMCwq" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="LHr8hYMCwe" resolve="e" />
                    </node>
                  </node>
                  <node concept="13MTOL" id="LHr8hYMCwr" role="2OqNvi">
                    <ref role="13MTZf" to="20wa:2pxN2iW2NcB" resolve="dataSubjectCategory" />
                  </node>
                </node>
                <node concept="1VAtEI" id="2$chU36b7AZ" role="2OqNvi" />
              </node>
              <node concept="3clFbS" id="LHr8hYMCws" role="2LFqv$">
                <node concept="lc7rE" id="2$chU36b7Et" role="3cqZAp">
                  <node concept="l8MVK" id="2$chU36hF9a" role="lcghm" />
                  <node concept="la8eA" id="2$chU36b7Eu" role="lcghm">
                    <property role="lacIc" value="-------------" />
                  </node>
                  <node concept="l9hG8" id="2$chU36b7Ev" role="lcghm">
                    <node concept="2OqwBi" id="2$chU36b7Ew" role="lb14g">
                      <node concept="2GrUjf" id="2$chU36b7Ex" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="LHr8hYMCwe" resolve="e" />
                      </node>
                      <node concept="3TrcHB" id="2$chU36b7Ey" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2$chU36b7Ez" role="lcghm">
                    <property role="lacIc" value="-------------------" />
                  </node>
                </node>
                <node concept="lc7rE" id="2$chU36b7E$" role="3cqZAp">
                  <node concept="la8eA" id="2$chU36b7E_" role="lcghm">
                    <property role="lacIc" value="     " />
                  </node>
                  <node concept="l8MVK" id="2$chU36b7EA" role="lcghm" />
                </node>
                <node concept="lc7rE" id="2$chU36b7EB" role="3cqZAp">
                  <node concept="la8eA" id="2$chU36b7EC" role="lcghm">
                    <property role="lacIc" value="AS A " />
                  </node>
                  <node concept="l9hG8" id="2$chU36b7ED" role="lcghm">
                    <node concept="2OqwBi" id="2$chU36b7EE" role="lb14g">
                      <node concept="2GrUjf" id="2$chU36b7EF" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="LHr8hYMCwm" resolve="f" />
                      </node>
                      <node concept="3TrcHB" id="2$chU36b7EG" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="l8MVK" id="2$chU36b7EH" role="lcghm" />
                </node>
                <node concept="lc7rE" id="LHr8hYMCw$" role="3cqZAp">
                  <node concept="la8eA" id="LHr8hYMCw_" role="lcghm">
                    <property role="lacIc" value="I want to erase any of my personal data " />
                  </node>
                  <node concept="l8MVK" id="LHr8hYMCwA" role="lcghm" />
                </node>
                <node concept="2Gpval" id="LHr8hYMCwB" role="3cqZAp">
                  <node concept="2GrKxI" id="LHr8hYMCwC" role="2Gsz3X">
                    <property role="TrG5h" value="g" />
                  </node>
                  <node concept="3clFbS" id="LHr8hYMCwD" role="2LFqv$">
                    <node concept="lc7rE" id="LHr8hYMCwE" role="3cqZAp">
                      <node concept="la8eA" id="2$chU36jE4N" role="lcghm">
                        <property role="lacIc" value="     " />
                      </node>
                      <node concept="l9hG8" id="LHr8hYMCwF" role="lcghm">
                        <node concept="2GrUjf" id="LHr8hYMCwG" role="lb14g">
                          <ref role="2Gs0qQ" node="LHr8hYMCwC" resolve="g" />
                        </node>
                      </node>
                      <node concept="la8eA" id="LHr8hYMCwH" role="lcghm">
                        <property role="lacIc" value=",  " />
                      </node>
                    </node>
                    <node concept="3clFbF" id="LHr8hYMCwI" role="3cqZAp">
                      <node concept="37vLTI" id="LHr8hYMCwJ" role="3clFbG">
                        <node concept="3cpWs3" id="LHr8hYMCwK" role="37vLTx">
                          <node concept="3cmrfG" id="LHr8hYMCwL" role="3uHU7w">
                            <property role="3cmrfH" value="1" />
                          </node>
                          <node concept="37vLTw" id="LHr8hYMCwM" role="3uHU7B">
                            <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                          </node>
                        </node>
                        <node concept="37vLTw" id="LHr8hYMCwN" role="37vLTJ">
                          <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                        </node>
                      </node>
                    </node>
                    <node concept="3clFbJ" id="LHr8hYMCwO" role="3cqZAp">
                      <node concept="3clFbS" id="LHr8hYMCwP" role="3clFbx">
                        <node concept="3clFbF" id="LHr8hYMCwQ" role="3cqZAp">
                          <node concept="37vLTI" id="LHr8hYMCwR" role="3clFbG">
                            <node concept="3cmrfG" id="LHr8hYMCwS" role="37vLTx">
                              <property role="3cmrfH" value="1" />
                            </node>
                            <node concept="37vLTw" id="LHr8hYMCwT" role="37vLTJ">
                              <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                            </node>
                          </node>
                        </node>
                        <node concept="lc7rE" id="2$chU36b7W6" role="3cqZAp">
                          <node concept="l8MVK" id="2$chU36b7W8" role="lcghm" />
                        </node>
                      </node>
                      <node concept="3clFbC" id="LHr8hYMCwX" role="3clFbw">
                        <node concept="3cmrfG" id="LHr8hYMCwY" role="3uHU7w">
                          <property role="3cmrfH" value="5" />
                        </node>
                        <node concept="37vLTw" id="LHr8hYMCwZ" role="3uHU7B">
                          <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="2OqwBi" id="LHr8hYMCx4" role="2GsD0m">
                    <node concept="2GrUjf" id="LHr8hYMCx5" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="LHr8hYMCwe" resolve="e" />
                    </node>
                    <node concept="2qgKlT" id="LHr8hYMCx6" role="2OqNvi">
                      <ref role="37wK5l" to="oniz:5Erw5yfdx17" resolve="ReturnPersonalData" />
                    </node>
                  </node>
                </node>
                <node concept="lc7rE" id="LHr8hYMCx0" role="3cqZAp">
                  <node concept="l8MVK" id="LHr8hYMCx1" role="lcghm" />
                </node>
                <node concept="lc7rE" id="LHr8hYMCx2" role="3cqZAp">
                  <node concept="la8eA" id="LHr8hYMCx3" role="lcghm">
                    <property role="lacIc" value="SO THAT I exercise my right to be forgotten " />
                  </node>
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="LHr8hYMCx8" role="3cqZAp" />
        <node concept="lc7rE" id="LHr8hYME_O" role="3cqZAp">
          <node concept="l8MVK" id="LHr8hYME_P" role="lcghm" />
          <node concept="l8MVK" id="LHr8hYME_Q" role="lcghm" />
        </node>
        <node concept="3SKdUt" id="LHr8hYME_R" role="3cqZAp">
          <node concept="1PaTwC" id="LHr8hYME_S" role="1aUNEU">
            <node concept="3oM_SD" id="LHr8hYMFZI" role="1PaTwD">
              <property role="3oM_SC" value="DATA" />
            </node>
            <node concept="3oM_SD" id="LHr8hYMG1U" role="1PaTwD">
              <property role="3oM_SC" value="PORTABILITY" />
            </node>
            <node concept="3oM_SD" id="LHr8hYMG0e" role="1PaTwD">
              <property role="3oM_SC" value="RIGHT" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="LHr8hYME_X" role="3cqZAp">
          <node concept="la8eA" id="LHr8hYME_Y" role="lcghm">
            <property role="lacIc" value="***************** DATA PORTABILITY RIGHT *****************" />
          </node>
          <node concept="l8MVK" id="LHr8hYME_Z" role="lcghm" />
        </node>
        <node concept="2Gpval" id="LHr8hYMEA0" role="3cqZAp">
          <node concept="2GrKxI" id="LHr8hYMEA1" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="2OqwBi" id="2$chU36b9Mg" role="2GsD0m">
            <node concept="2OqwBi" id="LHr8hYMEA2" role="2Oq$k0">
              <node concept="2OqwBi" id="LHr8hYMEA3" role="2Oq$k0">
                <node concept="117lpO" id="LHr8hYMEA4" role="2Oq$k0" />
                <node concept="3TrEf2" id="LHr8hYMEA5" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:2pxN2iW2EZ1" resolve="listDataType" />
                </node>
              </node>
              <node concept="3Tsc0h" id="LHr8hYMEA6" role="2OqNvi">
                <ref role="3TtcxE" to="20wa:3FQc_Nkm_Ez" resolve="dataType" />
              </node>
            </node>
            <node concept="1VAtEI" id="2$chU36bb$Q" role="2OqNvi" />
          </node>
          <node concept="3clFbS" id="LHr8hYMEA7" role="2LFqv$">
            <node concept="3clFbH" id="2$chU36bK4o" role="3cqZAp" />
            <node concept="2Gpval" id="LHr8hYMEA8" role="3cqZAp">
              <node concept="2GrKxI" id="LHr8hYMEA9" role="2Gsz3X">
                <property role="TrG5h" value="f" />
              </node>
              <node concept="2OqwBi" id="2$chU36be1B" role="2GsD0m">
                <node concept="2OqwBi" id="LHr8hYMEAa" role="2Oq$k0">
                  <node concept="2OqwBi" id="LHr8hYMEAb" role="2Oq$k0">
                    <node concept="3Tsc0h" id="LHr8hYMEAc" role="2OqNvi">
                      <ref role="3TtcxE" to="20wa:2pxN2iVZd46" resolve="personalData" />
                    </node>
                    <node concept="2GrUjf" id="LHr8hYMEAd" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="LHr8hYMEA1" resolve="e" />
                    </node>
                  </node>
                  <node concept="13MTOL" id="LHr8hYMEAe" role="2OqNvi">
                    <ref role="13MTZf" to="20wa:2pxN2iW2NcB" resolve="dataSubjectCategory" />
                  </node>
                </node>
                <node concept="1VAtEI" id="2$chU36benJ" role="2OqNvi" />
              </node>
              <node concept="3clFbS" id="LHr8hYMEAf" role="2LFqv$">
                <node concept="lc7rE" id="2$chU36berd" role="3cqZAp">
                  <node concept="l8MVK" id="2$chU36hF9r" role="lcghm" />
                  <node concept="la8eA" id="2$chU36bere" role="lcghm">
                    <property role="lacIc" value="-------------" />
                  </node>
                  <node concept="l9hG8" id="2$chU36berf" role="lcghm">
                    <node concept="2OqwBi" id="2$chU36berg" role="lb14g">
                      <node concept="2GrUjf" id="2$chU36berh" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="LHr8hYMEA1" resolve="e" />
                      </node>
                      <node concept="3TrcHB" id="2$chU36beri" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="2$chU36berj" role="lcghm">
                    <property role="lacIc" value="-------------------" />
                  </node>
                </node>
                <node concept="lc7rE" id="2$chU36berk" role="3cqZAp">
                  <node concept="la8eA" id="2$chU36berl" role="lcghm">
                    <property role="lacIc" value="     " />
                  </node>
                  <node concept="l8MVK" id="2$chU36berm" role="lcghm" />
                </node>
                <node concept="lc7rE" id="2$chU36bern" role="3cqZAp">
                  <node concept="la8eA" id="2$chU36bero" role="lcghm">
                    <property role="lacIc" value="AS A " />
                  </node>
                  <node concept="l9hG8" id="2$chU36berp" role="lcghm">
                    <node concept="2OqwBi" id="2$chU36berq" role="lb14g">
                      <node concept="2GrUjf" id="2$chU36berr" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="LHr8hYMEA9" resolve="f" />
                      </node>
                      <node concept="3TrcHB" id="2$chU36bers" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="l8MVK" id="2$chU36bert" role="lcghm" />
                </node>
                <node concept="lc7rE" id="LHr8hYMEAn" role="3cqZAp">
                  <node concept="la8eA" id="LHr8hYMEAo" role="lcghm">
                    <property role="lacIc" value="I want to obtain any of my personal data " />
                  </node>
                  <node concept="l8MVK" id="LHr8hYMEAp" role="lcghm" />
                </node>
                <node concept="2Gpval" id="LHr8hYMEAq" role="3cqZAp">
                  <node concept="2GrKxI" id="LHr8hYMEAr" role="2Gsz3X">
                    <property role="TrG5h" value="g" />
                  </node>
                  <node concept="3clFbS" id="LHr8hYMEAs" role="2LFqv$">
                    <node concept="lc7rE" id="LHr8hYMEAt" role="3cqZAp">
                      <node concept="la8eA" id="2$chU36jE54" role="lcghm">
                        <property role="lacIc" value="     " />
                      </node>
                      <node concept="l9hG8" id="LHr8hYMEAu" role="lcghm">
                        <node concept="2GrUjf" id="LHr8hYMEAv" role="lb14g">
                          <ref role="2Gs0qQ" node="LHr8hYMEAr" resolve="g" />
                        </node>
                      </node>
                      <node concept="la8eA" id="LHr8hYMEAw" role="lcghm">
                        <property role="lacIc" value=",  " />
                      </node>
                    </node>
                    <node concept="3clFbF" id="LHr8hYMEAx" role="3cqZAp">
                      <node concept="37vLTI" id="LHr8hYMEAy" role="3clFbG">
                        <node concept="3cpWs3" id="LHr8hYMEAz" role="37vLTx">
                          <node concept="3cmrfG" id="LHr8hYMEA$" role="3uHU7w">
                            <property role="3cmrfH" value="1" />
                          </node>
                          <node concept="37vLTw" id="LHr8hYMEA_" role="3uHU7B">
                            <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                          </node>
                        </node>
                        <node concept="37vLTw" id="LHr8hYMEAA" role="37vLTJ">
                          <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                        </node>
                      </node>
                    </node>
                    <node concept="3clFbJ" id="LHr8hYMEAB" role="3cqZAp">
                      <node concept="3clFbS" id="LHr8hYMEAC" role="3clFbx">
                        <node concept="3clFbF" id="LHr8hYMEAD" role="3cqZAp">
                          <node concept="37vLTI" id="LHr8hYMEAE" role="3clFbG">
                            <node concept="3cmrfG" id="LHr8hYMEAF" role="37vLTx">
                              <property role="3cmrfH" value="1" />
                            </node>
                            <node concept="37vLTw" id="LHr8hYMEAG" role="37vLTJ">
                              <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                            </node>
                          </node>
                        </node>
                        <node concept="lc7rE" id="2$chU36beRo" role="3cqZAp">
                          <node concept="l8MVK" id="2$chU36beRq" role="lcghm" />
                        </node>
                      </node>
                      <node concept="3clFbC" id="LHr8hYMEAK" role="3clFbw">
                        <node concept="3cmrfG" id="LHr8hYMEAL" role="3uHU7w">
                          <property role="3cmrfH" value="5" />
                        </node>
                        <node concept="37vLTw" id="LHr8hYMEAM" role="3uHU7B">
                          <ref role="3cqZAo" node="2pxN2iW38EO" resolve="i" />
                        </node>
                      </node>
                    </node>
                  </node>
                  <node concept="2OqwBi" id="LHr8hYMEAR" role="2GsD0m">
                    <node concept="2GrUjf" id="LHr8hYMEAS" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="LHr8hYMEA1" resolve="e" />
                    </node>
                    <node concept="2qgKlT" id="LHr8hYMEAT" role="2OqNvi">
                      <ref role="37wK5l" to="oniz:5Erw5yfdx17" resolve="ReturnPersonalData" />
                    </node>
                  </node>
                </node>
                <node concept="lc7rE" id="LHr8hYMEAN" role="3cqZAp">
                  <node concept="l8MVK" id="LHr8hYMEAO" role="lcghm" />
                </node>
                <node concept="lc7rE" id="LHr8hYMEAP" role="3cqZAp">
                  <node concept="la8eA" id="LHr8hYMEAQ" role="lcghm">
                    <property role="lacIc" value="SO THAT I exercise my right to personal data portability" />
                  </node>
                </node>
                <node concept="3clFbH" id="506pcQt__u7" role="3cqZAp" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="506pcQtxoiD" role="3cqZAp" />
        <node concept="3clFbH" id="506pcQtxoEg" role="3cqZAp" />
        <node concept="lc7rE" id="506pcQt$UMT" role="3cqZAp">
          <node concept="l8MVK" id="506pcQt_yKQ" role="lcghm" />
          <node concept="l8MVK" id="506pcQtAKSe" role="lcghm" />
          <node concept="l8MVK" id="506pcQtAL8U" role="lcghm" />
          <node concept="la8eA" id="506pcQt$VdU" role="lcghm">
            <property role="lacIc" value="              ********** Processing Right **********" />
          </node>
          <node concept="l8MVK" id="506pcQt_z1u" role="lcghm" />
        </node>
        <node concept="3SKdUt" id="506pcQt_zI9" role="3cqZAp">
          <node concept="1PaTwC" id="506pcQt_zIa" role="1aUNEU">
            <node concept="3oM_SD" id="506pcQt_zNV" role="1PaTwD">
              <property role="3oM_SC" value="" />
            </node>
            <node concept="3oM_SD" id="506pcQt_$8P" role="1PaTwD">
              <property role="3oM_SC" value="KNOWLEDGE" />
            </node>
            <node concept="3oM_SD" id="506pcQt_$b9" role="1PaTwD">
              <property role="3oM_SC" value="RIGHT" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="506pcQt_$bt" role="3cqZAp">
          <node concept="la8eA" id="506pcQt_$JY" role="lcghm">
            <property role="lacIc" value="****** KNOWLEDGE RIGHT **********" />
          </node>
          <node concept="l8MVK" id="506pcQtAKvf" role="lcghm" />
        </node>
        <node concept="3clFbH" id="506pcQtAJC$" role="3cqZAp" />
        <node concept="1_o_46" id="506pcQt__xb" role="3cqZAp">
          <node concept="1_o_bx" id="506pcQt__xd" role="1_o_by">
            <node concept="1_o_bG" id="506pcQt__xf" role="1_o_aQ">
              <property role="TrG5h" value="e" />
            </node>
            <node concept="2OqwBi" id="506pcQtGcdA" role="1_o_bz">
              <node concept="2OqwBi" id="506pcQt_AA0" role="2Oq$k0">
                <node concept="2OqwBi" id="506pcQt_Aec" role="2Oq$k0">
                  <node concept="117lpO" id="506pcQt_A6D" role="2Oq$k0" />
                  <node concept="3TrEf2" id="506pcQt_Alv" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:506pcQtxmXV" resolve="listProcessing" />
                  </node>
                </node>
                <node concept="3Tsc0h" id="506pcQt_AJ4" role="2OqNvi">
                  <ref role="3TtcxE" to="20wa:506pcQtus8w" resolve="processing" />
                </node>
              </node>
              <node concept="1VAtEI" id="506pcQtGe4l" role="2OqNvi" />
            </node>
          </node>
          <node concept="3clFbS" id="506pcQt__xj" role="2LFqv$">
            <node concept="lc7rE" id="506pcQt_DA0" role="3cqZAp">
              <node concept="l8MVK" id="506pcQt_DAB" role="lcghm" />
            </node>
            <node concept="3clFbH" id="506pcQtJoRU" role="3cqZAp" />
            <node concept="3clFbH" id="506pcQtJoSH" role="3cqZAp" />
            <node concept="1_o_46" id="506pcQtEKbP" role="3cqZAp">
              <node concept="1_o_bx" id="506pcQtEKbR" role="1_o_by">
                <node concept="1_o_bG" id="506pcQtEKbT" role="1_o_aQ">
                  <property role="TrG5h" value="f" />
                </node>
                <node concept="2OqwBi" id="506pcQtKS8x" role="1_o_bz">
                  <node concept="2OqwBi" id="506pcQtKRxX" role="2Oq$k0">
                    <node concept="2OqwBi" id="506pcQtKPw3" role="2Oq$k0">
                      <node concept="2OqwBi" id="506pcQtEPqB" role="2Oq$k0">
                        <node concept="2OqwBi" id="506pcQtEKJU" role="2Oq$k0">
                          <node concept="3M$PaV" id="506pcQtEKdg" role="2Oq$k0">
                            <ref role="3M$S_o" node="506pcQt__xf" resolve="e" />
                          </node>
                          <node concept="3TrEf2" id="506pcQtKNPa" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:424h5AVfh_Z" resolve="processing" />
                          </node>
                        </node>
                        <node concept="3Tsc0h" id="506pcQtKOm8" role="2OqNvi">
                          <ref role="3TtcxE" to="20wa:5VnHNHVgh9G" resolve="dataUsedPd" />
                        </node>
                      </node>
                      <node concept="13MTOL" id="506pcQtKQTn" role="2OqNvi">
                        <ref role="13MTZf" to="20wa:2olOl3C1TdP" resolve="dataref1" />
                      </node>
                    </node>
                    <node concept="13MTOL" id="506pcQtKRK9" role="2OqNvi">
                      <ref role="13MTZf" to="20wa:2pxN2iW2NcB" resolve="dataSubjectCategory" />
                    </node>
                  </node>
                  <node concept="1VAtEI" id="506pcQtKSuy" role="2OqNvi" />
                </node>
              </node>
              <node concept="3clFbS" id="506pcQtEKbX" role="2LFqv$">
                <node concept="lc7rE" id="506pcQtEPFw" role="3cqZAp">
                  <node concept="la8eA" id="506pcQtEPFO" role="lcghm">
                    <property role="lacIc" value="as a " />
                  </node>
                  <node concept="l9hG8" id="506pcQtEPGD" role="lcghm">
                    <node concept="2OqwBi" id="506pcQtEPOc" role="lb14g">
                      <node concept="3M$PaV" id="506pcQtEPHw" role="2Oq$k0">
                        <ref role="3M$S_o" node="506pcQtEKbT" resolve="f" />
                      </node>
                      <node concept="3TrcHB" id="506pcQtEQ8p" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="l8MVK" id="506pcQtEQfs" role="lcghm" />
                </node>
                <node concept="lc7rE" id="506pcQtEQgx" role="3cqZAp">
                  <node concept="la8eA" id="506pcQtERlf" role="lcghm">
                    <property role="lacIc" value="     " />
                  </node>
                  <node concept="la8eA" id="506pcQtEQgy" role="lcghm">
                    <property role="lacIc" value="I want to know all information about &quot;" />
                  </node>
                </node>
                <node concept="lc7rE" id="506pcQtEQhu" role="3cqZAp">
                  <node concept="l9hG8" id="506pcQtEQkR" role="lcghm">
                    <node concept="2OqwBi" id="506pcQtEQVd" role="lb14g">
                      <node concept="2OqwBi" id="506pcQtEQrJ" role="2Oq$k0">
                        <node concept="3M$PaV" id="506pcQtEQlH" role="2Oq$k0">
                          <ref role="3M$S_o" node="506pcQt__xf" resolve="e" />
                        </node>
                        <node concept="3TrEf2" id="506pcQtEQJu" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:424h5AVfh_Z" resolve="processing" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="506pcQtER7D" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="506pcQtERb7" role="lcghm">
                    <property role="lacIc" value="&quot;" />
                  </node>
                  <node concept="l8MVK" id="506pcQtFxV7" role="lcghm" />
                </node>
                <node concept="lc7rE" id="506pcQtERcJ" role="3cqZAp">
                  <node concept="la8eA" id="506pcQtERm6" role="lcghm">
                    <property role="lacIc" value="     " />
                  </node>
                  <node concept="la8eA" id="506pcQtERdo" role="lcghm">
                    <property role="lacIc" value="such as : Purposes, personal data used, provider and datareceivers information" />
                  </node>
                  <node concept="l8MVK" id="506pcQtERkC" role="lcghm" />
                </node>
                <node concept="lc7rE" id="506pcQtERmT" role="3cqZAp">
                  <node concept="la8eA" id="506pcQtERnB" role="lcghm">
                    <property role="lacIc" value="SO THAT I exercise my right to knowledge" />
                  </node>
                  <node concept="l8MVK" id="506pcQtFxVO" role="lcghm" />
                </node>
                <node concept="3clFbH" id="506pcQtEQfO" role="3cqZAp" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3clFbH" id="506pcQtMNFf" role="3cqZAp" />
        <node concept="3SKdUt" id="506pcQtMOV6" role="3cqZAp">
          <node concept="1PaTwC" id="506pcQtMOV7" role="1aUNEU">
            <node concept="3oM_SD" id="506pcQtMPI1" role="1PaTwD">
              <property role="3oM_SC" value="" />
            </node>
            <node concept="3oM_SD" id="506pcQtMPI3" role="1PaTwD">
              <property role="3oM_SC" value="DATASUBJECT'" />
            </node>
            <node concept="3oM_SD" id="506pcQtMPK8" role="1PaTwD">
              <property role="3oM_SC" value="RIGHT" />
            </node>
            <node concept="3oM_SD" id="506pcQtMPL0" role="1PaTwD">
              <property role="3oM_SC" value="TO" />
            </node>
            <node concept="3oM_SD" id="506pcQtMPLe" role="1PaTwD">
              <property role="3oM_SC" value="GIVE" />
            </node>
            <node concept="3oM_SD" id="506pcQtMPLT" role="1PaTwD">
              <property role="3oM_SC" value="AND" />
            </node>
            <node concept="3oM_SD" id="506pcQtMPNs" role="1PaTwD">
              <property role="3oM_SC" value="WITHDRAW" />
            </node>
            <node concept="3oM_SD" id="506pcQtMPPZ" role="1PaTwD">
              <property role="3oM_SC" value="CONSENT" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="506pcQtMOVb" role="3cqZAp">
          <node concept="l8MVK" id="506pcQtOW4D" role="lcghm" />
          <node concept="l8MVK" id="506pcQtOW_E" role="lcghm" />
          <node concept="la8eA" id="506pcQtMOVc" role="lcghm">
            <property role="lacIc" value="****** RIGHT TO GIVE AND WITHDRAW CONSENT **********" />
          </node>
          <node concept="l8MVK" id="506pcQtMOVd" role="lcghm" />
        </node>
        <node concept="3clFbH" id="506pcQtMOVe" role="3cqZAp" />
        <node concept="1_o_46" id="506pcQtMOVf" role="3cqZAp">
          <node concept="1_o_bx" id="506pcQtMOVg" role="1_o_by">
            <node concept="1_o_bG" id="506pcQtMOVh" role="1_o_aQ">
              <property role="TrG5h" value="e" />
            </node>
            <node concept="2OqwBi" id="506pcQtMOVi" role="1_o_bz">
              <node concept="2OqwBi" id="506pcQtMOVj" role="2Oq$k0">
                <node concept="2OqwBi" id="506pcQtMOVk" role="2Oq$k0">
                  <node concept="117lpO" id="506pcQtMOVl" role="2Oq$k0" />
                  <node concept="3TrEf2" id="506pcQtMOVm" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:506pcQtxmXV" resolve="listProcessing" />
                  </node>
                </node>
                <node concept="3Tsc0h" id="506pcQtMOVn" role="2OqNvi">
                  <ref role="3TtcxE" to="20wa:506pcQtus8w" resolve="processing" />
                </node>
              </node>
              <node concept="1VAtEI" id="506pcQtMOVo" role="2OqNvi" />
            </node>
          </node>
          <node concept="3clFbS" id="506pcQtMOVp" role="2LFqv$">
            <node concept="lc7rE" id="506pcQtMOVq" role="3cqZAp">
              <node concept="l8MVK" id="506pcQtMOVr" role="lcghm" />
            </node>
            <node concept="3clFbJ" id="506pcQtMPQk" role="3cqZAp">
              <node concept="3clFbS" id="506pcQtMPQm" role="3clFbx">
                <node concept="1_o_46" id="506pcQtMOVu" role="3cqZAp">
                  <node concept="1_o_bx" id="506pcQtMOVv" role="1_o_by">
                    <node concept="1_o_bG" id="506pcQtMOVw" role="1_o_aQ">
                      <property role="TrG5h" value="f" />
                    </node>
                    <node concept="2OqwBi" id="506pcQtMOVx" role="1_o_bz">
                      <node concept="2OqwBi" id="506pcQtMOVy" role="2Oq$k0">
                        <node concept="2OqwBi" id="506pcQtMOVz" role="2Oq$k0">
                          <node concept="2OqwBi" id="506pcQtMOV$" role="2Oq$k0">
                            <node concept="2OqwBi" id="506pcQtMOV_" role="2Oq$k0">
                              <node concept="3M$PaV" id="506pcQtMOVA" role="2Oq$k0">
                                <ref role="3M$S_o" node="506pcQtMOVh" resolve="e" />
                              </node>
                              <node concept="3TrEf2" id="506pcQtMOVB" role="2OqNvi">
                                <ref role="3Tt5mk" to="20wa:424h5AVfh_Z" resolve="processing" />
                              </node>
                            </node>
                            <node concept="3Tsc0h" id="506pcQtMOVC" role="2OqNvi">
                              <ref role="3TtcxE" to="20wa:5VnHNHVgh9G" resolve="dataUsedPd" />
                            </node>
                          </node>
                          <node concept="13MTOL" id="506pcQtMOVD" role="2OqNvi">
                            <ref role="13MTZf" to="20wa:2olOl3C1TdP" resolve="dataref1" />
                          </node>
                        </node>
                        <node concept="13MTOL" id="506pcQtMOVE" role="2OqNvi">
                          <ref role="13MTZf" to="20wa:2pxN2iW2NcB" resolve="dataSubjectCategory" />
                        </node>
                      </node>
                      <node concept="1VAtEI" id="506pcQtMOVF" role="2OqNvi" />
                    </node>
                  </node>
                  <node concept="3clFbS" id="506pcQtMOVG" role="2LFqv$">
                    <node concept="lc7rE" id="506pcQtMOVH" role="3cqZAp">
                      <node concept="la8eA" id="506pcQtMOVI" role="lcghm">
                        <property role="lacIc" value="as a " />
                      </node>
                      <node concept="l9hG8" id="506pcQtMOVJ" role="lcghm">
                        <node concept="2OqwBi" id="506pcQtMOVK" role="lb14g">
                          <node concept="3M$PaV" id="506pcQtMOVL" role="2Oq$k0">
                            <ref role="3M$S_o" node="506pcQtMOVw" resolve="f" />
                          </node>
                          <node concept="3TrcHB" id="506pcQtMOVM" role="2OqNvi">
                            <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                          </node>
                        </node>
                      </node>
                      <node concept="l8MVK" id="506pcQtMOVN" role="lcghm" />
                    </node>
                    <node concept="lc7rE" id="506pcQtMOVO" role="3cqZAp">
                      <node concept="la8eA" id="506pcQtMOVP" role="lcghm">
                        <property role="lacIc" value="     " />
                      </node>
                      <node concept="la8eA" id="506pcQtMOVQ" role="lcghm">
                        <property role="lacIc" value="I want to give or not and withdraw my consent anytime for &quot;" />
                      </node>
                    </node>
                    <node concept="lc7rE" id="506pcQtMOVR" role="3cqZAp">
                      <node concept="l9hG8" id="506pcQtMOVS" role="lcghm">
                        <node concept="2OqwBi" id="506pcQtMOVT" role="lb14g">
                          <node concept="2OqwBi" id="506pcQtMOVU" role="2Oq$k0">
                            <node concept="3M$PaV" id="506pcQtMOVV" role="2Oq$k0">
                              <ref role="3M$S_o" node="506pcQtMOVh" resolve="e" />
                            </node>
                            <node concept="3TrEf2" id="506pcQtMOVW" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:424h5AVfh_Z" resolve="processing" />
                            </node>
                          </node>
                          <node concept="3TrcHB" id="506pcQtMOVX" role="2OqNvi">
                            <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                          </node>
                        </node>
                      </node>
                      <node concept="la8eA" id="506pcQtMOVY" role="lcghm">
                        <property role="lacIc" value="&quot;" />
                      </node>
                      <node concept="l8MVK" id="506pcQtMOVZ" role="lcghm" />
                    </node>
                    <node concept="lc7rE" id="506pcQtMOW4" role="3cqZAp">
                      <node concept="la8eA" id="506pcQtMOW5" role="lcghm">
                        <property role="lacIc" value="SO THAT I exercise my right to consent" />
                      </node>
                      <node concept="l8MVK" id="506pcQtMOW6" role="lcghm" />
                    </node>
                    <node concept="3clFbH" id="506pcQtMOW7" role="3cqZAp" />
                  </node>
                </node>
                <node concept="3clFbH" id="506pcQtMPQl" role="3cqZAp" />
              </node>
              <node concept="3clFbC" id="506pcQtNBLS" role="3clFbw">
                <node concept="Xl_RD" id="506pcQtNBQf" role="3uHU7w">
                  <property role="Xl_RC" value="Consent_Contract" />
                </node>
                <node concept="2OqwBi" id="506pcQtMTXa" role="3uHU7B">
                  <node concept="2OqwBi" id="506pcQtMQzJ" role="2Oq$k0">
                    <node concept="2OqwBi" id="506pcQtMQ0n" role="2Oq$k0">
                      <node concept="3M$PaV" id="506pcQtMPRt" role="2Oq$k0">
                        <ref role="3M$S_o" node="506pcQtMOVh" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="506pcQtMQlS" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:424h5AVfh_Z" resolve="processing" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="506pcQtMQM7" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVgh99" resolve="pc" />
                    </node>
                  </node>
                  <node concept="liA8E" id="506pcQtMVZL" role="2OqNvi">
                    <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
                  </node>
                </node>
              </node>
            </node>
            <node concept="3clFbH" id="506pcQtMOVt" role="3cqZAp" />
          </node>
        </node>
        <node concept="3clFbH" id="506pcQtMNM1" role="3cqZAp" />
        <node concept="3SKdUt" id="506pcQtOWIE" role="3cqZAp">
          <node concept="1PaTwC" id="506pcQtOWIF" role="1aUNEU">
            <node concept="3oM_SD" id="506pcQtOWIG" role="1PaTwD">
              <property role="3oM_SC" value="" />
            </node>
            <node concept="3oM_SD" id="506pcQtOWIH" role="1PaTwD">
              <property role="3oM_SC" value="OPPOSITION" />
            </node>
            <node concept="3oM_SD" id="506pcQtOWII" role="1PaTwD">
              <property role="3oM_SC" value="RIGHT" />
            </node>
            <node concept="3oM_SD" id="506pcQtOXNM" role="1PaTwD">
              <property role="3oM_SC" value="" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="506pcQtOWIO" role="3cqZAp">
          <node concept="l8MVK" id="506pcQtOWIP" role="lcghm" />
          <node concept="l8MVK" id="506pcQtOWIQ" role="lcghm" />
          <node concept="la8eA" id="506pcQtOWIR" role="lcghm">
            <property role="lacIc" value="****** OPPOSITION RIGHT **********" />
          </node>
          <node concept="l8MVK" id="506pcQtOWIS" role="lcghm" />
        </node>
        <node concept="3clFbH" id="506pcQtOWIT" role="3cqZAp" />
        <node concept="1_o_46" id="506pcQtOWIU" role="3cqZAp">
          <node concept="1_o_bx" id="506pcQtOWIV" role="1_o_by">
            <node concept="1_o_bG" id="506pcQtOWIW" role="1_o_aQ">
              <property role="TrG5h" value="e" />
            </node>
            <node concept="2OqwBi" id="506pcQtOWIX" role="1_o_bz">
              <node concept="2OqwBi" id="506pcQtOWIY" role="2Oq$k0">
                <node concept="2OqwBi" id="506pcQtOWIZ" role="2Oq$k0">
                  <node concept="117lpO" id="506pcQtOWJ0" role="2Oq$k0" />
                  <node concept="3TrEf2" id="506pcQtOWJ1" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:506pcQtxmXV" resolve="listProcessing" />
                  </node>
                </node>
                <node concept="3Tsc0h" id="506pcQtOWJ2" role="2OqNvi">
                  <ref role="3TtcxE" to="20wa:506pcQtus8w" resolve="processing" />
                </node>
              </node>
              <node concept="1VAtEI" id="506pcQtOWJ3" role="2OqNvi" />
            </node>
          </node>
          <node concept="3clFbS" id="506pcQtOWJ4" role="2LFqv$">
            <node concept="lc7rE" id="506pcQtOWJ5" role="3cqZAp">
              <node concept="l8MVK" id="506pcQtOWJ6" role="lcghm" />
            </node>
            <node concept="3clFbJ" id="506pcQtOWJ7" role="3cqZAp">
              <node concept="3clFbS" id="506pcQtOWJ8" role="3clFbx">
                <node concept="1_o_46" id="506pcQtOWJ9" role="3cqZAp">
                  <node concept="1_o_bx" id="506pcQtOWJa" role="1_o_by">
                    <node concept="1_o_bG" id="506pcQtOWJb" role="1_o_aQ">
                      <property role="TrG5h" value="f" />
                    </node>
                    <node concept="2OqwBi" id="506pcQtOWJc" role="1_o_bz">
                      <node concept="2OqwBi" id="506pcQtOWJd" role="2Oq$k0">
                        <node concept="2OqwBi" id="506pcQtOWJe" role="2Oq$k0">
                          <node concept="2OqwBi" id="506pcQtOWJf" role="2Oq$k0">
                            <node concept="2OqwBi" id="506pcQtOWJg" role="2Oq$k0">
                              <node concept="3M$PaV" id="506pcQtOWJh" role="2Oq$k0">
                                <ref role="3M$S_o" node="506pcQtOWIW" resolve="e" />
                              </node>
                              <node concept="3TrEf2" id="506pcQtOWJi" role="2OqNvi">
                                <ref role="3Tt5mk" to="20wa:424h5AVfh_Z" resolve="processing" />
                              </node>
                            </node>
                            <node concept="3Tsc0h" id="506pcQtOWJj" role="2OqNvi">
                              <ref role="3TtcxE" to="20wa:5VnHNHVgh9G" resolve="dataUsedPd" />
                            </node>
                          </node>
                          <node concept="13MTOL" id="506pcQtOWJk" role="2OqNvi">
                            <ref role="13MTZf" to="20wa:2olOl3C1TdP" resolve="dataref1" />
                          </node>
                        </node>
                        <node concept="13MTOL" id="506pcQtOWJl" role="2OqNvi">
                          <ref role="13MTZf" to="20wa:2pxN2iW2NcB" resolve="dataSubjectCategory" />
                        </node>
                      </node>
                      <node concept="1VAtEI" id="506pcQtOWJm" role="2OqNvi" />
                    </node>
                  </node>
                  <node concept="3clFbS" id="506pcQtOWJn" role="2LFqv$">
                    <node concept="lc7rE" id="506pcQtOWJo" role="3cqZAp">
                      <node concept="la8eA" id="506pcQtOWJp" role="lcghm">
                        <property role="lacIc" value="as a " />
                      </node>
                      <node concept="l9hG8" id="506pcQtOWJq" role="lcghm">
                        <node concept="2OqwBi" id="506pcQtOWJr" role="lb14g">
                          <node concept="3M$PaV" id="506pcQtOWJs" role="2Oq$k0">
                            <ref role="3M$S_o" node="506pcQtOWJb" resolve="f" />
                          </node>
                          <node concept="3TrcHB" id="506pcQtOWJt" role="2OqNvi">
                            <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                          </node>
                        </node>
                      </node>
                      <node concept="l8MVK" id="506pcQtOWJu" role="lcghm" />
                    </node>
                    <node concept="lc7rE" id="506pcQtOWJv" role="3cqZAp">
                      <node concept="la8eA" id="506pcQtOWJw" role="lcghm">
                        <property role="lacIc" value="     " />
                      </node>
                      <node concept="la8eA" id="506pcQtOWJx" role="lcghm">
                        <property role="lacIc" value="I want oppose to &quot;" />
                      </node>
                    </node>
                    <node concept="lc7rE" id="506pcQtOWJy" role="3cqZAp">
                      <node concept="l9hG8" id="506pcQtOWJz" role="lcghm">
                        <node concept="2OqwBi" id="506pcQtOWJ$" role="lb14g">
                          <node concept="2OqwBi" id="506pcQtOWJ_" role="2Oq$k0">
                            <node concept="3M$PaV" id="506pcQtOWJA" role="2Oq$k0">
                              <ref role="3M$S_o" node="506pcQtOWIW" resolve="e" />
                            </node>
                            <node concept="3TrEf2" id="506pcQtOWJB" role="2OqNvi">
                              <ref role="3Tt5mk" to="20wa:424h5AVfh_Z" resolve="processing" />
                            </node>
                          </node>
                          <node concept="3TrcHB" id="506pcQtOWJC" role="2OqNvi">
                            <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                          </node>
                        </node>
                      </node>
                      <node concept="la8eA" id="506pcQtOWJD" role="lcghm">
                        <property role="lacIc" value="&quot;" />
                      </node>
                      <node concept="l8MVK" id="506pcQtOWJE" role="lcghm" />
                    </node>
                    <node concept="lc7rE" id="506pcQtOWJF" role="3cqZAp">
                      <node concept="la8eA" id="506pcQtOWJG" role="lcghm">
                        <property role="lacIc" value="SO THAT I exercise my right of opposition" />
                      </node>
                      <node concept="l8MVK" id="506pcQtOWJH" role="lcghm" />
                    </node>
                  </node>
                </node>
              </node>
              <node concept="3y3z36" id="506pcQtOXP6" role="3clFbw">
                <node concept="2OqwBi" id="506pcQtOWJM" role="3uHU7B">
                  <node concept="2OqwBi" id="506pcQtOWJN" role="2Oq$k0">
                    <node concept="2OqwBi" id="506pcQtOWJO" role="2Oq$k0">
                      <node concept="3M$PaV" id="506pcQtOWJP" role="2Oq$k0">
                        <ref role="3M$S_o" node="506pcQtOWIW" resolve="e" />
                      </node>
                      <node concept="3TrEf2" id="506pcQtOWJQ" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:424h5AVfh_Z" resolve="processing" />
                      </node>
                    </node>
                    <node concept="3TrcHB" id="506pcQtOWJR" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVgh99" resolve="pc" />
                    </node>
                  </node>
                  <node concept="liA8E" id="506pcQtOWJS" role="2OqNvi">
                    <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
                  </node>
                </node>
                <node concept="Xl_RD" id="506pcQtOWJL" role="3uHU7w">
                  <property role="Xl_RC" value="Consent_Contract" />
                </node>
              </node>
            </node>
            <node concept="3clFbH" id="506pcQtOWJT" role="3cqZAp" />
          </node>
        </node>
        <node concept="3clFbH" id="59Rn7sUykA9" role="3cqZAp" />
        <node concept="3SKdUt" id="59Rn7sUynof" role="3cqZAp">
          <node concept="1PaTwC" id="59Rn7sUynog" role="1aUNEU">
            <node concept="3oM_SD" id="59Rn7sUyooY" role="1PaTwD">
              <property role="3oM_SC" value="Data" />
            </node>
            <node concept="3oM_SD" id="59Rn7sUyop4" role="1PaTwD">
              <property role="3oM_SC" value="subject" />
            </node>
            <node concept="3oM_SD" id="59Rn7sUyopf" role="1PaTwD">
              <property role="3oM_SC" value="notification" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="59Rn7sUyCMj" role="3cqZAp">
          <node concept="l8MVK" id="59Rn7sUyCMk" role="lcghm" />
          <node concept="l8MVK" id="59Rn7sUyCMl" role="lcghm" />
          <node concept="la8eA" id="59Rn7sUyCMm" role="lcghm">
            <property role="lacIc" value="******* NOTIFICATION RIGHT **********" />
          </node>
          <node concept="l8MVK" id="59Rn7sUyCMn" role="lcghm" />
        </node>
        <node concept="3clFbH" id="59Rn7sUyCMo" role="3cqZAp" />
        <node concept="1_o_46" id="59Rn7sUyCMp" role="3cqZAp">
          <node concept="1_o_bx" id="59Rn7sUyCMq" role="1_o_by">
            <node concept="1_o_bG" id="59Rn7sUyCMr" role="1_o_aQ">
              <property role="TrG5h" value="e" />
            </node>
            <node concept="2OqwBi" id="59Rn7sUyCMs" role="1_o_bz">
              <node concept="2OqwBi" id="59Rn7sUyCMt" role="2Oq$k0">
                <node concept="2OqwBi" id="59Rn7sUyCMu" role="2Oq$k0">
                  <node concept="117lpO" id="59Rn7sUyCMv" role="2Oq$k0" />
                  <node concept="3TrEf2" id="59Rn7sUyCMw" role="2OqNvi">
                    <ref role="3Tt5mk" to="20wa:506pcQtxmXV" resolve="listProcessing" />
                  </node>
                </node>
                <node concept="3Tsc0h" id="59Rn7sUyCMx" role="2OqNvi">
                  <ref role="3TtcxE" to="20wa:506pcQtus8w" resolve="processing" />
                </node>
              </node>
              <node concept="1VAtEI" id="59Rn7sUyCMy" role="2OqNvi" />
            </node>
          </node>
          <node concept="3clFbS" id="59Rn7sUyCMz" role="2LFqv$">
            <node concept="lc7rE" id="59Rn7sUyCM$" role="3cqZAp">
              <node concept="l8MVK" id="59Rn7sUyCM_" role="lcghm" />
            </node>
            <node concept="1_o_46" id="59Rn7sUyCMC" role="3cqZAp">
              <node concept="1_o_bx" id="59Rn7sUyCMD" role="1_o_by">
                <node concept="1_o_bG" id="59Rn7sUyCME" role="1_o_aQ">
                  <property role="TrG5h" value="f" />
                </node>
                <node concept="2OqwBi" id="59Rn7sUyCMF" role="1_o_bz">
                  <node concept="2OqwBi" id="59Rn7sUyCMG" role="2Oq$k0">
                    <node concept="2OqwBi" id="59Rn7sUyCMH" role="2Oq$k0">
                      <node concept="2OqwBi" id="59Rn7sUyCMI" role="2Oq$k0">
                        <node concept="2OqwBi" id="59Rn7sUyCMJ" role="2Oq$k0">
                          <node concept="3M$PaV" id="59Rn7sUyCMK" role="2Oq$k0">
                            <ref role="3M$S_o" node="59Rn7sUyCMr" resolve="e" />
                          </node>
                          <node concept="3TrEf2" id="59Rn7sUyCML" role="2OqNvi">
                            <ref role="3Tt5mk" to="20wa:424h5AVfh_Z" resolve="processing" />
                          </node>
                        </node>
                        <node concept="3Tsc0h" id="59Rn7sUyCMM" role="2OqNvi">
                          <ref role="3TtcxE" to="20wa:5VnHNHVgh9G" resolve="dataUsedPd" />
                        </node>
                      </node>
                      <node concept="13MTOL" id="59Rn7sUyCMN" role="2OqNvi">
                        <ref role="13MTZf" to="20wa:2olOl3C1TdP" resolve="dataref1" />
                      </node>
                    </node>
                    <node concept="13MTOL" id="59Rn7sUyCMO" role="2OqNvi">
                      <ref role="13MTZf" to="20wa:2pxN2iW2NcB" resolve="dataSubjectCategory" />
                    </node>
                  </node>
                  <node concept="1VAtEI" id="59Rn7sUyCMP" role="2OqNvi" />
                </node>
              </node>
              <node concept="3clFbS" id="59Rn7sUyCMQ" role="2LFqv$">
                <node concept="lc7rE" id="59Rn7sUyCMR" role="3cqZAp">
                  <node concept="la8eA" id="59Rn7sUyCMS" role="lcghm">
                    <property role="lacIc" value="as a " />
                  </node>
                  <node concept="l9hG8" id="59Rn7sUyCMT" role="lcghm">
                    <node concept="2OqwBi" id="59Rn7sUyCMU" role="lb14g">
                      <node concept="3M$PaV" id="59Rn7sUyCMV" role="2Oq$k0">
                        <ref role="3M$S_o" node="59Rn7sUyCME" resolve="f" />
                      </node>
                      <node concept="3TrcHB" id="59Rn7sUyCMW" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="l8MVK" id="59Rn7sUyCMX" role="lcghm" />
                </node>
                <node concept="lc7rE" id="59Rn7sUyCMY" role="3cqZAp">
                  <node concept="la8eA" id="59Rn7sUyCMZ" role="lcghm">
                    <property role="lacIc" value="     " />
                  </node>
                  <node concept="la8eA" id="59Rn7sUyCN0" role="lcghm">
                    <property role="lacIc" value="I want to be notified when changes are made to &quot;" />
                  </node>
                </node>
                <node concept="lc7rE" id="59Rn7sUyCN1" role="3cqZAp">
                  <node concept="l9hG8" id="59Rn7sUyCN2" role="lcghm">
                    <node concept="2OqwBi" id="59Rn7sUyCN3" role="lb14g">
                      <node concept="2OqwBi" id="59Rn7sUyCN4" role="2Oq$k0">
                        <node concept="3M$PaV" id="59Rn7sUyCN5" role="2Oq$k0">
                          <ref role="3M$S_o" node="59Rn7sUyCMr" resolve="e" />
                        </node>
                        <node concept="3TrEf2" id="59Rn7sUyCN6" role="2OqNvi">
                          <ref role="3Tt5mk" to="20wa:424h5AVfh_Z" resolve="processing" />
                        </node>
                      </node>
                      <node concept="3TrcHB" id="59Rn7sUyCN7" role="2OqNvi">
                        <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                      </node>
                    </node>
                  </node>
                  <node concept="la8eA" id="59Rn7sUyCN8" role="lcghm">
                    <property role="lacIc" value="&quot;" />
                  </node>
                  <node concept="la8eA" id="59Rn7sUzZY7" role="lcghm">
                    <property role="lacIc" value="processing" />
                  </node>
                  <node concept="l8MVK" id="59Rn7sU$0qM" role="lcghm" />
                </node>
              </node>
            </node>
            <node concept="3clFbH" id="59Rn7sUyEc6" role="3cqZAp" />
          </node>
        </node>
        <node concept="3clFbH" id="59Rn7sUyBDW" role="3cqZAp" />
        <node concept="3clFbH" id="59Rn7sUyopx" role="3cqZAp" />
        <node concept="3SKdUt" id="59Rn7sUy3Wb" role="3cqZAp">
          <node concept="1PaTwC" id="59Rn7sUy3Wc" role="1aUNEU">
            <node concept="3oM_SD" id="59Rn7sUy45t" role="1PaTwD">
              <property role="3oM_SC" value="" />
            </node>
            <node concept="3oM_SD" id="59Rn7sUy5m6" role="1PaTwD">
              <property role="3oM_SC" value="Provider" />
            </node>
            <node concept="3oM_SD" id="59Rn7sUy5mk" role="1PaTwD">
              <property role="3oM_SC" value="user" />
            </node>
            <node concept="3oM_SD" id="59Rn7sUy5mL" role="1PaTwD">
              <property role="3oM_SC" value="stories" />
            </node>
            <node concept="3oM_SD" id="59Rn7sUy5mY" role="1PaTwD">
              <property role="3oM_SC" value="" />
            </node>
          </node>
        </node>
        <node concept="lc7rE" id="59Rn7sUyaI1" role="3cqZAp">
          <node concept="l8MVK" id="59Rn7sUyaI2" role="lcghm" />
          <node concept="l8MVK" id="59Rn7sUyaI3" role="lcghm" />
          <node concept="la8eA" id="59Rn7sUyaI4" role="lcghm">
            <property role="lacIc" value="******* Provider user stories **********" />
          </node>
          <node concept="l8MVK" id="59Rn7sUyaI5" role="lcghm" />
        </node>
        <node concept="3clFbH" id="59Rn7sUy9kW" role="3cqZAp" />
        <node concept="lc7rE" id="59Rn7sUy6Kf" role="3cqZAp">
          <node concept="la8eA" id="59Rn7sUy6Kg" role="lcghm">
            <property role="lacIc" value="as a Provider " />
          </node>
          <node concept="l8MVK" id="59Rn7sUy6Kl" role="lcghm" />
        </node>
        <node concept="lc7rE" id="59Rn7sUy6Km" role="3cqZAp">
          <node concept="la8eA" id="59Rn7sUy9aU" role="lcghm">
            <property role="lacIc" value="I want to be able to edit any information about a data item, such as the category, the category of the person involved. " />
          </node>
        </node>
        <node concept="lc7rE" id="59Rn7sUydjE" role="3cqZAp">
          <node concept="l8MVK" id="59Rn7sUyffM" role="lcghm" />
        </node>
        <node concept="lc7rE" id="59Rn7sUygM5" role="3cqZAp">
          <node concept="l8MVK" id="59Rn7sUygM6" role="lcghm" />
        </node>
        <node concept="3clFbH" id="59Rn7sUyfCY" role="3cqZAp" />
        <node concept="lc7rE" id="59Rn7sUybTJ" role="3cqZAp">
          <node concept="la8eA" id="59Rn7sUybTK" role="lcghm">
            <property role="lacIc" value="as a Provider " />
          </node>
          <node concept="l8MVK" id="59Rn7sUybTL" role="lcghm" />
        </node>
        <node concept="lc7rE" id="59Rn7sUybTM" role="3cqZAp">
          <node concept="la8eA" id="59Rn7sUybTN" role="lcghm">
            <property role="lacIc" value="I want to be able to edit any information about a processing, such as category, type, purposes and data used " />
          </node>
        </node>
        <node concept="3clFbH" id="59Rn7sUybKe" role="3cqZAp" />
        <node concept="lc7rE" id="59Rn7sUyjb1" role="3cqZAp">
          <node concept="l8MVK" id="59Rn7sUyjb2" role="lcghm" />
        </node>
        <node concept="lc7rE" id="59Rn7sUyjb3" role="3cqZAp">
          <node concept="l8MVK" id="59Rn7sUyjb4" role="lcghm" />
        </node>
        <node concept="3clFbH" id="59Rn7sUyjb5" role="3cqZAp" />
        <node concept="lc7rE" id="59Rn7sUyjb6" role="3cqZAp">
          <node concept="la8eA" id="59Rn7sUyjb7" role="lcghm">
            <property role="lacIc" value="as a Provider " />
          </node>
          <node concept="l8MVK" id="59Rn7sUyjb8" role="lcghm" />
        </node>
        <node concept="lc7rE" id="59Rn7sUyjb9" role="3cqZAp">
          <node concept="la8eA" id="59Rn7sUyjba" role="lcghm">
            <property role="lacIc" value="I want to be able to respond to requests from data subjects." />
          </node>
        </node>
        <node concept="3clFbH" id="59Rn7sUyhMB" role="3cqZAp" />
        <node concept="lc7rE" id="59Rn7sU$SCu" role="3cqZAp">
          <node concept="l8MVK" id="59Rn7sU$SCv" role="lcghm" />
        </node>
        <node concept="lc7rE" id="59Rn7sU$SCw" role="3cqZAp">
          <node concept="l8MVK" id="59Rn7sU$SCx" role="lcghm" />
        </node>
        <node concept="3clFbH" id="59Rn7sU$SCy" role="3cqZAp" />
        <node concept="lc7rE" id="59Rn7sU$SCz" role="3cqZAp">
          <node concept="la8eA" id="59Rn7sU$SC$" role="lcghm">
            <property role="lacIc" value="as a Provider " />
          </node>
          <node concept="l8MVK" id="59Rn7sU$SC_" role="lcghm" />
        </node>
        <node concept="lc7rE" id="59Rn7sU$SCA" role="3cqZAp">
          <node concept="la8eA" id="59Rn7sU$SCB" role="lcghm">
            <property role="lacIc" value="I want to be able to generate the register." />
          </node>
        </node>
        <node concept="3clFbH" id="59Rn7sU$R8L" role="3cqZAp" />
      </node>
    </node>
    <node concept="29tfMY" id="2pxN2iW3s6c" role="29tGrW">
      <node concept="3clFbS" id="2pxN2iW3s6d" role="2VODD2">
        <node concept="3clFbF" id="2pxN2iW3srO" role="3cqZAp">
          <node concept="Xl_RD" id="2pxN2iW3srN" role="3clFbG">
            <property role="Xl_RC" value="User stories" />
          </node>
        </node>
      </node>
    </node>
    <node concept="9MYSb" id="2pxN2iW3sxx" role="33IsuW">
      <node concept="3clFbS" id="2pxN2iW3sxy" role="2VODD2">
        <node concept="3clFbF" id="2pxN2iW3sN2" role="3cqZAp">
          <node concept="Xl_RD" id="2pxN2iW3sN1" role="3clFbG">
            <property role="Xl_RC" value="txt" />
          </node>
        </node>
      </node>
    </node>
  </node>
</model>

