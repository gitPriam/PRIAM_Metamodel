<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:e7beee50-bad0-4e7e-a2a7-f43f7868ae0a(PRIAM_LANGUAGE.behavior)">
  <persistence version="9" />
  <languages>
    <use id="7866978e-a0f0-4cc7-81bc-4d213d9375e1" name="jetbrains.mps.lang.smodel" version="19" />
    <use id="af65afd8-f0dd-4942-87d9-63a55f2a9db1" name="jetbrains.mps.lang.behavior" version="2" />
    <use id="e02dfeab-630f-4f6d-86a8-a0833a3f70fc" name="PRIAM_LANGUAGE" version="0" />
    <devkit ref="fbc25dd2-5da4-483a-8b19-70928e1b62d7(jetbrains.mps.devkit.general-purpose)" />
  </languages>
  <imports>
    <import index="20wa" ref="r:515d5f51-79c9-42c9-bba4-54c97b772d5b(PRIAM_LANGUAGE.structure)" />
    <import index="tpck" ref="r:00000000-0000-4000-0000-011c89590288(jetbrains.mps.lang.core.structure)" />
    <import index="wyt6" ref="6354ebe7-c22a-4a0f-ac54-50b52ab9b065/java:java.lang(JDK/)" implicit="true" />
  </imports>
  <registry>
    <language id="af65afd8-f0dd-4942-87d9-63a55f2a9db1" name="jetbrains.mps.lang.behavior">
      <concept id="6496299201655527393" name="jetbrains.mps.lang.behavior.structure.LocalBehaviorMethodCall" flags="nn" index="BsUDl" />
      <concept id="1225194240794" name="jetbrains.mps.lang.behavior.structure.ConceptBehavior" flags="ng" index="13h7C7">
        <reference id="1225194240799" name="concept" index="13h7C2" />
        <child id="1225194240805" name="method" index="13h7CS" />
        <child id="1225194240801" name="constructor" index="13h7CW" />
      </concept>
      <concept id="1225194413805" name="jetbrains.mps.lang.behavior.structure.ConceptConstructorDeclaration" flags="in" index="13hLZK" />
      <concept id="1225194472830" name="jetbrains.mps.lang.behavior.structure.ConceptMethodDeclaration" flags="ng" index="13i0hz" />
      <concept id="1225194691553" name="jetbrains.mps.lang.behavior.structure.ThisNodeExpression" flags="nn" index="13iPFW" />
    </language>
    <language id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage">
      <concept id="1215693861676" name="jetbrains.mps.baseLanguage.structure.BaseAssignmentExpression" flags="nn" index="d038R">
        <child id="1068498886297" name="rValue" index="37vLTx" />
        <child id="1068498886295" name="lValue" index="37vLTJ" />
      </concept>
      <concept id="1202948039474" name="jetbrains.mps.baseLanguage.structure.InstanceMethodCallOperation" flags="nn" index="liA8E" />
      <concept id="1154032098014" name="jetbrains.mps.baseLanguage.structure.AbstractLoopStatement" flags="nn" index="2LF5Ji">
        <child id="1154032183016" name="body" index="2LFqv$" />
      </concept>
      <concept id="1197027756228" name="jetbrains.mps.baseLanguage.structure.DotExpression" flags="nn" index="2OqwBi">
        <child id="1197027771414" name="operand" index="2Oq$k0" />
        <child id="1197027833540" name="operation" index="2OqNvi" />
      </concept>
      <concept id="1145552977093" name="jetbrains.mps.baseLanguage.structure.GenericNewExpression" flags="nn" index="2ShNRf">
        <child id="1145553007750" name="creator" index="2ShVmc" />
      </concept>
      <concept id="1137021947720" name="jetbrains.mps.baseLanguage.structure.ConceptFunction" flags="in" index="2VMwT0">
        <child id="1137022507850" name="body" index="2VODD2" />
      </concept>
      <concept id="1070475926800" name="jetbrains.mps.baseLanguage.structure.StringLiteral" flags="nn" index="Xl_RD">
        <property id="1070475926801" name="value" index="Xl_RC" />
      </concept>
      <concept id="1070534370425" name="jetbrains.mps.baseLanguage.structure.IntegerType" flags="in" index="10Oyi0" />
      <concept id="1070534644030" name="jetbrains.mps.baseLanguage.structure.BooleanType" flags="in" index="10P_77" />
      <concept id="1068431474542" name="jetbrains.mps.baseLanguage.structure.VariableDeclaration" flags="ng" index="33uBYm">
        <child id="1068431790190" name="initializer" index="33vP2m" />
      </concept>
      <concept id="1068498886296" name="jetbrains.mps.baseLanguage.structure.VariableReference" flags="nn" index="37vLTw">
        <reference id="1068581517664" name="variableDeclaration" index="3cqZAo" />
      </concept>
      <concept id="1068498886292" name="jetbrains.mps.baseLanguage.structure.ParameterDeclaration" flags="ir" index="37vLTG" />
      <concept id="1068498886294" name="jetbrains.mps.baseLanguage.structure.AssignmentExpression" flags="nn" index="37vLTI" />
      <concept id="1225271177708" name="jetbrains.mps.baseLanguage.structure.StringType" flags="in" index="17QB3L" />
      <concept id="4972933694980447171" name="jetbrains.mps.baseLanguage.structure.BaseVariableDeclaration" flags="ng" index="19Szcq">
        <child id="5680397130376446158" name="type" index="1tU5fm" />
      </concept>
      <concept id="1068580123132" name="jetbrains.mps.baseLanguage.structure.BaseMethodDeclaration" flags="ng" index="3clF44">
        <child id="1068580123133" name="returnType" index="3clF45" />
        <child id="1068580123134" name="parameter" index="3clF46" />
        <child id="1068580123135" name="body" index="3clF47" />
      </concept>
      <concept id="1068580123155" name="jetbrains.mps.baseLanguage.structure.ExpressionStatement" flags="nn" index="3clFbF">
        <child id="1068580123156" name="expression" index="3clFbG" />
      </concept>
      <concept id="1068580123159" name="jetbrains.mps.baseLanguage.structure.IfStatement" flags="nn" index="3clFbJ">
        <child id="1068580123160" name="condition" index="3clFbw" />
        <child id="1068580123161" name="ifTrue" index="3clFbx" />
      </concept>
      <concept id="1068580123136" name="jetbrains.mps.baseLanguage.structure.StatementList" flags="sn" stub="5293379017992965193" index="3clFbS">
        <child id="1068581517665" name="statement" index="3cqZAp" />
      </concept>
      <concept id="1068580123137" name="jetbrains.mps.baseLanguage.structure.BooleanConstant" flags="nn" index="3clFbT">
        <property id="1068580123138" name="value" index="3clFbU" />
      </concept>
      <concept id="1068581242878" name="jetbrains.mps.baseLanguage.structure.ReturnStatement" flags="nn" index="3cpWs6">
        <child id="1068581517676" name="expression" index="3cqZAk" />
      </concept>
      <concept id="1068581242864" name="jetbrains.mps.baseLanguage.structure.LocalVariableDeclarationStatement" flags="nn" index="3cpWs8">
        <child id="1068581242865" name="localVariableDeclaration" index="3cpWs9" />
      </concept>
      <concept id="1068581242863" name="jetbrains.mps.baseLanguage.structure.LocalVariableDeclaration" flags="nr" index="3cpWsn" />
      <concept id="1068581517677" name="jetbrains.mps.baseLanguage.structure.VoidType" flags="in" index="3cqZAl" />
      <concept id="1204053956946" name="jetbrains.mps.baseLanguage.structure.IMethodCall" flags="ng" index="1ndlxa">
        <reference id="1068499141037" name="baseMethodDeclaration" index="37wK5l" />
        <child id="1068499141038" name="actualArgument" index="37wK5m" />
      </concept>
      <concept id="1107535904670" name="jetbrains.mps.baseLanguage.structure.ClassifierType" flags="in" index="3uibUv">
        <reference id="1107535924139" name="classifier" index="3uigEE" />
      </concept>
      <concept id="1081773326031" name="jetbrains.mps.baseLanguage.structure.BinaryOperation" flags="nn" index="3uHJSO">
        <child id="1081773367579" name="rightExpression" index="3uHU7w" />
        <child id="1081773367580" name="leftExpression" index="3uHU7B" />
      </concept>
      <concept id="1073239437375" name="jetbrains.mps.baseLanguage.structure.NotEqualsExpression" flags="nn" index="3y3z36" />
      <concept id="1178549954367" name="jetbrains.mps.baseLanguage.structure.IVisible" flags="ng" index="1B3ioH">
        <child id="1178549979242" name="visibility" index="1B3o_S" />
      </concept>
      <concept id="1146644602865" name="jetbrains.mps.baseLanguage.structure.PublicVisibility" flags="nn" index="3Tm1VV" />
    </language>
    <language id="7866978e-a0f0-4cc7-81bc-4d213d9375e1" name="jetbrains.mps.lang.smodel">
      <concept id="1179409122411" name="jetbrains.mps.lang.smodel.structure.Node_ConceptMethodCall" flags="nn" index="2qgKlT" />
      <concept id="1138056022639" name="jetbrains.mps.lang.smodel.structure.SPropertyAccess" flags="nn" index="3TrcHB">
        <reference id="1138056395725" name="property" index="3TsBF5" />
      </concept>
      <concept id="1138056143562" name="jetbrains.mps.lang.smodel.structure.SLinkAccess" flags="nn" index="3TrEf2">
        <reference id="1138056516764" name="link" index="3Tt5mk" />
      </concept>
      <concept id="1138056282393" name="jetbrains.mps.lang.smodel.structure.SLinkListAccess" flags="nn" index="3Tsc0h">
        <reference id="1138056546658" name="link" index="3TtcxE" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1133920641626" name="jetbrains.mps.lang.core.structure.BaseConcept" flags="ng" index="2VYdi">
        <child id="5169995583184591170" name="smodelAttribute" index="lGtFl" />
      </concept>
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ng" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
      <concept id="709746936026466394" name="jetbrains.mps.lang.core.structure.ChildAttribute" flags="ng" index="3VBwX9">
        <property id="709746936026609031" name="linkId" index="3V$3ak" />
        <property id="709746936026609029" name="role_DebugInfo" index="3V$3am" />
      </concept>
      <concept id="4452961908202556907" name="jetbrains.mps.lang.core.structure.BaseCommentAttribute" flags="ng" index="1X3_iC">
        <child id="3078666699043039389" name="commentedNode" index="8Wnug" />
      </concept>
    </language>
    <language id="83888646-71ce-4f1c-9c53-c54016f6ad4f" name="jetbrains.mps.baseLanguage.collections">
      <concept id="540871147943773365" name="jetbrains.mps.baseLanguage.collections.structure.SingleArgumentSequenceOperation" flags="nn" index="25WWJ4">
        <child id="540871147943773366" name="argument" index="25WWJ7" />
      </concept>
      <concept id="1151688443754" name="jetbrains.mps.baseLanguage.collections.structure.ListType" flags="in" index="_YKpA">
        <child id="1151688676805" name="elementType" index="_ZDj9" />
      </concept>
      <concept id="3358009230509553641" name="jetbrains.mps.baseLanguage.collections.structure.LinkedListType" flags="in" index="2BANLN" />
      <concept id="1153943597977" name="jetbrains.mps.baseLanguage.collections.structure.ForEachStatement" flags="nn" index="2Gpval">
        <child id="1153944400369" name="variable" index="2Gsz3X" />
        <child id="1153944424730" name="inputSequence" index="2GsD0m" />
      </concept>
      <concept id="1153944193378" name="jetbrains.mps.baseLanguage.collections.structure.ForEachVariable" flags="nr" index="2GrKxI" />
      <concept id="1153944233411" name="jetbrains.mps.baseLanguage.collections.structure.ForEachVariableReference" flags="nn" index="2GrUjf">
        <reference id="1153944258490" name="variable" index="2Gs0qQ" />
      </concept>
      <concept id="1237721394592" name="jetbrains.mps.baseLanguage.collections.structure.AbstractContainerCreator" flags="nn" index="HWqM0">
        <child id="1237721435807" name="elementType" index="HW$YZ" />
      </concept>
      <concept id="1227008614712" name="jetbrains.mps.baseLanguage.collections.structure.LinkedListCreator" flags="nn" index="2Jqq0_" />
      <concept id="1160612413312" name="jetbrains.mps.baseLanguage.collections.structure.AddElementOperation" flags="nn" index="TSZUe" />
      <concept id="1172254888721" name="jetbrains.mps.baseLanguage.collections.structure.ContainsOperation" flags="nn" index="3JPx81" />
    </language>
  </registry>
  <node concept="13h7C7" id="424h5AViqLw">
    <ref role="13h7C2" to="20wa:5VnHNHVgjqK" resolve="DataRefPD" />
    <node concept="13i0hz" id="424h5AViAu1" role="13h7CS">
      <property role="TrG5h" value="getStatusData" />
      <node concept="3Tm1VV" id="424h5AViAu2" role="1B3o_S" />
      <node concept="10P_77" id="424h5AViAuh" role="3clF45" />
      <node concept="3clFbS" id="424h5AViAu4" role="3clF47">
        <node concept="3cpWs6" id="424h5AViMRs" role="3cqZAp">
          <node concept="2OqwBi" id="424h5AViNi1" role="3cqZAk">
            <node concept="2OqwBi" id="424h5AViN0Z" role="2Oq$k0">
              <node concept="13iPFW" id="424h5AViMRT" role="2Oq$k0" />
              <node concept="3TrEf2" id="424h5AViN89" role="2OqNvi">
                <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
              </node>
            </node>
            <node concept="3TrcHB" id="424h5AViNrw" role="2OqNvi">
              <ref role="3TsBF5" to="20wa:5VnHNHVghv9" resolve="hasPersonalUsage" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="13hLZK" id="424h5AViqLx" role="13h7CW">
      <node concept="3clFbS" id="424h5AViqLy" role="2VODD2" />
    </node>
  </node>
  <node concept="13h7C7" id="424h5AViFvj">
    <ref role="13h7C2" to="20wa:5VnHNHVgh92" resolve="Processing" />
    <node concept="13i0hz" id="424h5AVj0aQ" role="13h7CS">
      <property role="TrG5h" value="getStatusDataOfProcessing" />
      <node concept="3Tm1VV" id="424h5AVj0aR" role="1B3o_S" />
      <node concept="10P_77" id="424h5AVj0uV" role="3clF45" />
      <node concept="3clFbS" id="424h5AVj0aT" role="3clF47">
        <node concept="3clFbJ" id="424h5AVj0vQ" role="3cqZAp">
          <node concept="2OqwBi" id="424h5AVj2lw" role="3clFbw">
            <node concept="2OqwBi" id="424h5AVj0DV" role="2Oq$k0">
              <node concept="13iPFW" id="424h5AVj0wa" role="2Oq$k0" />
              <node concept="2qgKlT" id="424h5AVj0Md" role="2OqNvi">
                <ref role="37wK5l" node="424h5AViKll" resolve="ListOfStatusData" />
              </node>
            </node>
            <node concept="3JPx81" id="424h5AVj3wk" role="2OqNvi">
              <node concept="3clFbT" id="424h5AVj3z0" role="25WWJ7">
                <property role="3clFbU" value="true" />
              </node>
            </node>
          </node>
          <node concept="3clFbS" id="424h5AVj0vS" role="3clFbx">
            <node concept="3cpWs6" id="424h5AVj3Dp" role="3cqZAp">
              <node concept="3clFbT" id="424h5AVj3IS" role="3cqZAk">
                <property role="3clFbU" value="true" />
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="424h5AVj3OE" role="3cqZAp">
          <node concept="3clFbT" id="424h5AVj3OU" role="3cqZAk" />
        </node>
      </node>
    </node>
    <node concept="13i0hz" id="424h5AViKll" role="13h7CS">
      <property role="TrG5h" value="ListOfStatusData" />
      <node concept="3Tm1VV" id="424h5AViKlm" role="1B3o_S" />
      <node concept="3clFbS" id="424h5AViKlo" role="3clF47">
        <node concept="3cpWs8" id="424h5AViKIu" role="3cqZAp">
          <node concept="3cpWsn" id="424h5AViKIx" role="3cpWs9">
            <property role="TrG5h" value="l" />
            <node concept="2ShNRf" id="424h5AViU2c" role="33vP2m">
              <node concept="2Jqq0_" id="424h5AViU2a" role="2ShVmc">
                <node concept="10P_77" id="424h5AViU2b" role="HW$YZ" />
              </node>
            </node>
            <node concept="2BANLN" id="424h5AViT_u" role="1tU5fm">
              <node concept="10P_77" id="424h5AViTUA" role="_ZDj9" />
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="424h5AViKnl" role="3cqZAp">
          <node concept="2GrKxI" id="424h5AViKnm" role="2Gsz3X">
            <property role="TrG5h" value="s" />
          </node>
          <node concept="2OqwBi" id="424h5AViKxT" role="2GsD0m">
            <node concept="13iPFW" id="424h5AViKnT" role="2Oq$k0" />
            <node concept="3Tsc0h" id="424h5AViQQ$" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:5VnHNHVgh9G" resolve="dataUsedPd" />
            </node>
          </node>
          <node concept="3clFbS" id="424h5AViKno" role="2LFqv$">
            <node concept="3clFbF" id="424h5AViKOg" role="3cqZAp">
              <node concept="2OqwBi" id="424h5AViLCg" role="3clFbG">
                <node concept="37vLTw" id="424h5AViKOf" role="2Oq$k0">
                  <ref role="3cqZAo" node="424h5AViKIx" resolve="l" />
                </node>
                <node concept="TSZUe" id="424h5AViMhP" role="2OqNvi">
                  <node concept="2OqwBi" id="424h5AViRLL" role="25WWJ7">
                    <node concept="2OqwBi" id="424h5AViR4r" role="2Oq$k0">
                      <node concept="2GrUjf" id="424h5AViMos" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="424h5AViKnm" resolve="s" />
                      </node>
                      <node concept="3TrEf2" id="424h5AViRsN" role="2OqNvi">
                        <ref role="3Tt5mk" to="20wa:5VnHNHVgjqN" resolve="dataUsage" />
                      </node>
                    </node>
                    <node concept="2qgKlT" id="424h5AViS33" role="2OqNvi">
                      <ref role="37wK5l" node="424h5AVhXxp" resolve="getStatus" />
                    </node>
                  </node>
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="424h5AViSuH" role="3cqZAp">
          <node concept="37vLTw" id="424h5AViS$E" role="3cqZAk">
            <ref role="3cqZAo" node="424h5AViKIx" resolve="l" />
          </node>
        </node>
      </node>
      <node concept="2BANLN" id="424h5AViT7p" role="3clF45">
        <node concept="10P_77" id="424h5AViTi0" role="_ZDj9" />
      </node>
    </node>
    <node concept="13i0hz" id="4Xqrfpm5qCx" role="13h7CS">
      <property role="TrG5h" value="getAllDescriptionPurpose" />
      <node concept="3Tm1VV" id="4Xqrfpm5qCy" role="1B3o_S" />
      <node concept="2BANLN" id="4Xqrfpm5qJQ" role="3clF45">
        <node concept="17QB3L" id="4XqrfpmaxYh" role="_ZDj9" />
      </node>
      <node concept="3clFbS" id="4Xqrfpm5qC$" role="3clF47">
        <node concept="3cpWs8" id="4Xqrfpm5qLf" role="3cqZAp">
          <node concept="3cpWsn" id="4Xqrfpm5qLi" role="3cpWs9">
            <property role="TrG5h" value="l" />
            <node concept="2BANLN" id="4Xqrfpm5qLd" role="1tU5fm">
              <node concept="17QB3L" id="4Xqrfpmayg9" role="_ZDj9" />
            </node>
            <node concept="2ShNRf" id="4Xqrfpm5qMq" role="33vP2m">
              <node concept="2Jqq0_" id="4Xqrfpm5s7g" role="2ShVmc">
                <node concept="17QB3L" id="4XqrfpmayNo" role="HW$YZ" />
              </node>
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="4Xqrfpm5slG" role="3cqZAp">
          <node concept="2GrKxI" id="4Xqrfpm5slI" role="2Gsz3X">
            <property role="TrG5h" value="d" />
          </node>
          <node concept="2OqwBi" id="4Xqrfpm5swr" role="2GsD0m">
            <node concept="13iPFW" id="4Xqrfpm5smr" role="2Oq$k0" />
            <node concept="3Tsc0h" id="4Xqrfpm5sD0" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:5VnHNHVgiAP" resolve="purposes" />
            </node>
          </node>
          <node concept="3clFbS" id="4Xqrfpm5slM" role="2LFqv$">
            <node concept="3clFbF" id="4Xqrfpm5sFG" role="3cqZAp">
              <node concept="2OqwBi" id="4Xqrfpm5u4E" role="3clFbG">
                <node concept="37vLTw" id="4Xqrfpm5sZe" role="2Oq$k0">
                  <ref role="3cqZAo" node="4Xqrfpm5qLi" resolve="l" />
                </node>
                <node concept="TSZUe" id="4Xqrfpm5vgc" role="2OqNvi">
                  <node concept="2OqwBi" id="4Xqrfpm5vyT" role="25WWJ7">
                    <node concept="2GrUjf" id="4Xqrfpm5vnR" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="4Xqrfpm5slI" resolve="d" />
                    </node>
                    <node concept="3TrcHB" id="4Xqrfpm5vLI" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVghPM" resolve="description" />
                    </node>
                  </node>
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="4Xqrfpm5wFy" role="3cqZAp">
          <node concept="37vLTw" id="4Xqrfpm5wQC" role="3cqZAk">
            <ref role="3cqZAo" node="4Xqrfpm5qLi" resolve="l" />
          </node>
        </node>
      </node>
    </node>
    <node concept="13i0hz" id="4Xqrfpm6wZE" role="13h7CS">
      <property role="TrG5h" value="getAllTypePurpose" />
      <node concept="3Tm1VV" id="4Xqrfpm6wZF" role="1B3o_S" />
      <node concept="2BANLN" id="4Xqrfpm6xmn" role="3clF45">
        <node concept="3uibUv" id="4XqrfpmdhMA" role="_ZDj9">
          <ref role="3uigEE" to="wyt6:~String" resolve="String" />
        </node>
      </node>
      <node concept="3clFbS" id="4Xqrfpm6wZH" role="3clF47">
        <node concept="3cpWs8" id="4Xqrfpm6xno" role="3cqZAp">
          <node concept="3cpWsn" id="4Xqrfpm6xnr" role="3cpWs9">
            <property role="TrG5h" value="l" />
            <node concept="2BANLN" id="4Xqrfpm6xnm" role="1tU5fm">
              <node concept="3uibUv" id="4Xqrfpmdi7J" role="_ZDj9">
                <ref role="3uigEE" to="wyt6:~String" resolve="String" />
              </node>
            </node>
            <node concept="2ShNRf" id="4Xqrfpm6xoE" role="33vP2m">
              <node concept="2Jqq0_" id="4Xqrfpm6xDk" role="2ShVmc">
                <node concept="3uibUv" id="4Xqrfpmdic6" role="HW$YZ">
                  <ref role="3uigEE" to="wyt6:~String" resolve="String" />
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="4Xqrfpm6y4O" role="3cqZAp">
          <node concept="2GrKxI" id="4Xqrfpm6y4Q" role="2Gsz3X">
            <property role="TrG5h" value="t" />
          </node>
          <node concept="2OqwBi" id="4Xqrfpm6yfz" role="2GsD0m">
            <node concept="13iPFW" id="4Xqrfpm6y5z" role="2Oq$k0" />
            <node concept="3Tsc0h" id="4Xqrfpm6yo8" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:5VnHNHVgiAP" resolve="purposes" />
            </node>
          </node>
          <node concept="3clFbS" id="4Xqrfpm6y4U" role="2LFqv$">
            <node concept="3clFbF" id="4Xqrfpm6yqO" role="3cqZAp">
              <node concept="2OqwBi" id="4Xqrfpm6zwg" role="3clFbG">
                <node concept="37vLTw" id="4Xqrfpm6yqN" role="2Oq$k0">
                  <ref role="3cqZAo" node="4Xqrfpm6xnr" resolve="l" />
                </node>
                <node concept="TSZUe" id="4Xqrfpm6$_D" role="2OqNvi">
                  <node concept="2OqwBi" id="33K18miOV3u" role="25WWJ7">
                    <node concept="2OqwBi" id="33K18miOUv1" role="2Oq$k0">
                      <node concept="2GrUjf" id="33K18miOUjF" role="2Oq$k0">
                        <ref role="2Gs0qQ" node="4Xqrfpm6y4Q" resolve="t" />
                      </node>
                      <node concept="3TrcHB" id="33K18miOULE" role="2OqNvi">
                        <ref role="3TsBF5" to="20wa:5VnHNHVghPO" resolve="type" />
                      </node>
                    </node>
                    <node concept="liA8E" id="33K18miOVkV" role="2OqNvi">
                      <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
                    </node>
                  </node>
                </node>
              </node>
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="4Xqrfpm6_jl" role="3cqZAp">
          <node concept="37vLTw" id="4Xqrfpm6_q4" role="3cqZAk">
            <ref role="3cqZAo" node="4Xqrfpm6xnr" resolve="l" />
          </node>
        </node>
      </node>
    </node>
    <node concept="13hLZK" id="424h5AViFvk" role="13h7CW">
      <node concept="3clFbS" id="424h5AViFvl" role="2VODD2" />
    </node>
  </node>
  <node concept="13h7C7" id="7bfLM_U8MeU">
    <ref role="13h7C2" to="20wa:5VnHNHVghPL" resolve="Purpose" />
    <node concept="13hLZK" id="7bfLM_U8MeV" role="13h7CW">
      <node concept="3clFbS" id="7bfLM_U8MeW" role="2VODD2" />
    </node>
  </node>
  <node concept="13h7C7" id="424h5AVhXxe">
    <ref role="13h7C2" to="20wa:5VnHNHVgh9R" resolve="DataUsage" />
    <node concept="13i0hz" id="424h5AVhXxp" role="13h7CS">
      <property role="TrG5h" value="getStatus" />
      <node concept="3Tm1VV" id="424h5AVhXxq" role="1B3o_S" />
      <node concept="10P_77" id="424h5AVhXxD" role="3clF45" />
      <node concept="3clFbS" id="424h5AVhXxs" role="3clF47">
        <node concept="3clFbF" id="424h5AVhXy5" role="3cqZAp">
          <node concept="2OqwBi" id="424h5AVhXF9" role="3clFbG">
            <node concept="13iPFW" id="424h5AVhXy4" role="2Oq$k0" />
            <node concept="3TrcHB" id="424h5AVhXMh" role="2OqNvi">
              <ref role="3TsBF5" to="20wa:5VnHNHVghv9" resolve="hasPersonalUsage" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="13hLZK" id="424h5AVhXxf" role="13h7CW">
      <node concept="3clFbS" id="424h5AVhXxg" role="2VODD2" />
    </node>
  </node>
  <node concept="13h7C7" id="2pxN2iW09VB">
    <ref role="13h7C2" to="20wa:1j2riNJlag" resolve="DataType" />
    <node concept="13i0hz" id="5Erw5yfdx17" role="13h7CS">
      <property role="TrG5h" value="ReturnPersonalData" />
      <node concept="3Tm1VV" id="5Erw5yfdx18" role="1B3o_S" />
      <node concept="_YKpA" id="5Erw5yfdx1n" role="3clF45">
        <node concept="17QB3L" id="5Erw5yfdx1z" role="_ZDj9" />
      </node>
      <node concept="3clFbS" id="5Erw5yfdx1a" role="3clF47">
        <node concept="3cpWs8" id="5Erw5yfdx3C" role="3cqZAp">
          <node concept="3cpWsn" id="5Erw5yfdx3F" role="3cpWs9">
            <property role="TrG5h" value="L" />
            <node concept="_YKpA" id="5Erw5yfdx3A" role="1tU5fm">
              <node concept="17QB3L" id="5Erw5yfdx3Y" role="_ZDj9" />
            </node>
            <node concept="2ShNRf" id="5Erw5yfdydV" role="33vP2m">
              <node concept="2Jqq0_" id="5Erw5yfdzhT" role="2ShVmc">
                <node concept="17QB3L" id="5Erw5yfdzvw" role="HW$YZ" />
              </node>
            </node>
          </node>
        </node>
        <node concept="2Gpval" id="5Erw5yfdz$o" role="3cqZAp">
          <node concept="2GrKxI" id="5Erw5yfdz$q" role="2Gsz3X">
            <property role="TrG5h" value="e" />
          </node>
          <node concept="3clFbS" id="5Erw5yfdz$u" role="2LFqv$">
            <node concept="3clFbJ" id="40NILoP4oyX" role="3cqZAp">
              <node concept="3clFbS" id="40NILoP4oyZ" role="3clFbx">
                <node concept="1X3_iC" id="1PjvIwH_xut" role="lGtFl">
                  <property role="3V$3am" value="statement" />
                  <property role="3V$3ak" value="f3061a53-9226-4cc5-a443-f952ceaf5816/1068580123136/1068581517665" />
                  <node concept="3clFbF" id="1PjvIwH_ith" role="8Wnug">
                    <node concept="2OqwBi" id="1PjvIwH_odP" role="3clFbG">
                      <node concept="37vLTw" id="1PjvIwH_itf" role="2Oq$k0">
                        <ref role="3cqZAo" node="5Erw5yfdx3F" resolve="L" />
                      </node>
                      <node concept="TSZUe" id="1PjvIwH_oYI" role="2OqNvi">
                        <node concept="2OqwBi" id="1PjvIwH_rgi" role="25WWJ7">
                          <node concept="2GrUjf" id="1PjvIwH_r3j" role="2Oq$k0">
                            <ref role="2Gs0qQ" node="5Erw5yfdz$q" resolve="e" />
                          </node>
                          <node concept="3TrcHB" id="1PjvIwH_rAi" role="2OqNvi">
                            <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
                          </node>
                        </node>
                      </node>
                    </node>
                  </node>
                </node>
                <node concept="3clFbF" id="40NILoP4r0h" role="3cqZAp">
                  <node concept="2OqwBi" id="40NILoP4rMm" role="3clFbG">
                    <node concept="37vLTw" id="40NILoP4r0f" role="2Oq$k0">
                      <ref role="3cqZAo" node="5Erw5yfdx3F" resolve="L" />
                    </node>
                    <node concept="TSZUe" id="40NILoP4suS" role="2OqNvi">
                      <node concept="2OqwBi" id="40NILoP4tgR" role="25WWJ7">
                        <node concept="2GrUjf" id="40NILoP4t0w" role="2Oq$k0">
                          <ref role="2Gs0qQ" node="5Erw5yfdz$q" resolve="e" />
                        </node>
                        <node concept="3TrcHB" id="40NILoP4tCq" role="2OqNvi">
                          <ref role="3TsBF5" to="tpck:h0TrG11" resolve="name" />
                        </node>
                      </node>
                    </node>
                  </node>
                </node>
              </node>
              <node concept="3y3z36" id="40NILoP4pCD" role="3clFbw">
                <node concept="Xl_RD" id="40NILoP4pEZ" role="3uHU7w">
                  <property role="Xl_RC" value="Produced" />
                </node>
                <node concept="2OqwBi" id="40NILoP4tVq" role="3uHU7B">
                  <node concept="2OqwBi" id="40NILoP4oMR" role="2Oq$k0">
                    <node concept="2GrUjf" id="40NILoP4o_4" role="2Oq$k0">
                      <ref role="2Gs0qQ" node="5Erw5yfdz$q" resolve="e" />
                    </node>
                    <node concept="3TrcHB" id="40NILoP4p94" role="2OqNvi">
                      <ref role="3TsBF5" to="20wa:5VnHNHVgh9K" resolve="source" />
                    </node>
                  </node>
                  <node concept="liA8E" id="40NILoP4uly" role="2OqNvi">
                    <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
                  </node>
                </node>
              </node>
            </node>
          </node>
          <node concept="2OqwBi" id="5Erw5yfdzPZ" role="2GsD0m">
            <node concept="13iPFW" id="5Erw5yfdzGL" role="2Oq$k0" />
            <node concept="3Tsc0h" id="5Erw5yfdzX9" role="2OqNvi">
              <ref role="3TtcxE" to="20wa:2pxN2iVZd46" resolve="personalData" />
            </node>
          </node>
        </node>
        <node concept="3cpWs6" id="5Erw5yfdAbz" role="3cqZAp">
          <node concept="37vLTw" id="5Erw5yfdAdK" role="3cqZAk">
            <ref role="3cqZAo" node="5Erw5yfdx3F" resolve="L" />
          </node>
        </node>
      </node>
    </node>
    <node concept="13hLZK" id="2pxN2iW09VC" role="13h7CW">
      <node concept="3clFbS" id="2pxN2iW09VD" role="2VODD2" />
    </node>
  </node>
  <node concept="13h7C7" id="4TzkayQXql1">
    <ref role="13h7C2" to="20wa:33K18miOFQF" resolve="DataSubject" />
    <node concept="13i0hz" id="4TzkayQXqlc" role="13h7CS">
      <property role="TrG5h" value="getDsId" />
      <node concept="3Tm1VV" id="4TzkayQXqld" role="1B3o_S" />
      <node concept="10Oyi0" id="4TzkayQXqls" role="3clF45" />
      <node concept="3clFbS" id="4TzkayQXqlf" role="3clF47">
        <node concept="3clFbF" id="4TzkayQXqm0" role="3cqZAp">
          <node concept="2OqwBi" id="4TzkayQXqyn" role="3clFbG">
            <node concept="13iPFW" id="4TzkayQXqlZ" role="2Oq$k0" />
            <node concept="3TrcHB" id="4TzkayQXqXI" role="2OqNvi">
              <ref role="3TsBF5" to="20wa:3WaPWglf9AR" resolve="id" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="13hLZK" id="4TzkayQXql2" role="13h7CW">
      <node concept="3clFbS" id="4TzkayQXql3" role="2VODD2" />
    </node>
  </node>
  <node concept="13h7C7" id="4TzkayR2C$3">
    <ref role="13h7C2" to="20wa:5VnHNHVgh9D" resolve="Data" />
    <node concept="13i0hz" id="4TzkayR2C$D" role="13h7CS">
      <property role="TrG5h" value="getDataId" />
      <node concept="3Tm1VV" id="4TzkayR2C$E" role="1B3o_S" />
      <node concept="10Oyi0" id="4TzkayR2C$F" role="3clF45" />
      <node concept="3clFbS" id="4TzkayR2C$G" role="3clF47">
        <node concept="3clFbF" id="4TzkayR2C$H" role="3cqZAp">
          <node concept="2OqwBi" id="4TzkayR2C$I" role="3clFbG">
            <node concept="13iPFW" id="4TzkayR2C$J" role="2Oq$k0" />
            <node concept="3TrcHB" id="4TzkayR2C$K" role="2OqNvi">
              <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="13i0hz" id="4TzkayRmq7c" role="13h7CS">
      <property role="TrG5h" value="setDataId" />
      <node concept="3Tm1VV" id="4TzkayRmq7d" role="1B3o_S" />
      <node concept="3clFbS" id="4TzkayRmq7f" role="3clF47">
        <node concept="3clFbF" id="4TzkayRmq8P" role="3cqZAp">
          <node concept="37vLTI" id="4TzkayRmr8v" role="3clFbG">
            <node concept="37vLTw" id="4TzkayRmrr_" role="37vLTx">
              <ref role="3cqZAo" node="4TzkayRmri3" resolve="id" />
            </node>
            <node concept="2OqwBi" id="4TzkayRmqcP" role="37vLTJ">
              <node concept="13iPFW" id="4TzkayRmq8O" role="2Oq$k0" />
              <node concept="3TrcHB" id="4TzkayRmqeE" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:3WaPWglmSTC" resolve="id" />
              </node>
            </node>
          </node>
        </node>
      </node>
      <node concept="3cqZAl" id="4TzkayRmq8h" role="3clF45" />
      <node concept="37vLTG" id="4TzkayRmri3" role="3clF46">
        <property role="TrG5h" value="id" />
        <node concept="10Oyi0" id="4TzkayRmri2" role="1tU5fm" />
      </node>
    </node>
    <node concept="13hLZK" id="4TzkayR2C$4" role="13h7CW">
      <node concept="3clFbS" id="4TzkayR2C$5" role="2VODD2" />
    </node>
  </node>
  <node concept="13h7C7" id="4TzkayR5dSP">
    <ref role="13h7C2" to="20wa:2olOl3C0Wwg" resolve="NonPersonalData" />
    <node concept="13i0hz" id="4TzkayR5dT0" role="13h7CS">
      <property role="TrG5h" value="getDataId" />
      <node concept="3Tm1VV" id="4TzkayR5dT1" role="1B3o_S" />
      <node concept="10Oyi0" id="4TzkayR5dT2" role="3clF45" />
      <node concept="3clFbS" id="4TzkayR5dT3" role="3clF47">
        <node concept="3clFbF" id="4TzkayR96FU" role="3cqZAp">
          <node concept="BsUDl" id="4TzkayR96FT" role="3clFbG">
            <ref role="37wK5l" node="4TzkayR2C$D" resolve="getDataId" />
          </node>
        </node>
      </node>
    </node>
    <node concept="13i0hz" id="4TzkayRmrPO" role="13h7CS">
      <property role="TrG5h" value="setDataId" />
      <node concept="3Tm1VV" id="4TzkayRmrPP" role="1B3o_S" />
      <node concept="3clFbS" id="4TzkayRmrPQ" role="3clF47">
        <node concept="3clFbF" id="4TzkayRmrPR" role="3cqZAp">
          <node concept="BsUDl" id="4TzkayRmrPS" role="3clFbG">
            <ref role="37wK5l" node="4TzkayRmq7c" resolve="setDataId" />
            <node concept="37vLTw" id="4TzkayRmrPT" role="37wK5m">
              <ref role="3cqZAo" node="4TzkayRmrPV" resolve="id" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3cqZAl" id="4TzkayRmrPU" role="3clF45" />
      <node concept="37vLTG" id="4TzkayRmrPV" role="3clF46">
        <property role="TrG5h" value="id" />
        <node concept="10Oyi0" id="4TzkayRmrPW" role="1tU5fm" />
      </node>
    </node>
    <node concept="13hLZK" id="4TzkayR5dSQ" role="13h7CW">
      <node concept="3clFbS" id="4TzkayR5dSR" role="2VODD2" />
    </node>
  </node>
  <node concept="13h7C7" id="4TzkayR5e8S">
    <ref role="13h7C2" to="20wa:AQqjC1K8N8" resolve="PersonalData" />
    <node concept="13i0hz" id="4TzkayR5e9j" role="13h7CS">
      <property role="TrG5h" value="getDataId" />
      <node concept="3Tm1VV" id="4TzkayR5e9k" role="1B3o_S" />
      <node concept="10Oyi0" id="4TzkayR5e9l" role="3clF45" />
      <node concept="3clFbS" id="4TzkayR5e9m" role="3clF47">
        <node concept="3clFbF" id="4TzkayR96PJ" role="3cqZAp">
          <node concept="BsUDl" id="4TzkayR96PI" role="3clFbG">
            <ref role="37wK5l" node="4TzkayR2C$D" resolve="getDataId" />
          </node>
        </node>
      </node>
    </node>
    <node concept="13i0hz" id="4TzkayRmr_I" role="13h7CS">
      <property role="TrG5h" value="setDataId" />
      <node concept="3Tm1VV" id="4TzkayRmr_J" role="1B3o_S" />
      <node concept="3clFbS" id="4TzkayRmr_K" role="3clF47">
        <node concept="3clFbF" id="4TzkayRmrN7" role="3cqZAp">
          <node concept="BsUDl" id="4TzkayRmrN6" role="3clFbG">
            <ref role="37wK5l" node="4TzkayRmq7c" resolve="setDataId" />
            <node concept="37vLTw" id="4TzkayRmrNo" role="37wK5m">
              <ref role="3cqZAo" node="4TzkayRmr_S" resolve="id" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3cqZAl" id="4TzkayRmr_R" role="3clF45" />
      <node concept="37vLTG" id="4TzkayRmr_S" role="3clF46">
        <property role="TrG5h" value="id" />
        <node concept="10Oyi0" id="4TzkayRmr_T" role="1tU5fm" />
      </node>
    </node>
    <node concept="13hLZK" id="4TzkayR5e8T" role="13h7CW">
      <node concept="3clFbS" id="4TzkayR5e8U" role="2VODD2" />
    </node>
  </node>
  <node concept="13h7C7" id="17LsDUMnS6k">
    <ref role="13h7C2" to="20wa:6vZ7qLQf1O7" resolve="DataRefNpd" />
    <node concept="13i0hz" id="17LsDUMnS6v" role="13h7CS">
      <property role="TrG5h" value="setStatus" />
      <node concept="3Tm1VV" id="17LsDUMnS6w" role="1B3o_S" />
      <node concept="3clFbS" id="17LsDUMnS6y" role="3clF47">
        <node concept="3clFbF" id="17LsDUMnS7U" role="3cqZAp">
          <node concept="37vLTI" id="17LsDUMnUjf" role="3clFbG">
            <node concept="37vLTw" id="17LsDUMnUuX" role="37vLTx">
              <ref role="3cqZAo" node="17LsDUMnS7x" resolve="status" />
            </node>
            <node concept="2OqwBi" id="17LsDUMnTda" role="37vLTJ">
              <node concept="2OqwBi" id="17LsDUMnSUi" role="2Oq$k0">
                <node concept="13iPFW" id="17LsDUMnS7T" role="2Oq$k0" />
                <node concept="3TrEf2" id="17LsDUMnT1v" role="2OqNvi">
                  <ref role="3Tt5mk" to="20wa:6vZ7qLQf1Oa" resolve="dataUsage" />
                </node>
              </node>
              <node concept="3TrcHB" id="17LsDUMnTSB" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:5VnHNHVghv9" resolve="hasPersonalUsage" />
              </node>
            </node>
          </node>
        </node>
      </node>
      <node concept="3cqZAl" id="17LsDUMnS75" role="3clF45" />
      <node concept="37vLTG" id="17LsDUMnS7x" role="3clF46">
        <property role="TrG5h" value="status" />
        <node concept="3uibUv" id="17LsDUMnS7w" role="1tU5fm">
          <ref role="3uigEE" to="wyt6:~Boolean" resolve="Boolean" />
        </node>
      </node>
    </node>
    <node concept="13hLZK" id="17LsDUMnS6l" role="13h7CW">
      <node concept="3clFbS" id="17LsDUMnS6m" role="2VODD2" />
    </node>
  </node>
</model>

