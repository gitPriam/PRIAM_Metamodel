<?xml version="1.0" encoding="UTF-8"?>
<model ref="r:2adcd0b5-6265-4462-b7b6-92dedd477e2c(PRIAM_LANGUAGE.typesystem)">
  <persistence version="9" />
  <languages>
    <use id="7a5dda62-9140-4668-ab76-d5ed1746f2b2" name="jetbrains.mps.lang.typesystem" version="5" />
    <devkit ref="00000000-0000-4000-0000-1de82b3a4936(jetbrains.mps.devkit.aspect.typesystem)" />
  </languages>
  <imports>
    <import index="20wa" ref="r:515d5f51-79c9-42c9-bba4-54c97b772d5b(PRIAM_LANGUAGE.structure)" implicit="true" />
    <import index="wyt6" ref="6354ebe7-c22a-4a0f-ac54-50b52ab9b065/java:java.lang(JDK/)" implicit="true" />
  </imports>
  <registry>
    <language id="f3061a53-9226-4cc5-a443-f952ceaf5816" name="jetbrains.mps.baseLanguage">
      <concept id="1080223426719" name="jetbrains.mps.baseLanguage.structure.OrExpression" flags="nn" index="22lmx$" />
      <concept id="1202948039474" name="jetbrains.mps.baseLanguage.structure.InstanceMethodCallOperation" flags="nn" index="liA8E" />
      <concept id="1197027756228" name="jetbrains.mps.baseLanguage.structure.DotExpression" flags="nn" index="2OqwBi">
        <child id="1197027771414" name="operand" index="2Oq$k0" />
        <child id="1197027833540" name="operation" index="2OqNvi" />
      </concept>
      <concept id="1070475926800" name="jetbrains.mps.baseLanguage.structure.StringLiteral" flags="nn" index="Xl_RD">
        <property id="1070475926801" name="value" index="Xl_RC" />
      </concept>
      <concept id="1068580123152" name="jetbrains.mps.baseLanguage.structure.EqualsExpression" flags="nn" index="3clFbC" />
      <concept id="1068580123157" name="jetbrains.mps.baseLanguage.structure.Statement" flags="nn" index="3clFbH" />
      <concept id="1068580123159" name="jetbrains.mps.baseLanguage.structure.IfStatement" flags="nn" index="3clFbJ">
        <child id="1068580123160" name="condition" index="3clFbw" />
        <child id="1068580123161" name="ifTrue" index="3clFbx" />
      </concept>
      <concept id="1068580123136" name="jetbrains.mps.baseLanguage.structure.StatementList" flags="sn" stub="5293379017992965193" index="3clFbS">
        <child id="1068581517665" name="statement" index="3cqZAp" />
      </concept>
      <concept id="1068580123137" name="jetbrains.mps.baseLanguage.structure.BooleanConstant" flags="nn" index="3clFbT">
        <property id="1068580123138" name="value" index="3clFbU" />
      </concept>
      <concept id="1068580320020" name="jetbrains.mps.baseLanguage.structure.IntegerConstant" flags="nn" index="3cmrfG">
        <property id="1068580320021" name="value" index="3cmrfH" />
      </concept>
      <concept id="1081506762703" name="jetbrains.mps.baseLanguage.structure.GreaterThanExpression" flags="nn" index="3eOSWO" />
      <concept id="1081506773034" name="jetbrains.mps.baseLanguage.structure.LessThanExpression" flags="nn" index="3eOVzh" />
      <concept id="1204053956946" name="jetbrains.mps.baseLanguage.structure.IMethodCall" flags="ng" index="1ndlxa">
        <reference id="1068499141037" name="baseMethodDeclaration" index="37wK5l" />
        <child id="1068499141038" name="actualArgument" index="37wK5m" />
      </concept>
      <concept id="1081773326031" name="jetbrains.mps.baseLanguage.structure.BinaryOperation" flags="nn" index="3uHJSO">
        <child id="1081773367579" name="rightExpression" index="3uHU7w" />
        <child id="1081773367580" name="leftExpression" index="3uHU7B" />
      </concept>
    </language>
    <language id="7a5dda62-9140-4668-ab76-d5ed1746f2b2" name="jetbrains.mps.lang.typesystem">
      <concept id="1207055528241" name="jetbrains.mps.lang.typesystem.structure.WarningStatement" flags="nn" index="a7r0C">
        <child id="1207055552304" name="warningText" index="a7wSD" />
      </concept>
      <concept id="1175517767210" name="jetbrains.mps.lang.typesystem.structure.ReportErrorStatement" flags="nn" index="2MkqsV">
        <child id="1175517851849" name="errorString" index="2MkJ7o" />
      </concept>
      <concept id="1195213580585" name="jetbrains.mps.lang.typesystem.structure.AbstractCheckingRule" flags="ig" index="18hYwZ">
        <child id="1195213635060" name="body" index="18ibNy" />
      </concept>
      <concept id="1195214364922" name="jetbrains.mps.lang.typesystem.structure.NonTypesystemRule" flags="ig" index="18kY7G" />
      <concept id="3937244445246642777" name="jetbrains.mps.lang.typesystem.structure.AbstractReportStatement" flags="ng" index="1urrMJ">
        <child id="3937244445246642781" name="nodeToReport" index="1urrMF" />
      </concept>
      <concept id="1174642788531" name="jetbrains.mps.lang.typesystem.structure.ConceptReference" flags="ig" index="1YaCAy">
        <reference id="1174642800329" name="concept" index="1YaFvo" />
      </concept>
      <concept id="1174648085619" name="jetbrains.mps.lang.typesystem.structure.AbstractRule" flags="ng" index="1YuPPy">
        <child id="1174648101952" name="applicableNode" index="1YuTPh" />
      </concept>
      <concept id="1174650418652" name="jetbrains.mps.lang.typesystem.structure.ApplicableNodeReference" flags="nn" index="1YBJjd">
        <reference id="1174650432090" name="applicableNode" index="1YBMHb" />
      </concept>
    </language>
    <language id="7866978e-a0f0-4cc7-81bc-4d213d9375e1" name="jetbrains.mps.lang.smodel">
      <concept id="1138056022639" name="jetbrains.mps.lang.smodel.structure.SPropertyAccess" flags="nn" index="3TrcHB">
        <reference id="1138056395725" name="property" index="3TsBF5" />
      </concept>
      <concept id="1138056143562" name="jetbrains.mps.lang.smodel.structure.SLinkAccess" flags="nn" index="3TrEf2">
        <reference id="1138056516764" name="link" index="3Tt5mk" />
      </concept>
    </language>
    <language id="ceab5195-25ea-4f22-9b92-103b95ca8c0c" name="jetbrains.mps.lang.core">
      <concept id="1169194658468" name="jetbrains.mps.lang.core.structure.INamedConcept" flags="ng" index="TrEIO">
        <property id="1169194664001" name="name" index="TrG5h" />
      </concept>
    </language>
  </registry>
  <node concept="18kY7G" id="1qGzCsG8we9">
    <property role="TrG5h" value="check_PersonalData" />
    <node concept="3clFbS" id="1qGzCsG8wea" role="18ibNy">
      <node concept="3clFbJ" id="1qGzCsG8wej" role="3cqZAp">
        <node concept="3clFbS" id="1qGzCsG8wel" role="3clFbx">
          <node concept="3clFbJ" id="1qGzCsGe9F6" role="3cqZAp">
            <node concept="3clFbS" id="1qGzCsGe9F8" role="3clFbx">
              <node concept="a7r0C" id="1qGzCsGolh7" role="3cqZAp">
                <node concept="1YBJjd" id="1qGzCsGolyt" role="1urrMF">
                  <ref role="1YBMHb" node="1qGzCsG8wec" resolve="personalData" />
                </node>
                <node concept="Xl_RD" id="1qGzCsG8$Eq" role="a7wSD">
                  <property role="Xl_RC" value="Each 'direct' source data has the value 'true' in the isPortable attribute" />
                </node>
              </node>
            </node>
            <node concept="3clFbC" id="1qGzCsG8yYH" role="3clFbw">
              <node concept="3clFbT" id="1qGzCsG8zb2" role="3uHU7w" />
              <node concept="2OqwBi" id="1qGzCsG8xE$" role="3uHU7B">
                <node concept="1YBJjd" id="1qGzCsG8x_x" role="2Oq$k0">
                  <ref role="1YBMHb" node="1qGzCsG8wec" resolve="personalData" />
                </node>
                <node concept="3TrcHB" id="1qGzCsG8ybS" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5TuIUILdRIm" resolve="isPortable" />
                </node>
              </node>
            </node>
          </node>
          <node concept="3clFbH" id="1qGzCsGiB0X" role="3cqZAp" />
        </node>
        <node concept="2OqwBi" id="1qGzCsGhxt7" role="3clFbw">
          <node concept="2OqwBi" id="1qGzCsGgpSN" role="2Oq$k0">
            <node concept="2OqwBi" id="1qGzCsGfgOv" role="2Oq$k0">
              <node concept="1YBJjd" id="1qGzCsGfgDM" role="2Oq$k0">
                <ref role="1YBMHb" node="1qGzCsG8wec" resolve="personalData" />
              </node>
              <node concept="3TrcHB" id="1qGzCsGgpJj" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:5VnHNHVgh9K" resolve="source" />
              </node>
            </node>
            <node concept="liA8E" id="1qGzCsGhxsf" role="2OqNvi">
              <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
            </node>
          </node>
          <node concept="liA8E" id="1qGzCsGhxM9" role="2OqNvi">
            <ref role="37wK5l" to="wyt6:~String.equals(java.lang.Object)" resolve="equals" />
            <node concept="Xl_RD" id="1qGzCsGhxNv" role="37wK5m">
              <property role="Xl_RC" value="Direct" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3clFbJ" id="1qGzCsGiB7r" role="3cqZAp">
        <node concept="3clFbS" id="1qGzCsGiB7s" role="3clFbx">
          <node concept="3clFbJ" id="1qGzCsGiB7t" role="3cqZAp">
            <node concept="3clFbS" id="1qGzCsGiB7u" role="3clFbx">
              <node concept="a7r0C" id="1qGzCsGol_G" role="3cqZAp">
                <node concept="1YBJjd" id="1qGzCsGolD6" role="1urrMF">
                  <ref role="1YBMHb" node="1qGzCsG8wec" resolve="personalData" />
                </node>
                <node concept="Xl_RD" id="1qGzCsGiB7w" role="a7wSD">
                  <property role="Xl_RC" value="Any 'Produced' source data cannot be portable" />
                </node>
              </node>
            </node>
            <node concept="3clFbC" id="1qGzCsGiB7y" role="3clFbw">
              <node concept="2OqwBi" id="1qGzCsGiB7$" role="3uHU7B">
                <node concept="1YBJjd" id="1qGzCsGiB7_" role="2Oq$k0">
                  <ref role="1YBMHb" node="1qGzCsG8wec" resolve="personalData" />
                </node>
                <node concept="3TrcHB" id="1qGzCsGiB7A" role="2OqNvi">
                  <ref role="3TsBF5" to="20wa:5TuIUILdRIm" resolve="isPortable" />
                </node>
              </node>
              <node concept="3clFbT" id="1qGzCsGiBtl" role="3uHU7w">
                <property role="3clFbU" value="true" />
              </node>
            </node>
          </node>
          <node concept="3clFbH" id="1qGzCsGiB7B" role="3cqZAp" />
        </node>
        <node concept="2OqwBi" id="1qGzCsGiB7C" role="3clFbw">
          <node concept="2OqwBi" id="1qGzCsGiB7D" role="2Oq$k0">
            <node concept="2OqwBi" id="1qGzCsGiB7E" role="2Oq$k0">
              <node concept="1YBJjd" id="1qGzCsGiB7F" role="2Oq$k0">
                <ref role="1YBMHb" node="1qGzCsG8wec" resolve="personalData" />
              </node>
              <node concept="3TrcHB" id="1qGzCsGiB7G" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:5VnHNHVgh9K" resolve="source" />
              </node>
            </node>
            <node concept="liA8E" id="1qGzCsGiB7H" role="2OqNvi">
              <ref role="37wK5l" to="wyt6:~Object.toString()" resolve="toString" />
            </node>
          </node>
          <node concept="liA8E" id="1qGzCsGiB7I" role="2OqNvi">
            <ref role="37wK5l" to="wyt6:~String.equals(java.lang.Object)" resolve="equals" />
            <node concept="Xl_RD" id="1qGzCsGiB7J" role="37wK5m">
              <property role="Xl_RC" value="Produced" />
            </node>
          </node>
        </node>
      </node>
      <node concept="3clFbH" id="1qGzCsGiB19" role="3cqZAp" />
    </node>
    <node concept="1YaCAy" id="1qGzCsG8wec" role="1YuTPh">
      <property role="TrG5h" value="personalData" />
      <ref role="1YaFvo" to="20wa:AQqjC1K8N8" resolve="PersonalData" />
    </node>
  </node>
  <node concept="18kY7G" id="17LsDUMm9s6">
    <property role="TrG5h" value="check_Country" />
    <node concept="3clFbS" id="17LsDUMm9s7" role="18ibNy">
      <node concept="3clFbJ" id="17LsDUMm9uT" role="3cqZAp">
        <node concept="3clFbS" id="17LsDUMm9uU" role="3clFbx">
          <node concept="a7r0C" id="17LsDUMm9uX" role="3cqZAp">
            <node concept="1YBJjd" id="17LsDUMm9uY" role="1urrMF">
              <ref role="1YBMHb" node="17LsDUMm9s9" resolve="country" />
            </node>
            <node concept="Xl_RD" id="17LsDUMm9uZ" role="a7wSD">
              <property role="Xl_RC" value="the minor age for a country must be between 13 and 16 years" />
            </node>
          </node>
        </node>
        <node concept="22lmx$" id="17LsDUMmdVG" role="3clFbw">
          <node concept="3eOSWO" id="17LsDUMmfhk" role="3uHU7w">
            <node concept="3cmrfG" id="17LsDUMmfij" role="3uHU7w">
              <property role="3cmrfH" value="16" />
            </node>
            <node concept="2OqwBi" id="17LsDUMmemZ" role="3uHU7B">
              <node concept="1YBJjd" id="17LsDUMmecC" role="2Oq$k0">
                <ref role="1YBMHb" node="17LsDUMm9s9" resolve="country" />
              </node>
              <node concept="3TrcHB" id="17LsDUMmez9" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:5TuIUILdRH_" resolve="minorAge" />
              </node>
            </node>
          </node>
          <node concept="3eOVzh" id="17LsDUMmd8O" role="3uHU7B">
            <node concept="2OqwBi" id="17LsDUMmbew" role="3uHU7B">
              <node concept="1YBJjd" id="17LsDUMmb4F" role="2Oq$k0">
                <ref role="1YBMHb" node="17LsDUMm9s9" resolve="country" />
              </node>
              <node concept="3TrcHB" id="17LsDUMmbxY" role="2OqNvi">
                <ref role="3TsBF5" to="20wa:5TuIUILdRH_" resolve="minorAge" />
              </node>
            </node>
            <node concept="3cmrfG" id="17LsDUMmd9k" role="3uHU7w">
              <property role="3cmrfH" value="13" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="1YaCAy" id="17LsDUMm9s9" role="1YuTPh">
      <property role="TrG5h" value="country" />
      <ref role="1YaFvo" to="20wa:5TuIUILdRHt" resolve="Country" />
    </node>
  </node>
  <node concept="18kY7G" id="17LsDUMq16P">
    <property role="TrG5h" value="check_DataRefNpd" />
    <node concept="3clFbS" id="17LsDUMq16Q" role="18ibNy">
      <node concept="3clFbJ" id="17LsDUMq1DR" role="3cqZAp">
        <node concept="3clFbS" id="17LsDUMq1DT" role="3clFbx">
          <node concept="2MkqsV" id="17LsDUMq2R1" role="3cqZAp">
            <node concept="Xl_RD" id="17LsDUMq2Rg" role="2MkJ7o">
              <property role="Xl_RC" value="Non-personal data always has a non-personal status" />
            </node>
            <node concept="1YBJjd" id="17LsDUMq2Rr" role="1urrMF">
              <ref role="1YBMHb" node="17LsDUMq16S" resolve="dataRefNpd" />
            </node>
          </node>
        </node>
        <node concept="3clFbC" id="17LsDUMq2Bd" role="3clFbw">
          <node concept="3clFbT" id="17LsDUMq2Qv" role="3uHU7w">
            <property role="3clFbU" value="true" />
          </node>
          <node concept="2OqwBi" id="17LsDUMq260" role="3uHU7B">
            <node concept="2OqwBi" id="17LsDUMq1N9" role="2Oq$k0">
              <node concept="1YBJjd" id="17LsDUMq1E6" role="2Oq$k0">
                <ref role="1YBMHb" node="17LsDUMq16S" resolve="dataRefNpd" />
              </node>
              <node concept="3TrEf2" id="17LsDUMq1Um" role="2OqNvi">
                <ref role="3Tt5mk" to="20wa:6vZ7qLQf1Oa" resolve="dataUsage" />
              </node>
            </node>
            <node concept="3TrcHB" id="17LsDUMq2gg" role="2OqNvi">
              <ref role="3TsBF5" to="20wa:5VnHNHVghv9" resolve="hasPersonalUsage" />
            </node>
          </node>
        </node>
      </node>
    </node>
    <node concept="1YaCAy" id="17LsDUMq16S" role="1YuTPh">
      <property role="TrG5h" value="dataRefNpd" />
      <ref role="1YaFvo" to="20wa:6vZ7qLQf1O7" resolve="DataRefNpd" />
    </node>
  </node>
</model>

